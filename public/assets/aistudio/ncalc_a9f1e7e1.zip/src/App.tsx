import React, { useEffect, useRef, useState, useMemo } from 'react';
import { useStore } from './store'; import FormulaToolbar from './components/FormulaToolbar';
import FormulaBuilderPanel from './components/FormulaBuilderPanel';
import {
  THEMES,
  BUILTIN_TEMPLATES,
  FUNCS_METADATA,
  colToLetter,
  cellRef,
  cellKey,
  selBounds,
  parseCellRef,
  parseRange,
  exportToCSV,
  downloadFile,
  getFormulaHighlights,
  isValidNamedRangeName,
  evaluateFormula,
  EvalContext,
} from './utils';
import {
  FONT_FAMILIES,
  FONT_SIZES,
  NUMBER_FORMATS,
  CellFormat,
  ThemeDef,
  FuncDef,
  Template,
  NamedRange,
} from './types';
import ReactEChartsCore from 'echarts-for-react/lib/core';
import * as echarts from 'echarts/core';
import { BarChart, LineChart, PieChart, ScatterChart, RadarChart } from 'echarts/charts';
import { GridComponent, TooltipComponent, TitleComponent, LegendComponent } from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';
import Papa from 'papaparse';

echarts.use([
  BarChart,
  LineChart,
  PieChart,
  ScatterChart,
  RadarChart,
  GridComponent,
  TooltipComponent,
  TitleComponent,
  LegendComponent,
  CanvasRenderer,
]);

const DCW = 90, DRH = 24, MINCW = 35, MINRH = 18, MAXCW = 500, MAXRH = 300;

// Standard 70-color quick palette
const PALETTE_COLORS = [
  '#000000', '#434343', '#666666', '#999999', '#b7b7b7', '#cccccc', '#d9d9d9', '#efefef', '#f3f3f3', '#ffffff',
  '#980000', '#ff0000', '#ff9900', '#ffff00', '#00ff00', '#00ffff', '#4a86e8', '#0000ff', '#9900ff', '#ff00ff',
  '#e6b8af', '#f4cccc', '#fce5cd', '#fff2cc', '#d9ead3', '#d0e0e3', '#c9daf8', '#cfe2f3', '#d9d2e9', '#ead1dc',
  '#dd7e6b', '#ea9999', '#f9cb9c', '#ffe599', '#b6d7a8', '#a2c4c9', '#a4c2f4', '#9fc5e8', '#b4a7d6', '#d5a6bd',
  '#cc4125', '#e06666', '#f6b26b', '#ffd966', '#93c47d', '#76a5af', '#6d9eeb', '#6fa8dc', '#8e7cc3', '#c27ba0',
  '#a61c1c', '#cc0000', '#e69138', '#f1c232', '#6aa84f', '#45818e', '#3c78d8', '#3d85c6', '#674ea7', '#a64d79',
  '#5b0f00', '#660000', '#783f04', '#7f6000', '#274e13', '#0c343d', '#1155cc', '#0b5394', '#351c75', '#4c1130',
];

// Helper to calculate contiguous active data table range
function getDetectedTableRange(s: any): string {
  const b = selBounds(s.sel);
  if (b.r2 > b.r1 || b.c2 > b.c1) {
    return `${cellRef(b.c1, b.r1)}:${cellRef(b.c2, b.r2)}`;
  }
  const sh = s.sheet();
  const keys = Object.keys(sh.cells);
  if (keys.length === 0) return `${cellRef(b.c1, b.r1)}:${cellRef(b.c1, b.r1)}`;

  let minC = b.c1, maxC = b.c1, minR = b.r1, maxR = b.r1;
  keys.forEach(k => {
    const [c, r] = k.split(',').map(Number);
    if (sh.cells[k]?.raw) {
      if (c < minC) minC = c;
      if (c > maxC) maxC = c;
      if (r < minR) minR = r;
      if (r > maxR) maxR = r;
    }
  });

  return `${cellRef(minC, minR)}:${cellRef(maxC, maxR)}`;
}

import ExcelRibbon from './components/ExcelRibbon';

// ===== FORMULA BAR WITH AUTOCOMPLETE & ASSIST =====
function FormulaBar() {
  const s = useStore();
  const inpRef = useRef<HTMLInputElement>(null);
  const { editing, editValue, sel } = s;
  const { c, r } = sel.cursor;
  const name = cellRef(c, r);
  const raw = s.getCellRaw(c, r);

  const [acIndex, setAcIndex] = useState(0);

  const currentVal = editing ? editValue : raw;
  const isTypingFormula = currentVal.startsWith('=');

  const formulaMatch = currentVal.match(/^=([A-Za-z0-9_]*)$/);
  const prefix = formulaMatch ? formulaMatch[1].toUpperCase() : null;

  // Autocomplete includes 65+ functions AND defined named ranges (P3.2)
  const suggestions: FuncDef[] = useMemo(() => {
    if (prefix === null) return [];
    const funcs = FUNCS_METADATA.filter(fn => fn.name.startsWith(prefix)).slice(0, 6);
    const matchedNames: FuncDef[] = s.namedRanges
      .filter(nr => nr.name.toUpperCase().startsWith(prefix))
      .slice(0, 3)
      .map(nr => ({
        name: nr.name,
        syntax: nr.name,
        desc: `Named range referring to ${nr.range}${nr.comment ? ` (${nr.comment})` : ''}`,
        category: 'Lookup' as any,
        example: `=${nr.name}`,
      }));
    return [...matchedNames, ...funcs].slice(0, 8);
  }, [prefix, s.namedRanges]);

  // P3.1: Formula Highlights for referenced tokens
  const formulaTokensHighlights = useMemo(() => {
    if (!currentVal || !currentVal.startsWith('=')) return [];
    return getFormulaHighlights(currentVal, s.namedRanges);
  }, [currentVal, s.namedRanges]);

  const activeFuncHint = useMemo(() => {
    const fnMatch = currentVal.match(/^=([A-Z0-9]+)\(/i);
    if (!fnMatch) return null;
    const fnName = fnMatch[1].toUpperCase();
    return FUNCS_METADATA.find(fn => fn.name === fnName) || null;
  }, [currentVal]);

  const selectSuggestion = (fnName: string) => {
    s.setEditVal(`=${fnName}(`);
    if (inpRef.current) inpRef.current.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (suggestions.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setAcIndex(i => (i + 1) % suggestions.length);
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setAcIndex(i => (i - 1 + suggestions.length) % suggestions.length);
        return;
      }
      if (e.key === 'Tab' || (e.key === 'Enter' && prefix !== '')) {
        e.preventDefault();
        selectSuggestion(suggestions[acIndex].name);
        return;
      }
    }

    if (e.key === 'Enter') {
      e.preventDefault();
      s.stopEdit(true);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      s.stopEdit(false);
    }
  };

  return (
    <div className="fx-bar relative">
      <input
        className="fx-cell"
        defaultValue={name}
        key={name}
        onKeyDown={e => {
          if (e.key === 'Enter') {
            e.preventDefault();
            const val = (e.target as HTMLInputElement).value.toUpperCase().trim();
            const parsed = parseRange(val) || parseRange(`${val}:${val}`);
            if (parsed) {
              s.setSel({ anchor: { c: parsed.c1, r: parsed.r1 }, cursor: { c: parsed.c2, r: parsed.r2 } });
            }
            (e.target as HTMLInputElement).blur();
          }
        }}
        onFocus={e => (e.target as HTMLInputElement).select()}
        title="Jump to cell address (e.g. A1, B10)"
      />

      <span className={`fx-badge${editing && isTypingFormula ? ' formula-mode' : ''}`} title={editing && isTypingFormula ? 'Formula mode' : 'fx'}>
        fx
      </span>

      <div className="flex-1 relative">
        <input
          ref={inpRef}
          className="w-full font-mono text-[12px] px-2 py-0.5 outline-none"
          style={{
            background: 'var(--panel)',
            border: '1px solid var(--border)',
            borderRadius: '.3rem',
            color: 'var(--text)',
          }}
          value={currentVal}
          onChange={e => {
            if (editing) s.setEditVal(e.target.value);
            else s.startEdit(e.target.value);
            setAcIndex(0);
          }}
          onKeyDown={handleKeyDown}
          onFocus={() => {
            if (!editing) s.startEdit();
          }}
          placeholder={editing ? '' : 'Enter value or formula (e.g. =SUM(A1:A5), =IF(B2>100, "High", "Low"))'}
        />

        {/* Autocomplete Dropdown */}
        {isTypingFormula && suggestions.length > 0 && (
          <div className="absolute top-full left-0 mt-1 bg-[var(--menu-bg)] border border-[var(--border)] rounded shadow-2xl z-50 min-w-[320px] max-h-56 overflow-auto py-1">
            {suggestions.map((fn, idx) => (
              <div
                key={fn.name}
                className={`px-3 py-1.5 cursor-pointer text-xs flex flex-col ${
                  idx === acIndex ? 'bg-[var(--hover)] text-[var(--accent)] font-semibold' : 'hover:bg-[var(--hover)]'
                }`}
                onClick={() => selectSuggestion(fn.name)}
              >
                <div className="flex items-center justify-between font-mono">
                  <span>{fn.name}</span>
                  <span className="text-[10px] opacity-60 font-sans">{fn.category}</span>
                </div>
                <div className="text-[10.5px] opacity-75 font-sans font-normal">{fn.desc}</div>
              </div>
            ))}
          </div>
        )}

        {/* Live Function Syntax Assist */}
        {activeFuncHint && (
          <div className="absolute top-full left-0 mt-1 bg-[var(--menu-bg)] border border-[var(--border)] rounded shadow-2xl p-2 z-40 text-xs max-w-sm">
            <div className="font-mono font-bold text-[var(--accent)]">{activeFuncHint.syntax}</div>
            <div className="text-[11px] text-[var(--muted)] mt-0.5">{activeFuncHint.desc}</div>
            <div className="text-[10.5px] text-[var(--text)] mt-1 opacity-80 font-mono">
              Example: {activeFuncHint.example}
            </div>
          </div>
        )}
      </div><FormulaToolbar inputRef={inpRef} />

      {/* P3.1: Interactive Colored Reference Chips in Formula Bar */}
      {formulaTokensHighlights.length > 0 && (
        <div className="hidden lg:flex items-center gap-1 pl-1 pr-2 max-w-xs overflow-x-auto">
          {formulaTokensHighlights.map((hl, idx) => (
            <button
              key={idx}
              type="button"
              className="px-2 py-0.5 rounded text-[10.5px] font-mono font-bold whitespace-nowrap cursor-pointer transition-all hover:scale-105 shadow-2xs"
              style={{
                background: hl.bgColor,
                color: hl.color,
                border: `1.5px solid ${hl.borderColor}`,
              }}
              onClick={() => {
                s.setSel({
                  anchor: { c: hl.bounds.c1, r: hl.bounds.r1 },
                  cursor: { c: hl.bounds.c2, r: hl.bounds.r2 },
                });
                s.toast(`Selected reference: ${hl.refText}`);
              }}
              title={`Click to jump to reference: ${hl.refText}`}
            >
              {hl.refText}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ===== GRID =====
function Grid() {
  const s = useStore();
  const gridRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const editorRef = useRef<HTMLTextAreaElement>(null);

  const [dragging, setDragging] = useState<'col' | 'row' | null>(null);
  const [dragIdx, setDragIdx] = useState(-1);
  const [dragStart, setDragStart] = useState(0);
  const [dragStartSize, setDragStartSize] = useState(0);

  const [selecting, setSelecting] = useState(false);
  const [autoFilling, setAutoFilling] = useState(false);
  const [fillTarget, setFillTarget] = useState<{ c: number; r: number } | null>(null);

  const [hoverTip, setHoverTip] = useState<{ c: number; r: number; raw: string; val: any; x: number; y: number } | null>(null);

  const { gridRows, gridCols, sel, editing, editValue, gridlines, frozenRow } = s;
  const sh = s.sheet();
  const cw = sh.colWidths || {};
  const rh = sh.rowHeights || {};
  const bounds = selBounds(sel);

  // P3.1: Interactive Colored Formula Referencing
  const activeFormula = editing ? editValue : s.getCellRaw(sel.cursor.c, sel.cursor.r);
  const formulaHighlights = useMemo(() => {
    if (!activeFormula || !activeFormula.startsWith('=')) return [];
    return getFormulaHighlights(activeFormula, s.namedRanges);
  }, [activeFormula, s.namedRanges, editing]);

  const highlightKeyMap = useMemo(() => {
    const map = new Map<string, typeof formulaHighlights[0]>();
    formulaHighlights.forEach(hl => {
      hl.cellKeys.forEach(k => {
        if (!map.has(k)) map.set(k, hl);
      });
    });
    return map;
  }, [formulaHighlights]);

  // In-Cell formula autocomplete suggestions
  const inCellSuggestions = useMemo(() => {
    if (!editing || !editValue.startsWith('=')) return [];
    const match = editValue.match(/^=([A-Za-z0-9_]*)$/);
    if (!match) return [];
    const prefix = match[1].toUpperCase();
    return FUNCS_METADATA.filter(fn => fn.name.startsWith(prefix)).slice(0, 6);
  }, [editing, editValue]);

  // Wizard Visual Grid Range Highlights (Suggestion #4)
  const wizardGridMap = useMemo(() => {
    if (!s.showFunctionWizard) return null;
    const map = new Map<string, { type: 'start' | 'end' | 'inRange'; color: string; border: string; bg: string }>();

    const processRange = (startStr: string, endStr: string) => {
      const s1 = parseCellRef(startStr);
      const e1 = parseCellRef(endStr);
      if (!s1 || !e1) return;
      const minC = Math.min(s1.c, e1.c);
      const maxC = Math.max(s1.c, e1.c);
      const minR = Math.min(s1.r, e1.r);
      const maxR = Math.max(s1.r, e1.r);

      for (let r = minR; r <= maxR; r++) {
        for (let c = minC; c <= maxC; c++) {
          const k = cellKey(c, r);
          map.set(k, { type: 'inRange', color: '#10b981', border: '1.5px dashed #10b981', bg: 'rgba(16, 185, 129, 0.12)' });
        }
      }

      // Mark start & end
      map.set(cellKey(s1.c, s1.r), { type: 'start', color: '#16a34a', border: '2.5px solid #16a34a', bg: 'rgba(22, 163, 74, 0.2)' });
      map.set(cellKey(e1.c, e1.r), { type: 'end', color: '#ca8a04', border: '2.5px solid #ca8a04', bg: 'rgba(202, 138, 4, 0.2)' });
    };

    if (s.functionWizardStart && s.functionWizardEnd) {
      processRange(s.functionWizardStart, s.functionWizardEnd);
    }
    s.functionWizardExtraRanges.forEach(extra => {
      if (extra.start && extra.end) processRange(extra.start, extra.end);
    });

    return map;
  }, [s.showFunctionWizard, s.functionWizardStart, s.functionWizardEnd, s.functionWizardExtraRanges]);

  // Quick Analysis Widget Popover State
  const [showQuickAnalysis, setShowQuickAnalysis] = useState(false);
  const isMultiSelection = (bounds.r2 > bounds.r1 || bounds.c2 > bounds.c1) && !editing;

  const getCS = (c: number, r: number): React.CSSProperties => {
    const f = s.getCellFmt(c, r);
    if (!f) return {};
    const st: React.CSSProperties = {};
    if (f.bold) st.fontWeight = 'bold';
    if (f.italic) st.fontStyle = 'italic';
    if (f.underline && f.strikethrough) st.textDecoration = 'underline line-through';
    else if (f.underline) st.textDecoration = 'underline';
    else if (f.strikethrough) st.textDecoration = 'line-through';
    if (f.fontFamily) st.fontFamily = f.fontFamily;
    if (f.fontSize) st.fontSize = `${f.fontSize}px`;
    if (f.color) st.color = f.color;
    if (f.bgColor) st.background = f.bgColor;
    if (f.align) st.textAlign = f.align;
    if (f.valign) st.verticalAlign = f.valign;
    if (f.wrap) { st.whiteSpace = 'normal'; st.wordBreak = 'break-word'; }
    if (f.border) {
      if (f.border.t) st.borderTop = f.border.t;
      if (f.border.b) st.borderBottom = f.border.b;
      if (f.border.l) st.borderLeft = f.border.l;
      if (f.border.r) st.borderRight = f.border.r;
    }
    return st;
  };

  const handleMouseDown = (e: React.MouseEvent, c: number, r: number) => {
    if (e.button === 2) {
      if (c < bounds.c1 || c > bounds.c2 || r < bounds.r1 || r > bounds.r2) {
        s.setSel({ anchor: { c, r }, cursor: { c, r } });
      }
      s.setShowCtxMenu(true, { x: e.clientX, y: e.clientY });
      return;
    }

    // Point-and-Click Formula Referencing (Smart UX)
    if (editing && editValue.startsWith('=')) {
      e.preventDefault();
      const clickedAddress = cellRef(c, r);
      if (/([+\-*\/^,=(&<>:,]\s*)$/.test(editValue)) {
        s.setEditVal(editValue + clickedAddress);
      } else if (/\b\$?[A-Z]+\$?\d+$/i.test(editValue)) {
        // Replace last cell ref token with clicked cell
        const updated = editValue.replace(/(\$?[A-Z]+\$?\d+)$/i, clickedAddress);
        s.setEditVal(updated);
      } else {
        s.setEditVal(editValue + clickedAddress);
      }

      if (editorRef.current) {
        editorRef.current.focus();
        const len = editorRef.current.value.length;
        editorRef.current.setSelectionRange(len, len);
      }
      return;
    }

    if (editing) s.stopEdit(true);
    s.setShowCtxMenu(false);

    if (s.formatPainter?.active) {
      if (e.shiftKey) {
        s.setSel({ ...sel, cursor: { c, r } });
      } else {
        s.setSel({ anchor: { c, r }, cursor: { c, r } });
      }
      s.applyFormatPainterToSelection();
      setSelecting(false);
      return;
    }

    if (e.shiftKey) {
      s.setSel({ ...sel, cursor: { c, r } });
    } else {
      s.setSel({ anchor: { c, r }, cursor: { c, r } });
    }
    setSelecting(true);
  };

  const handleMouseMove = (_e: React.MouseEvent, c: number, r: number) => {
    if (selecting) {
      s.setSel({ ...sel, cursor: { c, r } });
    } else if (autoFilling) {
      setFillTarget({ c: Math.max(bounds.c2, c), r: Math.max(bounds.r2, r) });
    }
  };

  const handleFillHandleDown = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setAutoFilling(true);
    setFillTarget({ c: bounds.c2, r: bounds.r2 });
  };

  useEffect(() => {
    const handleGlobalMouseUp = () => {
      if (autoFilling && fillTarget) {
        if (fillTarget.r > bounds.r2 || fillTarget.c > bounds.c2) {
          s.autoFillToRange(bounds, {
            c1: bounds.c1,
            r1: bounds.r1,
            c2: fillTarget.c,
            r2: fillTarget.r,
          });
          s.toast('Series auto-filled');
        }
      }
      setSelecting(false);
      setAutoFilling(false);
      setFillTarget(null);
    };

    window.addEventListener('mouseup', handleGlobalMouseUp);
    return () => window.removeEventListener('mouseup', handleGlobalMouseUp);
  }, [autoFilling, fillTarget, bounds]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (editing) {
      if (e.key === 'Enter') {
        e.preventDefault();
        s.stopEdit(true);
        const { c, r } = s.sel.cursor;
        if (r + 1 < s.gridRows) s.setSel({ anchor: { c, r: r + 1 }, cursor: { c, r: r + 1 } });
      } else if (e.key === 'Tab') {
        e.preventDefault();
        s.stopEdit(true);
        const { c, r } = s.sel.cursor;
        const nc = e.shiftKey ? Math.max(0, c - 1) : Math.min(s.gridCols - 1, c + 1);
        s.setSel({ anchor: { c: nc, r }, cursor: { c: nc, r } });
      } else if (e.key === 'Escape') {
        e.preventDefault();
        s.stopEdit(false);
      }
      return;
    }

    const { c, r } = sel.cursor;
    const ctrl = e.ctrlKey || e.metaKey;

    switch (e.key) {
      case 'ArrowUp':
        e.preventDefault();
        if (e.shiftKey) s.setSel({ anchor: sel.anchor, cursor: { c, r: Math.max(0, r - 1) } });
        else if (r > 0) s.setSel({ anchor: { c, r: r - 1 }, cursor: { c, r: r - 1 } });
        break;
      case 'ArrowDown':
        e.preventDefault();
        if (e.shiftKey) s.setSel({ anchor: sel.anchor, cursor: { c, r: Math.min(gridRows - 1, r + 1) } });
        else if (r < gridRows - 1) s.setSel({ anchor: { c, r: r + 1 }, cursor: { c, r: r + 1 } });
        break;
      case 'ArrowLeft':
        e.preventDefault();
        if (e.shiftKey) s.setSel({ anchor: sel.anchor, cursor: { c: Math.max(0, c - 1), r } });
        else if (c > 0) s.setSel({ anchor: { c: c - 1, r }, cursor: { c: c - 1, r } });
        break;
      case 'ArrowRight':
        e.preventDefault();
        if (e.shiftKey) s.setSel({ anchor: sel.anchor, cursor: { c: Math.min(gridCols - 1, c + 1), r } });
        else if (c < gridCols - 1) s.setSel({ anchor: { c: c + 1, r }, cursor: { c: c + 1, r } });
        break;
      case 'Tab':
        e.preventDefault();
        {
          const nc = e.shiftKey ? Math.max(0, c - 1) : Math.min(gridCols - 1, c + 1);
          s.setSel({ anchor: { c: nc, r }, cursor: { c: nc, r } });
        }
        break;
      case 'Enter':
        e.preventDefault();
        s.startEdit();
        break;
      case 'Delete':
      case 'Backspace':
        e.preventDefault();
        s.snapshot();
        for (let rr = bounds.r1; rr <= bounds.r2; rr++) {
          for (let cc = bounds.c1; cc <= bounds.c2; cc++) {
            s.setCellRaw(cc, rr, '');
          }
        }
        break;
      case 'F2':
        e.preventDefault();
        s.startEdit();
        break;
      case 'Escape':
        if (s.formatPainter?.active) {
          e.preventDefault();
          s.deactivateFormatPainter();
          s.toast('Format Painter cancelled');
        }
        break;
      case 'f':
      case 'F':
        if (ctrl) {
          e.preventDefault();
          s.setModal('showFindModal', true);
        }
        break;
      case 'a':
      case 'A':
        if (ctrl) {
          e.preventDefault();
          s.selectSmartTableOrAll();
        }
        break;
      case 'z':
        if (ctrl) { e.preventDefault(); e.shiftKey ? s.redo() : s.undo(); }
        break;
      case 'y':
        if (ctrl) { e.preventDefault(); s.redo(); }
        break;
      case 'c':
        if (ctrl) { e.preventDefault(); s.copySel(); }
        break;
      case 'x':
        if (ctrl) { e.preventDefault(); s.cutSel(); }
        break;
      case 'v':
        if (ctrl) { e.preventDefault(); s.pasteSel(); }
        break;
      case 'b':
        if (ctrl) { e.preventDefault(); s.snapshot(); s.setFmtSel({ bold: !s.getCellFmt(c, r)?.bold }); }
        break;
      case 'i':
        if (ctrl) { e.preventDefault(); s.snapshot(); s.setFmtSel({ italic: !s.getCellFmt(c, r)?.italic }); }
        break;
      case 'u':
        if (ctrl) { e.preventDefault(); s.snapshot(); s.setFmtSel({ underline: !s.getCellFmt(c, r)?.underline }); }
        break;
      default:
        if (!ctrl && !e.altKey && e.key.length === 1 && !e.key.startsWith('F')) {
          e.preventDefault();
          s.startEdit(e.key);
        }
        break;
    }
  };

  useEffect(() => {
    if (!dragging) return;
    const mm = (e: MouseEvent) => {
      if (dragging === 'col') {
        const w = Math.max(MINCW, Math.min(MAXCW, dragStartSize + (e.clientX - dragStart)));
        s.setColW(dragIdx, w);
      } else {
        const h = Math.max(MINRH, Math.min(MAXRH, dragStartSize + (e.clientY - dragStart)));
        s.setRowH(dragIdx, h);
      }
    };
    const mu = () => setDragging(null);
    document.addEventListener('mousemove', mm);
    document.addEventListener('mouseup', mu);
    return () => {
      document.removeEventListener('mousemove', mm);
      document.removeEventListener('mouseup', mu);
    };
  }, [dragging, dragIdx, dragStart, dragStartSize]);

  const autoFitCol = (colIdx: number) => {
    let maxLen = 4;
    for (let r = 0; r < gridRows; r++) {
      const disp = s.getCellDisplay(colIdx, r);
      if (disp && disp.length > maxLen) maxLen = disp.length;
    }
    const calcW = Math.max(MINCW, Math.min(MAXCW, maxLen * 8 + 24));
    s.setColW(colIdx, calcW);
    s.toast(`Column ${colToLetter(colIdx)} auto-fitted`);
  };

  useEffect(() => {
    if (containerRef.current && !editing) containerRef.current.focus();
  }, [editing]);

  // Ensure cell editor caret is placed at the end when editing starts
  useEffect(() => {
    if (editing && editorRef.current) {
      editorRef.current.focus();
      const len = editorRef.current.value.length;
      editorRef.current.setSelectionRange(len, len);
    }
  }, [editing, s.editCell]);

  useEffect(() => {
    const w = gridRef.current; if (!w) return;
    const td = w.querySelector(`td[data-c="${sel.cursor.c}"][data-r="${sel.cursor.r}"]`) as HTMLElement | null;
    if (!td) return; const wr = w.getBoundingClientRect(), tr = td.getBoundingClientRect();
    if (tr.top < wr.top + 23) w.scrollTop -= wr.top + 22 - tr.top; else if (tr.bottom > wr.bottom) w.scrollTop += tr.bottom - wr.bottom;
    if (tr.left < wr.left + 41) w.scrollLeft -= wr.left + 40 - tr.left; else if (tr.right > wr.right) w.scrollLeft += tr.right - wr.right;
  }, [sel.cursor.c, sel.cursor.r]);

  const ctxA: Record<string, () => void> = {
    cut: () => s.cutSel(),
    copy: () => s.copySel(),
    paste: () => s.pasteSel(),
    bold: () => {
      s.snapshot();
      const current = s.getCellFmt(sel.cursor.c, sel.cursor.r)?.bold;
      s.setFmtSel({ bold: !current });
    },
    italic: () => {
      s.snapshot();
      const current = s.getCellFmt(sel.cursor.c, sel.cursor.r)?.italic;
      s.setFmtSel({ italic: !current });
    },
    underline: () => {
      s.snapshot();
      const current = s.getCellFmt(sel.cursor.c, sel.cursor.r)?.underline;
      s.setFmtSel({ underline: !current });
    },
    fmtNumber: () => {
      s.snapshot();
      s.setFmtSel({ numberFormat: 'number' });
    },
    fmtCurrency: () => {
      s.snapshot();
      s.setFmtSel({ numberFormat: 'currency' });
    },
    fmtPercent: () => {
      s.snapshot();
      s.setFmtSel({ numberFormat: 'percent' });
    },
    fmtInteger: () => {
      s.snapshot();
      s.setFmtSel({ numberFormat: 'integer' });
    },
    insertRowBelow: () => s.insertRowAt(sel.cursor.r + 1),
    insertColRight: () => s.insertColAt(sel.cursor.c + 1),
    deleteRow: () => s.deleteRowAt(sel.cursor.r),
    deleteCol: () => s.deleteColAt(sel.cursor.c),
    sortAsc: () => s.sortColumn(sel.cursor.c, true),
    sortDesc: () => s.sortColumn(sel.cursor.c, false),
    addComment: () => {
      const existing = s.getCellRaw(sel.cursor.c, sel.cursor.r);
      const val = prompt('Enter cell note / value:', existing);
      if (val !== null) {
        s.snapshot();
        s.setCellRaw(sel.cursor.c, sel.cursor.r, val);
      }
    },
    chartFromSelection: () => {
      s.setModal('showChartModal', true);
    },
    conditionalFormatting: () => {
      s.setFormatCellsTab('conditional');
      if (!s.showFormatCells) s.toggleFormatCells();
    },
    clearCells: () => {
      s.snapshot();
      for (let r = bounds.r1; r <= bounds.r2; r++) {
        for (let c = bounds.c1; c <= bounds.c2; c++) {
          s.setCellRaw(c, r, '');
        }
      }
      s.toast('Cleared selected cells');
    },
  };

  return (
    <div ref={containerRef} className="flex-1 flex flex-col overflow-hidden" onKeyDown={handleKeyDown} tabIndex={0}>
      <div
        ref={gridRef}
        id="grid-wrap"
        className={`grid-wrap${gridlines ? '' : ' hide-gridlines'}`}
        style={{
          cursor: s.formatPainter?.active ? 'crosshair' : dragging ? 'col-resize' : 'default',
          zoom: `${s.zoom}%`,
        }}
      >
        <table id="grid">
          <colgroup>
            <col style={{ width: 40 }} />
            {Array.from({ length: gridCols }, (_, c) => (
              <col key={c} style={{ width: cw[c] || DCW }} />
            ))}
          </colgroup>
          <thead>
            <tr>
              <th className="corner" style={{ width: 40, minWidth: 40, height: 22 }} />
              {Array.from({ length: gridCols }, (_, c) => (
                <th
                  key={c}
                  data-c={c}
                  className={`col${c >= bounds.c1 && c <= bounds.c2 ? ' hdr-sel' : ''}`}
                  style={{ height: 22 }}
                  onClick={e => {
                    if ((e.target as HTMLElement).classList.contains('col-resizer')) return;
                    s.setSel({ anchor: { c, r: 0 }, cursor: { c, r: gridRows - 1 } });
                  }}
                >
                  <div className="relative w-full h-full flex items-center justify-center">
                    {colToLetter(c)}
                    <div
                      className="col-resizer"
                      title="Double-click to auto-fit column width"
                      onMouseDown={e => {
                        e.preventDefault();
                        e.stopPropagation();
                        setDragging('col');
                        setDragIdx(c);
                        setDragStart(e.clientX);
                        setDragStartSize(cw[c] || DCW);
                      }}
                      onDoubleClick={e => {
                        e.preventDefault();
                        e.stopPropagation();
                        autoFitCol(c);
                      }}
                    />
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: gridRows }, (_, r) => {
              const rowH = rh[r] || DRH;
              const isFrozen = frozenRow && r === 0;

              return (
                <tr
                  key={r}
                  style={{
                    height: rowH,
                    position: isFrozen ? 'sticky' : undefined,
                    top: isFrozen ? 22 : undefined,
                    zIndex: isFrozen ? 3 : undefined,
                  }}
                >
                  <th
                    className={`row${r >= bounds.r1 && r <= bounds.r2 ? ' hdr-sel' : ''}`}
                    style={{ width: 40, minWidth: 40, background: isFrozen ? 'var(--header)' : undefined }}
                    onClick={() => s.setSel({ anchor: { c: 0, r }, cursor: { c: gridCols - 1, r } })}
                  >
                    <div className="relative w-full h-full flex items-center justify-center">
                      {r + 1}
                      <div
                        className="row-resizer"
                        onMouseDown={e => {
                          e.preventDefault();
                          e.stopPropagation();
                          setDragging('row');
                          setDragIdx(r);
                          setDragStart(e.clientY);
                          setDragStartSize(rowH);
                        }}
                      />
                    </div>
                  </th>
                  {Array.from({ length: gridCols }, (_, c) => {
                    const inSel = c >= bounds.c1 && c <= bounds.c2 && r >= bounds.r1 && r <= bounds.r2;
                    const inAutoFill =
                      autoFilling &&
                      fillTarget &&
                      c >= bounds.c1 &&
                      c <= fillTarget.c &&
                      r >= bounds.r1 &&
                      r <= fillTarget.r;

                    const isAnchor = c === sel.anchor.c && r === sel.anchor.r;
                    const isBottomRight = c === bounds.c2 && r === bounds.r2;
                    const isCursor = c === sel.cursor.c && r === sel.cursor.r;
                    const display = s.getCellDisplay(c, r);
                    const rawVal = s.getCellRaw(c, r);
                    const isFormula = rawVal.startsWith('=');
                    const cs = getCS(c, r);
                    const isEd = editing && isCursor;
                    const cellKStr = cellKey(c, r);
                    const formulaHl = highlightKeyMap.get(cellKStr);
                    const wizHl = wizardGridMap?.get(cellKStr);

                    return (
                      <td
                        key={c}
                        data-c={c}
                        data-r={r}
                        className={`${inSel && !formulaHl && !wizHl ? 'sel' : ''} ${isAnchor && !editing && !formulaHl && !wizHl ? 'anchor' : ''} ${
                          inAutoFill && !inSel ? 'bg-[var(--sel)] border-dashed border-[var(--accent)] opacity-80' : ''
                        }`}
                        style={{
                          height: rowH,
                          padding: '0 4px',
                          fontSize: '12.5px',
                          color: 'var(--text)',
                          verticalAlign: 'middle',
                          cursor: 'cell',
                          position: 'relative',
                          overflow: isEd ? 'visible' : 'hidden',
                          outline: wizHl
                            ? wizHl.border
                            : formulaHl
                            ? `2px solid ${formulaHl.borderColor}`
                            : isAnchor && !editing
                            ? '2px solid var(--selBorder)'
                            : undefined,
                          outlineOffset: '-2px',
                          background: wizHl
                            ? wizHl.bg
                            : formulaHl
                            ? formulaHl.bgColor
                            : inSel
                            ? 'var(--sel)'
                            : cs.background || undefined,
                          ...cs,
                        }}
                        onMouseDown={e => handleMouseDown(e, c, r)}
                        onMouseMove={e => handleMouseMove(e, c, r)}
                        onDoubleClick={() => s.startEdit(undefined, { c, r })}
                        onMouseEnter={e => {
                          if (isFormula && !editing) {
                            const rect = (e.target as HTMLElement).getBoundingClientRect();
                            setHoverTip({
                              c,
                              r,
                              raw: rawVal,
                              val: display,
                              x: rect.left,
                              y: rect.bottom + 4,
                            });
                          }
                        }}
                        onMouseLeave={() => setHoverTip(null)}
                        onContextMenu={e => {
                          e.preventDefault();
                          handleMouseDown(e, c, r);
                          s.setShowCtxMenu(true, { x: e.clientX, y: e.clientY });
                        }}
                      >
                        {isEd ? (
                          <div className="relative w-full h-full">
                            <textarea
                              ref={el => {
                                (editorRef as any).current = el;
                                if (el) {
                                  const len = el.value.length;
                                  el.setSelectionRange(len, len);
                                }
                              }}
                              className="cell-editor"
                              style={{ minWidth: cw[c] || DCW, minHeight: rowH, inset: 0 }}
                              value={editValue}
                              onChange={e => s.setEditVal(e.target.value)}
                              onFocus={e => {
                                const len = e.currentTarget.value.length;
                                e.currentTarget.setSelectionRange(len, len);
                              }}
                              onKeyDown={e => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  s.stopEdit(true);
                                  if (r + 1 < s.gridRows) {
                                    s.setSel({ anchor: { c, r: r + 1 }, cursor: { c, r: r + 1 } });
                                  }
                                } else if (e.key === 'Tab') {
                                  e.preventDefault();
                                  s.stopEdit(true);
                                  const nc = e.shiftKey ? Math.max(0, c - 1) : Math.min(s.gridCols - 1, c + 1);
                                  s.setSel({ anchor: { c: nc, r }, cursor: { c: nc, r } });
                                } else if (e.key === 'Escape') {
                                  e.preventDefault();
                                  s.stopEdit(false);
                                }
                                e.stopPropagation();
                              }}
                              autoFocus
                            />

                            {/* In-Cell Formula Autocomplete Suggestions Popup */}
                            {editValue.startsWith('=') && inCellSuggestions.length > 0 && (
                              <div
                                className="absolute top-full left-0 mt-1 bg-[var(--menu-bg)] border border-[var(--border)] rounded-md shadow-2xl z-50 min-w-[220px] max-h-44 overflow-auto py-1"
                                onClick={e => e.stopPropagation()}
                              >
                                {inCellSuggestions.map(fn => (
                                  <div
                                    key={fn.name}
                                    className="px-2.5 py-1 text-xs cursor-pointer flex items-center justify-between hover:bg-[var(--hover)]"
                                    onMouseDown={e => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      s.setEditVal(`=${fn.name}(`);
                                      if (editorRef.current) {
                                        editorRef.current.focus();
                                        const len = editorRef.current.value.length;
                                        editorRef.current.setSelectionRange(len, len);
                                      }
                                    }}
                                  >
                                    <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                                      {fn.name}
                                    </span>
                                    <span className="text-[10px] text-[var(--muted)]">{fn.category}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        ) : (
                          <span className="block truncate">{display}</span>
                        )}

                        {/* Auto-Fill Corner Drag Handle */}
                        {isBottomRight && !editing && (
                          <div
                            className="fill-handle"
                            onMouseDown={handleFillHandleDown}
                            title="Drag to auto-fill series or relative formulas"
                          />
                        )}

                        {/* Smart Quick-Analysis Floating Widget (Multi-Selection) */}
                        {isBottomRight && isMultiSelection && (
                          <div className="absolute -bottom-7 -right-1 z-30 flex items-center">
                            <button
                              type="button"
                              className={`w-6 h-6 rounded-md shadow-md flex items-center justify-center text-xs font-bold transition-all cursor-pointer ${
                                showQuickAnalysis
                                  ? 'bg-blue-600 text-white ring-2 ring-blue-400'
                                  : 'bg-[var(--panel)] border border-[var(--border)] text-[var(--text)] hover:bg-blue-50 hover:text-blue-600'
                              }`}
                              onClick={e => {
                                e.stopPropagation();
                                setShowQuickAnalysis(!showQuickAnalysis);
                              }}
                              title="Quick Analysis: 1-click Charts, AutoSum, and Visuals"
                            >
                              ⚡
                            </button>

                            {/* Quick Analysis Popover Menu */}
                            {showQuickAnalysis && (
                              <div
                                className="absolute top-7 right-0 bg-[var(--menu-bg)] border border-[var(--border)] rounded-xl shadow-2xl p-2 z-50 flex flex-col gap-1 w-44 animate-scale-in"
                                onClick={e => e.stopPropagation()}
                              >
                                <div className="text-[9.5px] font-bold text-[var(--muted)] uppercase px-1.5 py-0.5 border-b border-[var(--border)] mb-0.5">
                                  Quick Analysis
                                </div>
                                <button
                                  className="text-left text-xs px-2 py-1 rounded hover:bg-[var(--hover)] flex items-center gap-1.5 cursor-pointer"
                                  onClick={() => {
                                    s.addChart({
                                      id: `chart_${Date.now()}`,
                                      type: 'bar',
                                      title: 'Data Bar Chart',
                                      dataRange: `${cellRef(bounds.c1, bounds.r1)}:${cellRef(bounds.c2, bounds.r2)}`,
                                    });
                                    setShowQuickAnalysis(false);
                                    s.toast('Bar Chart created');
                                  }}
                                >
                                  <span>📊</span>
                                  <span>Bar Chart</span>
                                </button>
                                <button
                                  className="text-left text-xs px-2 py-1 rounded hover:bg-[var(--hover)] flex items-center gap-1.5 cursor-pointer"
                                  onClick={() => {
                                    s.addChart({
                                      id: `chart_${Date.now()}`,
                                      type: 'line',
                                      title: 'Trendline Chart',
                                      dataRange: `${cellRef(bounds.c1, bounds.r1)}:${cellRef(bounds.c2, bounds.r2)}`,
                                    });
                                    setShowQuickAnalysis(false);
                                    s.toast('Line Chart created');
                                  }}
                                >
                                  <span>📈</span>
                                  <span>Line Trend</span>
                                </button>
                                <button
                                  className="text-left text-xs px-2 py-1 rounded hover:bg-[var(--hover)] flex items-center gap-1.5 cursor-pointer"
                                  onClick={() => {
                                    const targetR = bounds.r2 + 1;
                                    if (targetR < s.gridRows) {
                                      s.snapshot();
                                      s.setCellRaw(
                                        bounds.c1,
                                        targetR,
                                        `=SUM(${cellRef(bounds.c1, bounds.r1)}:${cellRef(bounds.c1, bounds.r2)})`
                                      );
                                      s.toast('Inserted =SUM() below');
                                    }
                                    setShowQuickAnalysis(false);
                                  }}
                                >
                                  <span>Σ</span>
                                  <span>AutoSum Below</span>
                                </button>
                                <button
                                  className="text-left text-xs px-2 py-1 rounded hover:bg-[var(--hover)] flex items-center gap-1.5 cursor-pointer"
                                  onClick={() => {
                                    s.copySel();
                                    setShowQuickAnalysis(false);
                                  }}
                                >
                                  <span>📋</span>
                                  <span>Copy Data (TSV)</span>
                                </button>
                              </div>
                            )}
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Formula Hover Tooltip */}
      {hoverTip && (
        <div
          className="cell-tip shadow-lg"
          style={{ left: hoverTip.x, top: hoverTip.y, display: 'block' }}
        >
          <div className="font-semibold text-[var(--accent)] font-mono">{hoverTip.raw}</div>
          <div className="text-[10px] text-[var(--muted)]">Calculated: {String(hoverTip.val)}</div>
        </div>
      )}

      {/* 2-Column Optimized Context Menu (Matching Photo) */}
      {s.showCtxMenu && (
        <div
          className="ctx-menu show"
          style={{
            left: typeof window !== 'undefined' ? Math.max(10, Math.min(window.innerWidth - 410, s.ctxMenuPos.x)) : s.ctxMenuPos.x,
            top: typeof window !== 'undefined' ? Math.max(10, Math.min(window.innerHeight - 380, s.ctxMenuPos.y)) : s.ctxMenuPos.y,
          }}
          onClick={() => s.setShowCtxMenu(false)}
        >
          {/* Left Column */}
          <div className="ctx-col">
            {/* Selection Section */}
            <div className="ctx-section-header">SELECTION</div>
            <div className="ctx-item" onClick={() => ctxA.copy()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon">📄</span>
                <span>Copy</span>
              </div>
              <span className="ctx-shortcut">Ctrl+C</span>
            </div>
            <div className="ctx-item" onClick={() => ctxA.cut()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon">✂️</span>
                <span>Cut</span>
              </div>
              <span className="ctx-shortcut">Ctrl+X</span>
            </div>
            <div
              className={`ctx-item${!s.clipboard ? ' disabled' : ''}`}
              onClick={() => ctxA.paste()}
            >
              <div className="ctx-item-left">
                <span className="ctx-item-icon">📋</span>
                <span>Paste</span>
              </div>
              <span className="ctx-shortcut">Ctrl+V</span>
            </div>

            {/* Format Section */}
            <div className="ctx-section-header mt-1">FORMAT</div>
            <div className="ctx-item" onClick={() => ctxA.bold()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon font-bold font-serif text-xs">B</span>
                <span>Bold</span>
              </div>
            </div>
            <div className="ctx-item" onClick={() => ctxA.italic()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon italic font-serif text-xs">I</span>
                <span>Italic</span>
              </div>
            </div>
            <div className="ctx-item" onClick={() => ctxA.underline()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon underline font-serif text-xs">U</span>
                <span>Underline</span>
              </div>
            </div>

            {/* Number Format Section */}
            <div className="ctx-section-header mt-1">NUMBER FORMAT</div>
            <div className="ctx-item" onClick={() => ctxA.fmtNumber()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon font-mono font-bold text-xs">#</span>
                <span>Number (1,234.00)</span>
              </div>
            </div>
            <div className="ctx-item" onClick={() => ctxA.fmtCurrency()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon font-mono font-bold text-xs">$</span>
                <span>Currency (USD)</span>
              </div>
            </div>
            <div className="ctx-item" onClick={() => ctxA.fmtPercent()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon font-mono font-bold text-xs">%</span>
                <span>Percentage</span>
              </div>
            </div>
            <div className="ctx-item" onClick={() => ctxA.fmtInteger()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon font-mono font-bold text-xs">0</span>
                <span>Integer</span>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="ctx-col">
            {/* Rows & Columns Section */}
            <div className="ctx-section-header">ROWS & COLUMNS</div>
            <div className="ctx-item" onClick={() => ctxA.insertRowBelow()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon font-bold text-emerald-600">+</span>
                <span>Insert Row Below</span>
              </div>
            </div>
            <div className="ctx-item" onClick={() => ctxA.insertColRight()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon font-bold text-emerald-600">+</span>
                <span>Insert Column Right</span>
              </div>
            </div>
            <div className="ctx-item ctx-danger" onClick={() => ctxA.deleteRow()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon font-bold">−</span>
                <span>Delete Row</span>
              </div>
            </div>
            <div className="ctx-item ctx-danger" onClick={() => ctxA.deleteCol()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon font-bold">−</span>
                <span>Delete Column</span>
              </div>
            </div>

            {/* Sort Section */}
            <div className="ctx-section-header mt-1">SORT</div>
            <div className="ctx-item" onClick={() => ctxA.sortAsc()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon font-bold">↑</span>
                <span>Sort A → Z (col)</span>
              </div>
            </div>
            <div className="ctx-item" onClick={() => ctxA.sortDesc()}>
              <div className="ctx-item-left">
                <span className="ctx-item-icon font-bold">↓</span>
                <span>Sort Z → A (col)</span>
              </div>
            </div>

            {/* Actions Section */}
            <div className="mt-1 border-t border-[var(--border)] pt-1">
              <div className="ctx-item" onClick={() => ctxA.addComment()}>
                <div className="ctx-item-left">
                  <span className="ctx-item-icon">💭</span>
                  <span>Add/Edit Comment</span>
                </div>
              </div>
              <div className="ctx-item" onClick={() => ctxA.chartFromSelection()}>
                <div className="ctx-item-left">
                  <span className="ctx-item-icon">📊</span>
                  <span>Chart from Selection</span>
                </div>
              </div>
              <div className="ctx-item" onClick={() => ctxA.conditionalFormatting()}>
                <div className="ctx-item-left">
                  <span className="ctx-item-icon text-amber-500">⚡</span>
                  <span>Conditional Formatting...</span>
                </div>
              </div>
              <div className="ctx-item ctx-danger" onClick={() => ctxA.clearCells()}>
                <div className="ctx-item-left">
                  <span className="ctx-item-icon">🧹</span>
                  <span>Clear Cells</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ===== SHEET TABS =====
function SheetTabs() {
  const s = useStore();
  const [renaming, setRenaming] = useState<number | null>(null);
  const [rv, setRv] = useState('');

  return (
    <div className="sheet-tabs">
      {s.sheets.map((sh, i) => (
        <div
          key={i}
          className={`sheet-tab${i === s.activeSheet ? ' active' : ''}`}
          onClick={() => s.setActiveSheet(i)}
          onDoubleClick={e => {
            e.stopPropagation();
            setRenaming(i);
            setRv(sh.name);
          }}
        >
          {renaming === i ? (
            <input
              className="bg-[var(--panel)] border border-[var(--accent)] rounded px-1.5 py-0 text-[11px] outline-none w-24"
              style={{ color: 'var(--text)' }}
              value={rv}
              onChange={e => setRv(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  if (rv.trim()) s.renameSheet(i, rv.trim());
                  setRenaming(null);
                }
                if (e.key === 'Escape') setRenaming(null);
              }}
              onBlur={() => {
                if (rv.trim()) s.renameSheet(i, rv.trim());
                setRenaming(null);
              }}
              autoFocus
              onClick={e => e.stopPropagation()}
            />
          ) : (
            <span>{sh.name}</span>
          )}
          {s.sheets.length > 1 && (
            <span
              className="x ml-1"
              onClick={e => {
                e.stopPropagation();
                s.snapshot();
                s.removeSheet(i);
              }}
              title="Delete Sheet"
            >
              ×
            </span>
          )}
        </div>
      ))}
      <button className="btn icon text-xs" onClick={() => s.addSheet()} title="Add New Sheet" style={{ color: 'var(--muted)' }}>
        +
      </button>
    </div>
  );
}

// ===== STATUS BAR WITH CLICKABLE FORMULA INSERTER =====
function StatusBar() {
  const s = useStore();
  const bounds = selBounds(s.sel);
  const single = bounds.c1 === bounds.c2 && bounds.r1 === bounds.r2;

  let sum = 0, cnt = 0, ncnt = 0, mn = Infinity, mx = -Infinity;
  if (!single) {
    for (let r = bounds.r1; r <= bounds.r2; r++) {
      for (let c = bounds.c1; c <= bounds.c2; c++) {
        const v = s.getCellValue(c, r);
        if (v != null && v !== '') {
          cnt++;
          const n = typeof v === 'number' ? v : parseFloat(v);
          if (!isNaN(n)) {
            sum += n;
            ncnt++;
            if (n < mn) mn = n;
            if (n > mx) mx = n;
          }
        }
      }
    }
  }

  const avg = ncnt > 0 ? sum / ncnt : 0;
  const cc = (bounds.c2 - bounds.c1 + 1) * (bounds.r2 - bounds.r1 + 1);

  const handleStatClick = (fn: string, val: number, e: React.MouseEvent) => {
    if (e.shiftKey) {
      navigator.clipboard.writeText(String(val)).catch(() => {});
      s.toast(`📋 Copied ${fn} (${val}) to clipboard`);
      return;
    }
    const targetR = bounds.r2 + 1;
    if (targetR >= s.gridRows) {
      s.toast('No room below selection to insert formula');
      return;
    }
    const rangeStr = `${cellRef(bounds.c1, bounds.r1)}:${cellRef(bounds.c1, bounds.r2)}`;
    const formula = `=${fn}(${rangeStr})`;
    s.snapshot();
    s.setCellRaw(bounds.c1, targetR, formula);
    s.setSel({ anchor: { c: bounds.c1, r: targetR }, cursor: { c: bounds.c1, r: targetR } });
    s.toast(`Inserted ${formula} at ${cellRef(bounds.c1, targetR)}`);
  };

  return (
    <div className="flex items-center gap-3 px-3 py-1 bg-[var(--panel)] border-t border-[var(--border)] text-[11px] select-none" style={{ color: 'var(--muted)' }}>
      {single ? (
        <span>Ready</span>
      ) : (
        <>
          <span>Cells: <b>{cc}</b></span>
          {ncnt > 0 && (
            <>
              <span
                className="stat-click"
                title="Click to insert =SUM() below selection, Shift+Click to copy"
                onClick={e => handleStatClick('SUM', sum, e)}
              >
                Σ {sum % 1 === 0 ? sum : sum.toFixed(2)}
              </span>
              <span
                className="stat-click"
                title="Click to insert =AVERAGE() below selection, Shift+Click to copy"
                onClick={e => handleStatClick('AVERAGE', avg, e)}
              >
                Avg {avg.toFixed(2)}
              </span>
              <span
                className="stat-click"
                title="Click to insert =COUNT() below selection, Shift+Click to copy"
                onClick={e => handleStatClick('COUNT', cnt, e)}
              >
                Count {cnt}
              </span>
              <span>Min {mn === Infinity ? '-' : String(mn)}</span>
              <span>Max {mx === -Infinity ? '-' : String(mx)}</span>
            </>
          )}
        </>
      )}
      {/* Active Format Painter Banner */}
      {s.formatPainter?.active && (
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 text-[10.5px] font-semibold animate-pulse">
          <span>🖌️ Painter Active {s.formatPainter.isLocked ? '(Locked)' : ''}</span>
          <button
            className="hover:text-red-500 font-bold ml-1 cursor-pointer"
            onClick={() => s.deactivateFormatPainter()}
            title="Cancel format painter (Esc)"
          >
            ✕
          </button>
        </div>
      )}

      <div className="flex-1 flex items-center justify-center"><a href="https://grmagazin.blogspot.com/p/donate.html" target="_blank" rel="noopener noreferrer" className="text-[11px] font-semibold hover:underline cursor-pointer hover:text-red-500" style={{ color: 'var(--muted)' }} title="Support this app ❤️ (opens in new tab)">❤️ Support App</a></div>

      {/* Interactive Zoom Controls */}
      <div className="flex items-center gap-1.5 border-l border-[var(--border)] pl-2.5">
        <button
          className="w-4 h-4 rounded flex items-center justify-center font-bold text-xs hover:bg-[var(--hover)] cursor-pointer"
          onClick={() => s.setZoom(s.zoom - 10)}
          title="Zoom Out (10%)"
        >
          −
        </button>
        <span
          className="font-mono text-[10.5px] text-[var(--text)] font-semibold w-10 text-center cursor-pointer hover:underline"
          onClick={() => s.setZoom(100)}
          title="Click to reset zoom to 100%"
        >
          {s.zoom}%
        </span>
        <button
          className="w-4 h-4 rounded flex items-center justify-center font-bold text-xs hover:bg-[var(--hover)] cursor-pointer"
          onClick={() => s.setZoom(s.zoom + 10)}
          title="Zoom In (10%)"
        >
          +
        </button>
      </div>

      <span className="text-[10px] opacity-70 hidden md:inline">GRmagazin Ncalc v3</span>
    </div>
  );
}

// ===== CHARTS PANEL =====
import ChartPanel from './components/ChartPanel';

// ===== MODAL WRAPPER =====
function ModalWrap({
  show,
  onClose,
  title,
  children,
  wide,
}: {
  show: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (show) document.addEventListener('keydown', h);
    return () => document.removeEventListener('keydown', h);
  }, [show, onClose]);

  if (!show) return null;
  return (
    <div className="modal-back" onClick={onClose}>
      <div className={`modal${wide ? ' w-[min(900px,94vw)]' : ''}`} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3 border-b border-[var(--border)] pb-2">
          <h2 className="text-sm font-semibold" style={{ color: 'var(--text)' }}>
            {title}
          </h2>
          <button
            type="button"
            className="w-7 h-7 rounded-md flex items-center justify-center hover:bg-[var(--hover)] text-[var(--muted)] hover:text-[var(--text)] text-sm font-bold cursor-pointer transition-colors"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            title="Close (Escape)"
          >
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ===== TEMPLATES MODAL (BUILT-IN + USER SAVED TEMPLATES) =====
function TemplateModal() {
  const s = useStore();
  const [tplTab, setTplTab] = useState<'presets' | 'user'>('presets');
  const [customName, setCustomName] = useState('');

  const handleSaveCurrent = () => {
    if (!customName.trim()) {
      s.toast('Please provide a template title');
      return;
    }
    s.saveAsCustomTemplate(customName.trim());
    setCustomName('');
    setTplTab('user');
  };

  const applyCustomTpl = (t: Template) => {
    s.snapshot();
    if (t.sheets) {
      useStore.setState({
        sheets: JSON.parse(JSON.stringify(t.sheets)),
        charts: JSON.parse(JSON.stringify(t.charts || [])),
        activeSheet: 0,
        sel: { anchor: { c: 0, r: 0 }, cursor: { c: 0, r: 0 } },
      });
      s.toast(`Applied custom template "${t.name}"`);
    } else if (t.data) {
      s.applyTpl(t.data);
      s.toast(`Applied template "${t.name}"`);
    }
    s.setModal('showTplModal', false);
  };

  return (
    <ModalWrap show={s.showTplModal} onClose={() => s.setModal('showTplModal', false)} title="Spreadsheet Templates Library" wide>
      <div className="space-y-4">
        {/* Sub-tabs */}
        <div className="flex items-center justify-between border-b border-[var(--border)] pb-2">
          <div className="flex items-center gap-2">
            <button
              className={`px-3 py-1 text-xs rounded font-medium ${
                tplTab === 'presets'
                  ? 'bg-[var(--accent)] text-white'
                  : 'bg-[var(--panel-2)] text-[var(--muted)] hover:bg-[var(--hover)]'
              }`}
              onClick={() => setTplTab('presets')}
            >
              Preset Business Templates ({BUILTIN_TEMPLATES.length})
            </button>
            <button
              className={`px-3 py-1 text-xs rounded font-medium ${
                tplTab === 'user'
                  ? 'bg-[var(--accent)] text-white'
                  : 'bg-[var(--panel-2)] text-[var(--muted)] hover:bg-[var(--hover)]'
              }`}
              onClick={() => setTplTab('user')}
            >
              My Saved Templates ({s.userTemplates.length})
            </button>
          </div>

          {/* Quick Save Current Sheet as Template */}
          <div className="flex items-center gap-1.5">
            <input
              className="text-xs px-2 py-1 bg-[var(--panel)] border border-[var(--border)] rounded outline-none w-44"
              placeholder="New template name..."
              value={customName}
              onChange={e => setCustomName(e.target.value)}
            />
            <button
              className="px-2.5 py-1 text-xs rounded font-medium bg-[var(--accent)] text-white hover:opacity-90"
              onClick={handleSaveCurrent}
            >
              Save As Template
            </button>
          </div>
        </div>

        {/* Presets View */}
        {tplTab === 'presets' && (
          <div className="tpl-grid">
            {BUILTIN_TEMPLATES.map((t, i) => (
              <div
                key={i}
                className="tpl-card"
                onClick={() => {
                  s.snapshot();
                  s.applyTpl(t.data || []);
                  s.setModal('showTplModal', false);
                  s.toast(`Loaded preset: ${t.name}`);
                }}
              >
                <span className="icon">{t.icon}</span>
                <span className="name">{t.name}</span>
                {t.desc && <span className="text-[10px] text-[var(--muted)] mt-1 px-1">{t.desc}</span>}
              </div>
            ))}
          </div>
        )}

        {/* User Saved Templates View */}
        {tplTab === 'user' && (
          <div>
            {s.userTemplates.length === 0 ? (
              <div className="text-center py-8 text-xs text-[var(--muted)]">
                You haven't saved any custom templates yet.<br />
                Type a name above and click <b>"Save As Template"</b> to save your current layout & sheets!
              </div>
            ) : (
              <div className="tpl-grid">
                {s.userTemplates.map(t => (
                  <div
                    key={t.id}
                    className="tpl-card relative group"
                    onClick={() => applyCustomTpl(t)}
                  >
                    <button
                      className="absolute top-1 right-1 text-[11px] text-gray-400 hover:text-red-500 px-1 rounded hover:bg-black/5"
                      onClick={e => {
                        e.stopPropagation();
                        if (t.id) s.deleteCustomTemplate(t.id);
                      }}
                      title="Delete Template"
                    >
                      ✕
                    </button>
                    <span className="icon">{t.icon || '📑'}</span>
                    <span className="name">{t.name}</span>
                    <span className="text-[9px] text-[var(--muted)] mt-1">
                      {t.sheets?.length || 1} Sheet(s) · {t.charts?.length || 0} Chart(s)
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </ModalWrap>
  );
}

// ===== P3.2: NAME MANAGER MODAL (DEFINED NAMED RANGES) =====
function NameManagerModal() {
  const s = useStore();
  const [nameInput, setNameInput] = useState('');
  const [rangeInput, setRangeInput] = useState('');
  const [commentInput, setCommentInput] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);

  const detectedRange = useMemo(() => getDetectedTableRange(s), [s.sel, s.sheets, s.activeSheet, s.showNameManagerModal]);

  useEffect(() => {
    if (s.showNameManagerModal && !editingId) {
      setRangeInput(detectedRange);
      setNameInput('');
      setCommentInput('');
    }
  }, [s.showNameManagerModal, detectedRange, editingId]);

  if (!s.showNameManagerModal) return null;

  const existingOtherNames = editingId
    ? s.namedRanges.filter(nr => nr.id !== editingId).map(nr => nr.name)
    : s.namedRanges.map(nr => nr.name);

  const validation = nameInput.trim() ? isValidNamedRangeName(nameInput.trim(), existingOtherNames) : { valid: true };

  const handleSave = () => {
    if (!nameInput.trim()) {
      s.toast('Please enter a valid range name');
      return;
    }
    if (!validation.valid) {
      s.toast(`Cannot save: ${validation.error}`);
      return;
    }

    if (editingId) {
      const ok = s.updateNamedRange(editingId, {
        name: nameInput.trim(),
        range: rangeInput.trim().toUpperCase(),
        comment: commentInput.trim(),
      });
      if (ok) {
        setEditingId(null);
        setNameInput('');
        setCommentInput('');
      }
    } else {
      const ok = s.addNamedRange(nameInput.trim(), rangeInput.trim().toUpperCase(), commentInput.trim());
      if (ok) {
        setNameInput('');
        setCommentInput('');
      }
    }
  };

  const handleEditClick = (nr: NamedRange) => {
    setEditingId(nr.id);
    setNameInput(nr.name);
    setRangeInput(nr.range);
    setCommentInput(nr.comment || '');
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setNameInput('');
    setRangeInput(detectedRange);
    setCommentInput('');
  };

  return (
    <ModalWrap
      show={s.showNameManagerModal}
      onClose={() => s.setShowNameManagerModal(false)}
      title="Name Manager — Defined Named Ranges (P3.2)"
      wide
    >
      <div className="space-y-4">
        {/* Form to Add / Edit Named Range */}
        <div className="p-3.5 rounded-xl border border-[var(--border)] bg-[var(--panel-2)] space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[var(--text)] flex items-center gap-1.5">
              <span>🏷️</span>
              <span>{editingId ? 'Edit Named Range' : 'Define New Named Range'}</span>
            </span>
            {editingId && (
              <button
                type="button"
                className="text-[11px] text-gray-500 hover:underline cursor-pointer"
                onClick={handleCancelEdit}
              >
                Cancel Edit
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-[10px] font-bold text-[var(--muted)] uppercase block mb-1">
                Name (e.g. SalesData)
              </label>
              <input
                type="text"
                className={`w-full text-xs px-2.5 py-1.5 rounded-lg border bg-[var(--panel)] outline-none font-semibold ${
                  nameInput && !validation.valid
                    ? 'border-red-500 text-red-600'
                    : 'border-[var(--border)] text-[var(--text)] focus:border-purple-500'
                }`}
                placeholder="e.g. SalesData, TaxRate"
                value={nameInput}
                onChange={e => setNameInput(e.target.value)}
              />
              {nameInput && !validation.valid && (
                <div className="text-[10px] text-red-500 mt-1">{validation.error}</div>
              )}
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-[var(--muted)] uppercase">
                  Refers to (Range)
                </label>
                <button
                  type="button"
                  className="text-[9.5px] text-blue-600 hover:underline cursor-pointer"
                  onClick={() => setRangeInput(detectedRange)}
                >
                  Use Selection ({detectedRange})
                </button>
              </div>
              <input
                type="text"
                className="w-full text-xs font-mono font-bold px-2.5 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel)] text-[var(--accent)] outline-none focus:border-purple-500"
                placeholder="e.g. B2:B50"
                value={rangeInput}
                onChange={e => setRangeInput(e.target.value)}
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-[var(--muted)] uppercase block mb-1">
                Comment (Optional)
              </label>
              <input
                type="text"
                className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel)] text-[var(--text)] outline-none focus:border-purple-500"
                placeholder="e.g. Total quarterly sales column"
                value={commentInput}
                onChange={e => setCommentInput(e.target.value)}
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              className="px-4 py-1.5 rounded-lg font-bold text-xs text-white bg-purple-600 hover:bg-purple-700 active:scale-95 shadow-xs transition-all cursor-pointer"
              onClick={handleSave}
            >
              {editingId ? '✓ Update Named Range' : '+ Add Named Range'}
            </button>
          </div>
        </div>

        {/* Existing Named Ranges Table */}
        <div className="border border-[var(--border)] rounded-xl overflow-hidden">
          <div className="bg-[var(--panel-2)] px-4 py-2 text-xs font-bold text-[var(--text)] border-b border-[var(--border)] flex items-center justify-between">
            <span>Defined Names ({s.namedRanges.length})</span>
            <span className="text-[10.5px] font-normal text-[var(--muted)]">
              Use in formulas like <code className="font-mono bg-black/5 px-1 py-0.5 rounded">=SUM(SalesData)</code>
            </span>
          </div>

          {s.namedRanges.length === 0 ? (
            <div className="text-center py-8 text-xs text-[var(--muted)]">
              No named ranges defined yet. Enter a name above (e.g. <b>SalesData</b>) and select a cell range!
            </div>
          ) : (
            <table className="w-full text-xs text-left">
              <thead className="bg-[var(--header)] text-[var(--muted)] text-[10.5px] border-b border-[var(--border)]">
                <tr>
                  <th className="p-2.5 font-semibold">Name</th>
                  <th className="p-2.5 font-semibold">Refers To</th>
                  <th className="p-2.5 font-semibold">Comment</th>
                  <th className="p-2.5 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--border)] text-[var(--text)]">
                {s.namedRanges.map(nr => (
                  <tr key={nr.id} className="hover:bg-[var(--hover)]">
                    <td className="p-2.5 font-mono font-bold text-purple-600 dark:text-purple-400">
                      {nr.name}
                    </td>
                    <td className="p-2.5 font-mono text-[var(--accent)] font-semibold">
                      {nr.range}
                    </td>
                    <td className="p-2.5 text-[var(--muted)]">
                      {nr.comment || '—'}
                    </td>
                    <td className="p-2.5 text-right space-x-1.5">
                      <button
                        type="button"
                        className="px-2 py-1 text-[11px] rounded border border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--hover)] cursor-pointer"
                        onClick={() => handleEditClick(nr)}
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        className="px-2 py-1 text-[11px] rounded border border-red-200 bg-red-50 text-red-600 hover:bg-red-100 cursor-pointer"
                        onClick={() => s.deleteNamedRange(nr.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </ModalWrap>
  );
}

// ===== CHART MODAL (AUTO-DETECTS SELECTED DATA RANGE) =====
function ChartModal() {
  const s = useStore();
  const types = [
    { type: 'bar', label: 'Bar', icon: '📊' },
    { type: 'line', label: 'Line', icon: '📈' },
    { type: 'pie', label: 'Pie', icon: '🥧' },
    { type: 'area', label: 'Area', icon: '📉' },
    { type: 'scatter', label: 'Scatter', icon: '⚬' },
    { type: 'radar', label: 'Radar', icon: '🕸️' },
  ];

  // Auto-detect selected or surrounding data range
  const detectedRange = useMemo(() => getDetectedTableRange(s), [s.sel, s.sheets, s.activeSheet, s.showChartModal]);
  const [rv, setRv] = useState(detectedRange);
  const [tv, setTv] = useState('Data Summary');

  useEffect(() => {
    setRv(detectedRange);
  }, [detectedRange, s.showChartModal]);

  return (
    <ModalWrap show={s.showChartModal} onClose={() => s.setModal('showChartModal', false)} title="Insert Chart Visualizer">
      <div className="space-y-3">
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted)' }}>
            Choose Visualization Type
          </label>
          <div className="grid grid-cols-6 gap-1.5">
            {types.map(ct => (
              <button
                key={ct.type}
                className={`ct-card${s.modalChartType === ct.type ? ' active' : ''}`}
                onClick={() => s.setChartType(ct.type)}
              >
                <span className="text-xl">{ct.icon}</span>
                <span className="text-xs">{ct.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-xs font-medium" style={{ color: 'var(--muted)' }}>
              Data Cell Range
            </label>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold bg-emerald-50 dark:bg-emerald-950/40 px-1.5 py-0.5 rounded flex items-center gap-1">
              ✓ Auto-detected from active selection: <b>{detectedRange}</b>
            </span>
          </div>
          <div className="flex items-center gap-2">
            <input
              className="flex-1 font-mono text-xs px-2.5 py-1.5 outline-none font-bold"
              style={{
                background: 'var(--panel)',
                border: '1px solid var(--border)',
                borderRadius: '.3rem',
                color: 'var(--accent)',
              }}
              value={rv}
              onChange={e => setRv(e.target.value)}
              placeholder="e.g. A1:E6"
            />
            <button
              className="px-2.5 py-1.5 text-xs rounded border border-[var(--border)] bg-[var(--panel-2)] hover:bg-[var(--hover)]"
              onClick={() => setRv(detectedRange)}
              title="Reset to selected cell range"
            >
              Use Selected Range
            </button>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted)' }}>
            Chart Title
          </label>
          <input
            className="w-full text-xs px-2.5 py-1.5 outline-none"
            style={{
              background: 'var(--panel)',
              border: '1px solid var(--border)',
              borderRadius: '.3rem',
              color: 'var(--text)',
            }}
            value={tv}
            onChange={e => setTv(e.target.value)}
          />
        </div>
        <button
          className="w-full py-2 rounded text-xs font-semibold text-white shadow-sm hover:opacity-95 transition"
          style={{ background: 'var(--accent)' }}
          onClick={() => {
            s.addChart({
              id: `chart_${Date.now()}`,
              type: s.modalChartType as any,
              title: tv || 'Chart',
              dataRange: rv || detectedRange,
            });
            s.setModal('showChartModal', false);
            s.toast(`Added ${s.modalChartType.toUpperCase()} Chart (${rv || detectedRange})`);
          }}
        >
          Create & View Chart
        </button>
      </div>
    </ModalWrap>
  );
}

// ===== THEMES MODAL =====
function ThemeModal() {
  const s = useStore();
  const lt = THEMES.filter(t => t.group === 'light');
  const dt = THEMES.filter(t => t.group === 'dark');

  const TG = ({ themes, label, icon }: { themes: ThemeDef[]; label: string; icon: string }) => (
    <div>
      <h3 className="text-xs font-semibold mb-2" style={{ color: 'var(--text)' }}>
        {icon} {label}
      </h3>
      <div className="grid grid-cols-3 gap-2">
        {themes.map(t => (
          <button
            key={t.key}
            className={`flex items-center gap-2 p-2 border rounded cursor-pointer transition-all${
              s.theme === t.key ? ' border-[var(--accent)] ring-2 ring-[var(--accent)]/30' : ''
            }`}
            style={{ background: t.vars.bg, borderColor: s.theme === t.key ? 'var(--accent)' : 'var(--border)' }}
            onClick={() => s.setTheme(t.key)}
          >
            <div className="w-6 h-6 rounded border flex items-center justify-center" style={{ background: t.vars.panel, borderColor: t.vars.border }}>
              <div className="w-3 h-3 rounded-xs" style={{ background: t.vars.accent }} />
            </div>
            <span className="text-[11px] font-medium" style={{ color: t.vars.text }}>
              {t.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <ModalWrap show={s.showThemeModal} onClose={() => s.setModal('showThemeModal', false)} title="Themes Palette (12 Styles)" wide>
      <div className="space-y-4">
        <TG themes={lt} label="Light Themes" icon="☀️" />
        <TG themes={dt} label="Dark Themes" icon="🌙" />
      </div>
    </ModalWrap>
  );
}

// ===== FIND & REPLACE MODAL =====
function FindReplaceModal() {
  const s = useStore();
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [matchCase, setMatchCase] = useState(false);
  const [allCells, setAllCells] = useState(true);

  const handleReplace = () => {
    const count = s.findAndReplace(findText, replaceText, matchCase, allCells);
    s.toast(count > 0 ? `Replaced ${count} occurrence(s)` : 'No matching text found');
  };

  return (
    <ModalWrap show={s.showFindModal} onClose={() => s.setModal('showFindModal', false)} title="Find and Replace">
      <div className="space-y-3">
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted)' }}>Find</label>
          <input
            className="w-full text-xs px-2.5 py-1.5 outline-none"
            style={{ background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: '.3rem', color: 'var(--text)' }}
            value={findText}
            onChange={e => setFindText(e.target.value)}
            placeholder="Text to find..."
            autoFocus
          />
        </div>
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted)' }}>Replace with</label>
          <input
            className="w-full text-xs px-2.5 py-1.5 outline-none"
            style={{ background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: '.3rem', color: 'var(--text)' }}
            value={replaceText}
            onChange={e => setReplaceText(e.target.value)}
            placeholder="New text..."
          />
        </div>
        <div className="flex gap-4 text-xs" style={{ color: 'var(--text)' }}>
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input type="checkbox" checked={matchCase} onChange={e => setMatchCase(e.target.checked)} />
            Match case
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input type="checkbox" checked={allCells} onChange={e => setAllCells(e.target.checked)} />
            Entire Sheet (uncheck for selection only)
          </label>
        </div>
        <div className="flex gap-2 pt-2">
          <button
            className="flex-1 py-1.5 rounded text-xs font-semibold text-white"
            style={{ background: 'var(--accent)' }}
            onClick={handleReplace}
          >
            Replace All
          </button>
        </div>
      </div>
    </ModalWrap>
  );
}

// ===== RESIZE MODAL =====
function ResizeModal() {
  const s = useStore();
  const [rows, setRows] = useState(s.gridRows);
  const [cols, setCols] = useState(s.gridCols);

  return (
    <ModalWrap show={s.showResizeModal} onClose={() => s.setModal('showResizeModal', false)} title="Resize Grid Dimensions">
      <div className="space-y-3">
        <div className="flex gap-3">
          <div className="flex-1">
            <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted)' }}>Total Rows (5 - 500)</label>
            <input
              type="number"
              className="w-full text-xs px-2.5 py-1.5 outline-none"
              style={{ background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: '.3rem', color: 'var(--text)' }}
              value={rows}
              min={5}
              max={500}
              onChange={e => setRows(parseInt(e.target.value) || 50)}
            />
          </div>
          <div className="flex-1">
            <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted)' }}>Total Columns (5 - 100)</label>
            <input
              type="number"
              className="w-full text-xs px-2.5 py-1.5 outline-none"
              style={{ background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: '.3rem', color: 'var(--text)' }}
              value={cols}
              min={5}
              max={100}
              onChange={e => setCols(parseInt(e.target.value) || 26)}
            />
          </div>
        </div>
        <button
          className="w-full py-2 rounded text-xs font-semibold text-white"
          style={{ background: 'var(--accent)' }}
          onClick={() => {
            s.resizeGrid(Math.max(5, Math.min(500, rows)), Math.max(5, Math.min(100, cols)));
            s.setModal('showResizeModal', false);
            s.toast(`Grid dimension set to ${rows} rows × ${cols} cols`);
          }}
        >
          Apply New Dimensions
        </button>
      </div>
    </ModalWrap>
  );
}

// ===== ERROR CONSOLE MODAL =====
function ErrorModal() {
  const s = useStore();
  const errors = s.scanErrors();

  return (
    <ModalWrap show={s.showErrModal} onClose={() => s.setModal('showErrModal', false)} title="Formula Error Diagnostics">
      <div>
        {errors.length === 0 ? (
          <div className="text-center py-6" style={{ color: 'var(--muted)', fontSize: 13 }}>
            ✅ All formula references and calculations in <b>{s.sheet().name}</b> are valid!
          </div>
        ) : (
          <>
            <div className="mb-3 text-xs" style={{ color: 'var(--muted)' }}>
              Found <b>{errors.length}</b> formula calculation issue(s). Click any row to focus the cell.
            </div>
            <div className="max-h-72 overflow-auto space-y-1">
              {errors.map((e, i) => (
                <div
                  key={i}
                  className="err-row rounded p-2"
                  onClick={() => {
                    const parsed = parseRange(`${e.cell}:${e.cell}`);
                    if (parsed) {
                      s.setSel({ anchor: { c: parsed.c1, r: parsed.r1 }, cursor: { c: parsed.c1, r: parsed.r1 } });
                      s.setModal('showErrModal', false);
                      s.startEdit();
                    }
                  }}
                >
                  <span className="cell">{e.cell}</span>
                  <span className="formula">{e.formula}</span>
                  <span className="error">{e.error}</span>
                  <span className="help">{e.help}</span>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </ModalWrap>
  );
}

// ===== ABOUT MODAL =====
function AboutModal() {
  const s = useStore();
  return (
    <ModalWrap
      show={s.showAboutModal}
      onClose={() => s.setModal('showAboutModal', false)}
      title="About GRmagazin Sheets — Ncalc v3"
    >
      <div className="text-center space-y-3.5 py-2">
        <div
          className="inline-flex px-3.5 py-2 rounded-xl items-center justify-center font-bold text-lg shadow-md tracking-tight"
          style={{ background: 'var(--accent)', color: 'white' }}
        >
          GRmagazin
        </div>
        <h3 className="text-base font-bold text-[var(--text)]">
          GRmagazin Sheets — Ncalc v3
        </h3>
        <p className="text-xs max-w-md mx-auto text-[var(--muted)] leading-relaxed">
          A modern, fast, and stable spreadsheet web application with <b>Excel Ribbon Tabs</b>, calculation engine, interactive visualizations, and automatic data recovery.
        </p>
        <div className="text-[11px] grid grid-cols-2 gap-2 text-left bg-[var(--panel-2)] p-3 rounded-lg border border-[var(--border)] text-[var(--text)]">
          <div>📁 <b>File</b>: New, Import CSV/JSON, Export, Print, Snapshots.</div>
          <div>✏️ <b>Edit</b>: Clipboard, Painter 🖌️, Font, Align, Borders.</div>
          <div>➕ <b>Insert</b>: 6 Chart types, Templates, Sheet controls.</div>
          <div>🔢 <b>Data</b>: Sheet Size (Rows & Cols), Pivot Panel, Sort.</div>
          <div>ƒx <b>Functions</b>: 65+ Formula functions, Formula Builder.</div>
          <div>👁️ <b>View</b>: Format Cells 📝, Bulk Edit 🎨, 12 Themes.</div>
        </div>
        <div className="flex items-center justify-center gap-3 pt-1">
          <button
            type="button"
            className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
            onClick={() => s.setModal('showAboutModal', false)}
          >
            OK / Close
          </button>
        </div>
        <p className="text-[10px] text-[var(--muted)] opacity-70">
          React 19 + TypeScript + Zustand + Apache ECharts + Tailwind CSS
        </p>
      </div>
    </ModalWrap>
  );
}

import BulkEditPanel from './components/BulkEditPanel'; import BorderEditPanel from './components/BorderEditPanel';

// ===== FORMAT CELLS PANEL (Right Sidebar Slider) =====
function FormatCellsPanel() {
  const s = useStore();
  const [isDragging, setIsDragging] = useState(false);
  const startXRef = useRef(0);
  const startWRef = useRef(0);

  // Active cell format
  const fmt = s.getCellFmt(s.sel.cursor.c, s.sel.cursor.r) || {};

  // Local state for interactive changes
  const [activeNumberFormat, setActiveNumberFormat] = useState(fmt.numberFormat || '');
  const [activeBgColor, setActiveBgColor] = useState(fmt.bgColor || '');
  const [activeTextColor, setActiveTextColor] = useState(fmt.color || '');
  const [activeAlign, setActiveAlign] = useState<'left' | 'center' | 'right' | 'justify'>(
    (fmt.align as any) || 'left'
  );
  const [activeFontFamily, setActiveFontFamily] = useState(fmt.fontFamily || 'Arial');
  const [activeFontSize, setActiveFontSize] = useState(fmt.fontSize || 12);
  const [activeBold, setActiveBold] = useState(!!fmt.bold);
  const [activeItalic, setActiveItalic] = useState(!!fmt.italic);
  const [activeUnderline, setActiveUnderline] = useState(!!fmt.underline);
  const [activeWrap, setActiveWrap] = useState(!!fmt.wrap);

  // Border tab state
  const { borderEditState } = s;

  // Conditional tab state
  const [condRule, setCondRule] = useState<'gt' | 'lt' | 'eq' | 'contains'>('gt');
  const [condVal, setCondVal] = useState('100');
  const [condColor, setCondColor] = useState<'green' | 'red' | 'yellow'>('green');

  // Validation tab state
  const [validType, setValidType] = useState<'list' | 'number'>('list');
  const [validItems, setValidItems] = useState('Approved, Pending, Rejected');

  // Sync with cell selection
  useEffect(() => {
    const currentFmt = s.getCellFmt(s.sel.cursor.c, s.sel.cursor.r) || {};
    setActiveNumberFormat(currentFmt.numberFormat || '');
    setActiveBgColor(currentFmt.bgColor || '');
    setActiveTextColor(currentFmt.color || '');
    setActiveAlign((currentFmt.align as any) || 'left');
    setActiveFontFamily(currentFmt.fontFamily || 'Arial');
    setActiveFontSize(currentFmt.fontSize || 12);
    setActiveBold(!!currentFmt.bold);
    setActiveItalic(!!currentFmt.italic);
    setActiveUnderline(!!currentFmt.underline);
    setActiveWrap(!!currentFmt.wrap);
  }, [s.sel, s.sheets, s.activeSheet]);

  const handleSplitterDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    startXRef.current = e.clientX;
    startWRef.current = s.formatCellsWidth;
  };

  useEffect(() => {
    if (!isDragging) return;
    const handleMM = (e: MouseEvent) => {
      const delta = startXRef.current - e.clientX;
      s.setFormatCellsWidth(startWRef.current + delta);
    };
    const handleMU = () => setIsDragging(false);
    document.addEventListener('mousemove', handleMM);
    document.addEventListener('mouseup', handleMU);
    return () => {
      document.removeEventListener('mousemove', handleMM);
      document.removeEventListener('mouseup', handleMU);
    };
  }, [isDragging, s]);

  if (!s.showFormatCells) return null;

  // Color Swatches matching photo
  const bgSwatches = [
    '#ffffff', '#fef9c3', '#dcfce7', '#dbeafe', '#fce7f3', '#fee2e2', '#ede9fe',
    '#ffedd5', '#f1f5f9', '#e0e7ff', '#ccfbf1', '#1e293b',
  ];

  const textSwatches = [
    '#000000', '#1e293b', '#2563eb', '#16a34a', '#dc2626', '#7c3aed', '#c2410c',
    '#0891b2', '#475569', '#ffffff',
  ];

  const borderColors = [
    '#000000', '#1f2937', '#2563eb', '#16a34a', '#dc2626', '#7c3aed', '#c2410c', '#0891b2',
    '#475569', '#ffffff',
  ];

  const handleApplyFormatting = () => {
    s.snapshot();
    const patch: Partial<CellFormat> = {
      numberFormat: activeNumberFormat || undefined,
      bgColor: activeBgColor || undefined,
      color: activeTextColor || undefined,
      align: activeAlign === 'justify' ? 'left' : activeAlign,
      fontFamily: activeFontFamily,
      fontSize: activeFontSize,
      bold: activeBold,
      italic: activeItalic,
      underline: activeUnderline,
      wrap: activeWrap,
    };
    s.setFmtSel(patch);
    s.toast('Format applied to selection');
  };

  const handleApplyConditional = () => {
    s.snapshot();
    const b = selBounds(s.sel);
    const bg = condColor === 'green' ? '#dcfce7' : condColor === 'red' ? '#fee2e2' : '#fef9c3';
    const text = condColor === 'green' ? '#166534' : condColor === 'red' ? '#991b1b' : '#854d0e';
    for (let r = b.r1; r <= b.r2; r++) {
      for (let c = b.c1; c <= b.c2; c++) {
        const val = s.getCellValue(c, r);
        const num = typeof val === 'number' ? val : parseFloat(val);
        const targetNum = parseFloat(condVal);
        let match = false;
        if (!isNaN(num) && !isNaN(targetNum)) {
          if (condRule === 'gt' && num > targetNum) match = true;
          if (condRule === 'lt' && num < targetNum) match = true;
          if (condRule === 'eq' && num === targetNum) match = true;
        }
        if (condRule === 'contains' && String(val).toLowerCase().includes(condVal.toLowerCase())) {
          match = true;
        }
        if (match) {
          s.setCellFmt(c, r, { bgColor: bg, color: text });
        }
      }
    }
    s.toast('Conditional formatting applied');
  };

  const handleApplyValidation = () => {
    s.snapshot();
    const b = selBounds(s.sel);
    if (validType === 'list') {
      const items = validItems.split(',').map(i => i.trim()).filter(Boolean);
      for (let r = b.r1; r <= b.r2; r++) {
        for (let c = b.c1; c <= b.c2; c++) {
          if (!s.getCellRaw(c, r) && items.length > 0) {
            s.setCellRaw(c, r, items[0]);
          }
        }
      }
      s.toast(`Validation list (${items.join(', ')}) set`);
    }
  };

  const tabs: { id: typeof s.formatCellsTab; label: string }[] = [
    { id: 'number', label: 'Number' },
    { id: 'font', label: 'Font' },
    { id: 'colors', label: 'Colors' },
    { id: 'align', label: 'Align' },
    { id: 'border', label: 'Border' },
    { id: 'conditional', label: 'Conditional' },
    { id: 'validation', label: 'Validation' },
  ];

  return (
    <>
      {/* Draggable Splitter */}
      <div
        id="splitter"
        className={isDragging ? 'dragging' : ''}
        onMouseDown={handleSplitterDown}
        onDoubleClick={() => { s.setFormatCellsWidth(320); s.toast('Reset format panel width to 320px'); }}
        title="Drag to resize panel, double-click to reset"
      />

      <div
        style={{
          width: s.formatCellsWidth,
          flexShrink: 0,
          background: 'var(--panel)',
          borderLeft: '1px solid var(--border)',
          overflow: 'auto',
          padding: 12,
          display: 'flex',
          flexDirection: 'column',
          gap: 10,
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-[var(--border)]">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-xs">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <line x1="4" y1="21" x2="4" y2="14" />
                <line x1="4" y1="10" x2="4" y2="3" />
                <line x1="12" y1="21" x2="12" y2="12" />
                <line x1="12" y1="8" x2="12" y2="3" />
                <line x1="20" y1="21" x2="20" y2="16" />
                <line x1="20" y1="12" x2="20" y2="3" />
                <line x1="1" y1="14" x2="7" y2="14" />
                <line x1="9" y1="8" x2="15" y2="8" />
                <line x1="17" y1="16" x2="23" y2="16" />
              </svg>
            </div>
            <div>
              <div className="font-bold text-xs text-[var(--text)]">Format Cells</div>
              <div className="text-[10px] text-[var(--muted)]">Style your selection</div>
            </div>
          </div>
          <button
            className="text-[var(--muted)] hover:text-red-500 text-sm px-1.5 py-0.5 rounded hover:bg-[var(--hover)]"
            onClick={() => s.toggleFormatCells()}
          >
            ✕
          </button>
        </div>

        {/* LIVE PREVIEW BOX */}
        <div>
          <div className="text-[9.5px] font-bold text-[var(--muted)] uppercase tracking-wider mb-1">
            LIVE PREVIEW
          </div>
          <div
            className="w-full h-14 rounded-lg border border-[var(--border)] flex items-center justify-center px-3 shadow-xs transition-all"
            style={{
              background: activeBgColor || '#f8fafc',
              color: activeTextColor || '#111827',
              fontFamily: activeFontFamily,
              fontSize: `${Math.min(18, Math.max(11, activeFontSize))}px`,
              fontWeight: activeBold ? 'bold' : 'normal',
              fontStyle: activeItalic ? 'italic' : 'normal',
              textDecoration: activeUnderline ? 'underline' : 'none',
              textAlign: activeAlign === 'justify' ? 'left' : activeAlign,
              border:
                s.formatCellsTab === 'border'
                  ? `${borderEditState.thickness} ${borderEditState.lineStyle} ${borderEditState.color}`
                  : '1px solid var(--border)',
            }}
          >
            <span className="truncate">
              {activeNumberFormat === 'currency'
                ? '$1,234.56'
                : activeNumberFormat === 'percent'
                ? '85.5%'
                : activeNumberFormat === 'integer'
                ? '1,235'
                : activeNumberFormat === 'number'
                ? '1,234.56'
                : 'Aa Bb 1234'}
            </span>
          </div>
        </div>

        {/* SUB-TABS NAVIGATION (matching photo) */}
        <div className="flex items-center gap-1 border-b border-[var(--border)] pb-1 overflow-x-auto text-[11px]">
          {tabs.map(tab => (
            <button
              key={tab.id}
              className={`px-2 py-1 rounded-md transition-all font-medium whitespace-nowrap ${
                s.formatCellsTab === tab.id
                  ? 'bg-blue-50 text-blue-600 font-bold dark:bg-blue-950/50 dark:text-blue-400 border-b-2 border-blue-600'
                  : 'text-[var(--muted)] hover:bg-[var(--hover)] hover:text-[var(--text)]'
              }`}
              onClick={() => s.setFormatCellsTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* ===== TAB 1: NUMBER FORMAT ===== */}
        {s.formatCellsTab === 'number' && (
          <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
            {[
              { val: '', label: 'General', sub: '1234.56', icon: '#' },
              { val: 'number', label: 'Number', sub: '1,234.56', icon: '#' },
              { val: 'currency', label: 'Currency', sub: '$1,234.56', icon: '$' },
              { val: 'percent', label: 'Percent', sub: '85.5%', icon: '%' },
              { val: 'integer', label: 'Integer', sub: '1,235', icon: '#' },
              { val: 'date', label: 'Date', sub: '2024-01-15', icon: '📅' },
              { val: 'scientific', label: 'Scientific', sub: '1.23e+4', icon: 'e' },
            ].map(item => (
              <button
                key={item.val}
                className={`w-full flex items-center gap-3 p-2 rounded-lg border text-left transition-all ${
                  activeNumberFormat === item.val
                    ? 'border-blue-500 bg-blue-50/70 dark:bg-blue-950/40 shadow-xs'
                    : 'border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--hover)]'
                }`}
                onClick={() => {
                  setActiveNumberFormat(item.val);
                  s.snapshot();
                  s.setFmtSel({ numberFormat: item.val || undefined });
                }}
              >
                <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-300 font-bold flex items-center justify-center text-xs flex-shrink-0">
                  {item.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-semibold text-[var(--text)]">{item.label}</div>
                  <div className="text-[10px] text-[var(--muted)] font-mono">{item.sub}</div>
                </div>
                {activeNumberFormat === item.val && (
                  <span className="text-blue-600 font-bold text-xs">✓</span>
                )}
              </button>
            ))}
          </div>
        )}

        {/* ===== TAB 2: FONT ===== */}
        {s.formatCellsTab === 'font' && (
          <div className="space-y-3">
            <div>
              <label className="text-[10px] font-bold text-[var(--muted)] uppercase block mb-1">
                Font Family
              </label>
              <select
                className="w-full text-xs p-2 rounded border border-[var(--border)] bg-[var(--panel)] outline-none"
                value={activeFontFamily}
                onChange={e => {
                  setActiveFontFamily(e.target.value);
                  s.snapshot();
                  s.setFmtSel({ fontFamily: e.target.value });
                }}
              >
                {FONT_FAMILIES.map(f => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-[var(--muted)] uppercase block mb-1">
                Font Style
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                <button
                  className={`py-2 rounded border text-xs font-bold ${
                    activeBold ? 'border-blue-600 bg-blue-50 text-blue-600' : 'border-[var(--border)]'
                  }`}
                  onClick={() => {
                    setActiveBold(!activeBold);
                    s.snapshot();
                    s.setFmtSel({ bold: !activeBold });
                  }}
                >
                  B
                </button>
                <button
                  className={`py-2 rounded border text-xs italic ${
                    activeItalic ? 'border-blue-600 bg-blue-50 text-blue-600' : 'border-[var(--border)]'
                  }`}
                  onClick={() => {
                    setActiveItalic(!activeItalic);
                    s.snapshot();
                    s.setFmtSel({ italic: !activeItalic });
                  }}
                >
                  I
                </button>
                <button
                  className={`py-2 rounded border text-xs underline ${
                    activeUnderline ? 'border-blue-600 bg-blue-50 text-blue-600' : 'border-[var(--border)]'
                  }`}
                  onClick={() => {
                    setActiveUnderline(!activeUnderline);
                    s.snapshot();
                    s.setFmtSel({ underline: !activeUnderline });
                  }}
                >
                  U
                </button>
                <button
                  className={`py-2 rounded border text-xs line-through ${
                    fmt.strikethrough ? 'border-blue-600 bg-blue-50 text-blue-600' : 'border-[var(--border)]'
                  }`}
                  onClick={() => {
                    s.snapshot();
                    s.setFmtSel({ strikethrough: !fmt.strikethrough });
                  }}
                >
                  S
                </button>
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-[var(--muted)] uppercase block mb-1">
                Font Size
              </label>
              <select
                className="w-full text-xs p-2 rounded border border-[var(--border)] bg-[var(--panel)] outline-none"
                value={activeFontSize}
                onChange={e => {
                  const sz = parseInt(e.target.value);
                  setActiveFontSize(sz);
                  s.snapshot();
                  s.setFmtSel({ fontSize: sz });
                }}
              >
                {FONT_SIZES.map(sz => (
                  <option key={sz} value={sz}>{sz} px</option>
                ))}
              </select>
            </div>
          </div>
        )}

        {/* ===== TAB 3: COLORS ===== */}
        {s.formatCellsTab === 'colors' && (
          <div className="space-y-3">
            {/* Background Color */}
            <div>
              <div className="flex items-center gap-1 text-[10px] font-bold text-blue-600 uppercase mb-1.5">
                <span>🧹</span>
                <span>BACKGROUND</span>
              </div>
              <div className="grid grid-cols-7 gap-1.5">
                {bgSwatches.map((col, idx) => (
                  <button
                    key={idx}
                    className={`w-7 h-7 rounded-md border-2 transition-transform hover:scale-110 ${
                      activeBgColor === col ? 'border-blue-600 ring-2 ring-blue-400' : 'border-gray-200'
                    }`}
                    style={{ background: col }}
                    onClick={() => {
                      setActiveBgColor(col);
                      s.snapshot();
                      s.setFmtSel({ bgColor: col });
                    }}
                  />
                ))}
                <button
                  className="w-7 h-7 rounded-md border border-[var(--border)] flex items-center justify-center text-xs hover:bg-[var(--hover)]"
                  onClick={() => {
                    const input = document.createElement('input');
                    input.type = 'color';
                    input.onchange = (e: any) => {
                      setActiveBgColor(e.target.value);
                      s.snapshot();
                      s.setFmtSel({ bgColor: e.target.value });
                    };
                    input.click();
                  }}
                  title="Custom background color"
                >
                  🎨
                </button>
              </div>
            </div>

            {/* Text Color */}
            <div>
              <div className="flex items-center gap-1 text-[10px] font-bold text-blue-600 uppercase mb-1.5">
                <span>T</span>
                <span>TEXT COLOR</span>
              </div>
              <div className="grid grid-cols-7 gap-1.5">
                {textSwatches.map((col, idx) => (
                  <button
                    key={idx}
                    className={`w-7 h-7 rounded-md border-2 transition-transform hover:scale-110 ${
                      activeTextColor === col ? 'border-blue-600 ring-2 ring-blue-400' : 'border-gray-200'
                    }`}
                    style={{ background: col }}
                    onClick={() => {
                      setActiveTextColor(col);
                      s.snapshot();
                      s.setFmtSel({ color: col });
                    }}
                  />
                ))}
                <button
                  className="w-7 h-7 rounded-md border border-[var(--border)] flex items-center justify-center text-xs hover:bg-[var(--hover)]"
                  onClick={() => {
                    const input = document.createElement('input');
                    input.type = 'color';
                    input.onchange = (e: any) => {
                      setActiveTextColor(e.target.value);
                      s.snapshot();
                      s.setFmtSel({ color: e.target.value });
                    };
                    input.click();
                  }}
                  title="Custom text color"
                >
                  🎨
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ===== TAB 4: ALIGN ===== */}
        {s.formatCellsTab === 'align' && (
          <div className="space-y-3">
            <div>
              <div className="text-[10px] font-bold text-[var(--muted)] uppercase mb-1.5">
                HORIZONTAL
              </div>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'left', label: 'Left', icon: 'M3 6h18M3 12h10M3 18h14' },
                  { id: 'center', label: 'Center', icon: 'M3 6h18M6 12h12M4 18h16' },
                  { id: 'right', label: 'Right', icon: 'M3 6h18M11 12h10M7 18h14' },
                  { id: 'justify', label: 'Justify', icon: 'M3 6h18M3 12h18M3 18h18' },
                ].map(item => (
                  <button
                    key={item.id}
                    className={`py-2.5 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                      activeAlign === item.id
                        ? 'border-blue-600 bg-blue-600 text-white shadow-xs'
                        : 'border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--hover)] text-[var(--text)]'
                    }`}
                    onClick={() => {
                      setActiveAlign(item.id as any);
                      s.snapshot();
                      s.setFmtSel({ align: item.id === 'justify' ? 'left' : (item.id as any) });
                    }}
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                      <path d={item.icon} />
                    </svg>
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="text-[10px] font-bold text-[var(--muted)] uppercase mb-1.5">
                TEXT CONTROL
              </div>
              <div className="grid grid-cols-3 gap-2">
                <button
                  className={`py-2 rounded-lg border text-xs font-medium flex flex-col items-center gap-1 ${
                    activeWrap ? 'border-blue-600 bg-blue-50 text-blue-600 font-bold' : 'border-[var(--border)]'
                  }`}
                  onClick={() => {
                    setActiveWrap(!activeWrap);
                    s.snapshot();
                    s.setFmtSel({ wrap: !activeWrap });
                  }}
                >
                  <span>↩️</span>
                  <span>Wrap</span>
                </button>
                <button
                  className="py-2 rounded-lg border border-[var(--border)] text-xs font-medium flex flex-col items-center gap-1 hover:bg-[var(--hover)]"
                  onClick={() => s.toast('Indent decreased')}
                >
                  <span>⇦</span>
                  <span>Out</span>
                </button>
                <button
                  className="py-2 rounded-lg border border-[var(--border)] text-xs font-medium flex flex-col items-center gap-1 hover:bg-[var(--hover)]"
                  onClick={() => s.toast('Indent increased')}
                >
                  <span>⇨</span>
                  <span>In</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ===== TAB 5: BORDER (BORDER EDIT MATCHING PHOTO) ===== */}
        {s.formatCellsTab === 'border' && (
          <div className="space-y-3">
            {/* Border Position */}
            <div>
              <div className="text-[10px] font-bold text-[var(--muted)] uppercase mb-1.5">
                BORDER POSITION
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { id: 'none', label: 'None', icon: '◻️' },
                  { id: 'outline', label: 'Outline', icon: '🔲' },
                  { id: 'inside', label: 'Inside', icon: '⧉' },
                  { id: 'all', label: 'All', icon: '▦' },
                  { id: 'top', label: 'Top', icon: '▔' },
                  { id: 'bottom', label: 'Bottom', icon: ' ' },
                  { id: 'left', label: 'Left', icon: '▏' },
                  { id: 'right', label: 'Right', icon: '▕' },
                ].map(item => (
                  <button
                    key={item.id}
                    className={`py-2 px-1 rounded-lg border text-xs font-medium flex flex-col items-center justify-center gap-1 transition-all ${
                      borderEditState.position === item.id
                        ? 'border-blue-600 bg-blue-600 text-white font-bold'
                        : 'border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--hover)]'
                    }`}
                    onClick={() => s.updateBorderEditState({ position: item.id as any })}
                  >
                    <span className="text-base leading-none">{item.icon}</span>
                    <span className="text-[10px]">{item.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Line Style */}
            <div>
              <div className="text-[10px] font-bold text-[var(--muted)] uppercase mb-1.5">
                LINE STYLE
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'solid', label: 'Solid', borderStyle: 'solid' },
                  { id: 'dashed', label: 'Dashed', borderStyle: 'dashed' },
                  { id: 'dotted', label: 'Dotted', borderStyle: 'dotted' },
                ].map(styleItem => (
                  <button
                    key={styleItem.id}
                    className={`py-2 px-2 rounded-lg border text-xs font-medium flex flex-col items-center justify-center gap-1 ${
                      borderEditState.lineStyle === styleItem.id
                        ? 'border-blue-600 bg-blue-600 text-white font-bold'
                        : 'border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--hover)]'
                    }`}
                    onClick={() => s.updateBorderEditState({ lineStyle: styleItem.id as any })}
                  >
                    <div
                      className="w-full h-0 border-t-2"
                      style={{
                        borderStyle: styleItem.borderStyle,
                        borderColor: borderEditState.lineStyle === styleItem.id ? 'white' : '#111827',
                      }}
                    />
                    <span className="text-[10px]">{styleItem.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Thickness */}
            <div>
              <div className="text-[10px] font-bold text-[var(--muted)] uppercase mb-1.5">
                THICKNESS
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {['1px', '2px', '3px'].map(th => (
                  <button
                    key={th}
                    className={`py-1.5 rounded-lg border text-xs font-semibold ${
                      borderEditState.thickness === th
                        ? 'border-blue-600 bg-blue-600 text-white'
                        : 'border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--hover)]'
                    }`}
                    onClick={() => s.updateBorderEditState({ thickness: th as any })}
                  >
                    {th}
                  </button>
                ))}
              </div>
            </div>

            {/* Color */}
            <div>
              <div className="text-[10px] font-bold text-[var(--muted)] uppercase mb-1.5">
                COLOR
              </div>
              <div className="grid grid-cols-6 gap-1.5">
                {borderColors.map((col, idx) => (
                  <button
                    key={idx}
                    className={`w-7 h-7 rounded-md border-2 transition-transform hover:scale-110 ${
                      borderEditState.color === col ? 'border-blue-600 ring-2 ring-blue-400' : 'border-gray-200'
                    }`}
                    style={{ background: col }}
                    onClick={() => s.updateBorderEditState({ color: col })}
                  />
                ))}
              </div>
            </div>

            {/* Border Action Buttons (Matching Photo) */}
            <div className="flex gap-2 pt-2 border-t border-[var(--border)]">
              <button
                className="flex-1 py-1.5 text-xs rounded border border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--hover)]"
                onClick={() => {
                  s.snapshot();
                  s.setFmtSel({ border: undefined });
                  s.toast('Borders cleared');
                }}
              >
                🧹 Clear
              </button>
              <button
                className="flex-1 py-1.5 text-xs rounded font-semibold text-white bg-emerald-600 hover:bg-emerald-700"
                onClick={() => s.applyBorderEdit()}
              >
                ⚡ Smart Apply
              </button>
              <button
                className="flex-1 py-1.5 text-xs rounded font-semibold text-white bg-blue-600 hover:bg-blue-700"
                onClick={() => s.applyBorderEdit()}
              >
                Apply
              </button>
            </div>
          </div>
        )}

        {/* ===== TAB 6: CONDITIONAL FORMATTING ===== */}
        {s.formatCellsTab === 'conditional' && (
          <div className="space-y-3">
            <div>
              <label className="text-[10px] font-bold text-[var(--muted)] uppercase block mb-1">
                Format Cells If
              </label>
              <select
                className="w-full text-xs p-2 rounded border border-[var(--border)] bg-[var(--panel)] outline-none"
                value={condRule}
                onChange={(e: any) => setCondRule(e.target.value)}
              >
                <option value="gt">Greater Than (&gt;)</option>
                <option value="lt">Less Than (&lt;)</option>
                <option value="eq">Equal To (=)</option>
                <option value="contains">Text Contains</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-[var(--muted)] uppercase block mb-1">
                Value or Threshold
              </label>
              <input
                className="w-full text-xs p-2 rounded border border-[var(--border)] bg-[var(--panel)] outline-none"
                value={condVal}
                onChange={e => setCondVal(e.target.value)}
                placeholder="e.g. 100 or Pass"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-[var(--muted)] uppercase block mb-1">
                Highlight Style
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  className={`py-2 rounded border text-xs font-medium ${
                    condColor === 'green' ? 'border-emerald-600 bg-emerald-100 text-emerald-800' : 'border-[var(--border)]'
                  }`}
                  onClick={() => setCondColor('green')}
                >
                  🟢 Green
                </button>
                <button
                  className={`py-2 rounded border text-xs font-medium ${
                    condColor === 'red' ? 'border-red-600 bg-red-100 text-red-800' : 'border-[var(--border)]'
                  }`}
                  onClick={() => setCondColor('red')}
                >
                  🔴 Red
                </button>
                <button
                  className={`py-2 rounded border text-xs font-medium ${
                    condColor === 'yellow' ? 'border-yellow-600 bg-yellow-100 text-yellow-800' : 'border-[var(--border)]'
                  }`}
                  onClick={() => setCondColor('yellow')}
                >
                  🟡 Yellow
                </button>
              </div>
            </div>

            <button
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg mt-2"
              onClick={handleApplyConditional}
            >
              Apply Conditional Formatting
            </button>
          </div>
        )}

        {/* ===== TAB 7: DATA VALIDATION ===== */}
        {s.formatCellsTab === 'validation' && (
          <div className="space-y-3">
            <div>
              <label className="text-[10px] font-bold text-[var(--muted)] uppercase block mb-1">
                Validation Criteria
              </label>
              <select
                className="w-full text-xs p-2 rounded border border-[var(--border)] bg-[var(--panel)] outline-none"
                value={validType}
                onChange={(e: any) => setValidType(e.target.value)}
              >
                <option value="list">Dropdown List of Items</option>
                <option value="number">Numeric Range (Min / Max)</option>
              </select>
            </div>

            {validType === 'list' && (
              <div>
                <label className="text-[10px] font-bold text-[var(--muted)] uppercase block mb-1">
                  List Items (comma-separated)
                </label>
                <input
                  className="w-full text-xs p-2 rounded border border-[var(--border)] bg-[var(--panel)] outline-none"
                  value={validItems}
                  onChange={e => setValidItems(e.target.value)}
                  placeholder="e.g. In Progress, Done, Review"
                />
              </div>
            )}

            <button
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg mt-2"
              onClick={handleApplyValidation}
            >
              Set Cell Validation Rule
            </button>
          </div>
        )}

        {/* FOOTER BAR (Reset & Clear All Formatting matching photo) */}
        <div className="flex items-center gap-2 pt-2 mt-auto border-t border-[var(--border)]">
          <button
            className="px-3 py-2 text-xs rounded-lg border border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--hover)] flex items-center justify-center gap-1 font-medium"
            onClick={() => {
              const currentFmt = s.getCellFmt(s.sel.cursor.c, s.sel.cursor.r) || {};
              setActiveNumberFormat(currentFmt.numberFormat || '');
              setActiveBgColor(currentFmt.bgColor || '');
              setActiveTextColor(currentFmt.color || '');
              setActiveAlign((currentFmt.align as any) || 'left');
              setActiveFontFamily(currentFmt.fontFamily || 'Arial');
              setActiveFontSize(currentFmt.fontSize || 12);
              setActiveBold(!!currentFmt.bold);
              setActiveItalic(!!currentFmt.italic);
              setActiveUnderline(!!currentFmt.underline);
              s.toast('Format settings reset');
            }}
          >
            <span>↺</span>
            <span>Reset</span>
          </button>
          <button
            className="flex-1 py-2 text-xs rounded-lg border border-red-200 bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-300 dark:border-red-900/60 font-semibold hover:bg-red-100 flex items-center justify-center gap-1"
            onClick={() => s.clearFormattingSelection()}
          >
            <span>⌫</span>
            <span>Clear All Formatting</span>
          </button>
        </div>

        {/* Global Apply Button */}
        {s.formatCellsTab !== 'border' && s.formatCellsTab !== 'conditional' && s.formatCellsTab !== 'validation' && (
          <button
            className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs"
            onClick={handleApplyFormatting}
          >
            ✓ Apply to Selection
          </button>
        )}
      </div>
    </>
  );
}

// FormulaBuilderPanel extracted to src/components/FormulaBuilderPanel.tsx

// ===== PIVOT PANEL (Right Sidebar Slider) =====
function PivotPanel() {
  const s = useStore();
  const [isDragging, setIsDragging] = useState(false);
  const startXRef = useRef(0);
  const startWRef = useRef(0);

  // Auto-detect contiguous source range if not set
  const detectedRange = useMemo(() => getDetectedTableRange(s), [s.sel, s.sheets, s.activeSheet, s.showPivotPanel]);

  useEffect(() => {
    if (!s.pivotConfig.sourceRange && s.showPivotPanel) {
      s.updatePivotConfig({ sourceRange: detectedRange });
    }
  }, [detectedRange, s.showPivotPanel]);

  const activeRangeStr = s.pivotConfig.sourceRange || detectedRange;
  const parsedRange = parseRange(activeRangeStr);

  // Parse header column fields from source range
  const availableFields: string[] = useMemo(() => {
    if (!parsedRange) return [];
    const fields: string[] = [];
    for (let c = parsedRange.c1; c <= parsedRange.c2; c++) {
      const hVal = String(s.getCellValue(c, parsedRange.r1) || colToLetter(c));
      fields.push(hVal);
    }
    return fields;
  }, [parsedRange, s.sheets, s.activeSheet]);

  // Set default field selections when fields change
  useEffect(() => {
    if (availableFields.length > 0) {
      const updates: Partial<typeof s.pivotConfig> = {};
      if (!s.pivotConfig.rowField || !availableFields.includes(s.pivotConfig.rowField)) {
        updates.rowField = availableFields[0];
      }
      if (!s.pivotConfig.valField || !availableFields.includes(s.pivotConfig.valField)) {
        updates.valField = availableFields[availableFields.length - 1];
      }
      if (Object.keys(updates).length > 0) {
        s.updatePivotConfig(updates);
      }
    }
  }, [availableFields]);

  const handleSplitterDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    startXRef.current = e.clientX;
    startWRef.current = s.pivotPanelWidth;
  };

  useEffect(() => {
    if (!isDragging) return;
    const handleMM = (e: MouseEvent) => {
      const delta = startXRef.current - e.clientX;
      s.setPivotPanelWidth(startWRef.current + delta);
    };
    const handleMU = () => setIsDragging(false);
    document.addEventListener('mousemove', handleMM);
    document.addEventListener('mouseup', handleMU);
    return () => {
      document.removeEventListener('mousemove', handleMM);
      document.removeEventListener('mouseup', handleMU);
    };
  }, [isDragging, s]);

  if (!s.showPivotPanel) return null;

  // Compute live mini-preview data
  const previewData = (() => {
    if (!parsedRange || availableFields.length === 0) return null;
    const headers: { col: number; name: string }[] = [];
    for (let c = parsedRange.c1; c <= parsedRange.c2; c++) {
      headers.push({ col: c, name: String(s.getCellValue(c, parsedRange.r1) || colToLetter(c)) });
    }

    const rowHeader = headers.find(h => h.name === s.pivotConfig.rowField) || headers[0];
    const colHeader = headers.find(h => h.name === s.pivotConfig.colField);
    const valHeader = headers.find(h => h.name === s.pivotConfig.valField) || headers[headers.length - 1];

    if (!rowHeader || !valHeader) return null;

    const rowKeysSet = new Set<string>();
    const colKeysSet = new Set<string>();
    const matrix: Record<string, Record<string, number[]>> = {};

    for (let r = parsedRange.r1 + 1; r <= parsedRange.r2; r++) {
      const rowVal = String(s.getCellValue(rowHeader.col, r) || '(blank)');
      const colVal = colHeader ? String(s.getCellValue(colHeader.col, r) || '(blank)') : 'Total';
      const rawNum = s.getCellValue(valHeader.col, r);
      const valNum = typeof rawNum === 'number' ? rawNum : parseFloat(rawNum) || 0;

      rowKeysSet.add(rowVal);
      colKeysSet.add(colVal);

      if (!matrix[rowVal]) matrix[rowVal] = {};
      if (!matrix[rowVal][colVal]) matrix[rowVal][colVal] = [];
      matrix[rowVal][colVal].push(valNum);
    }

    let rowKeys = Array.from(rowKeysSet).slice(0, 5); // top 5 for preview
    if (s.pivotConfig.sortOrder === 'desc') rowKeys.sort((a, b) => b.localeCompare(a));
    else rowKeys.sort((a, b) => a.localeCompare(b));

    const colKeys = Array.from(colKeysSet).slice(0, 4); // top 4 cols for preview

    const calcAgg = (nums: number[]) => {
      if (!nums || nums.length === 0) return 0;
      switch (s.pivotConfig.aggregation) {
        case 'SUM': return nums.reduce((a, b) => a + b, 0);
        case 'AVERAGE': return nums.reduce((a, b) => a + b, 0) / nums.length;
        case 'COUNT': return nums.length;
        case 'MIN': return Math.min(...nums);
        case 'MAX': return Math.max(...nums);
        case 'MEDIAN': {
          const sorted = [...nums].sort((a, b) => a - b);
          const mid = Math.floor(sorted.length / 2);
          return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
        }
        case 'PRODUCT': return nums.reduce((a, b) => a * b, 1);
        default: return nums.reduce((a, b) => a + b, 0);
      }
    };

    return { rowKeys, colKeys, matrix, calcAgg, rowTitle: rowHeader.name, colTitle: colHeader?.name || 'Values' };
  })();

  const aggregations: (typeof s.pivotConfig.aggregation)[] = [
    'SUM', 'AVERAGE', 'COUNT', 'MIN', 'MAX', 'MEDIAN', 'PRODUCT',
  ];

  return (
    <>
      {/* Draggable Splitter Bar */}
      <div
        id="splitter"
        className={isDragging ? 'dragging' : ''}
        onMouseDown={handleSplitterDown}
        onDoubleClick={() => { s.setPivotPanelWidth(320); s.toast('Reset pivot panel width to 320px'); }}
        title="Drag to resize panel, double-click to reset"
      />

      <div
        style={{
          width: s.pivotPanelWidth,
          flexShrink: 0,
          background: 'var(--panel)',
          borderLeft: '1px solid var(--border)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {/* Header */}
        <div className="p-3 border-b border-[var(--border)] flex items-center justify-between bg-[var(--panel)]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 flex items-center justify-center text-white text-base shadow-xs">
              📊
            </div>
            <div>
              <div className="font-bold text-sm text-[var(--text)]">Pivot Panel</div>
              <div className="text-[11px] text-[var(--muted)]">Interactive Data Summarizer</div>
            </div>
          </div>
          <button
            className="text-[var(--muted)] hover:text-red-500 text-sm px-1.5 py-0.5 rounded hover:bg-[var(--hover)]"
            onClick={() => s.togglePivotPanel()}
            title="Close Pivot Panel"
          >
            ✕
          </button>
        </div>

        {/* Form Controls - Scrollable */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3.5">
          {/* SECTION 1: SOURCE RANGE */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider">
                Source Range
              </label>
              <button
                className="text-[10px] text-blue-600 dark:text-blue-400 font-semibold hover:underline"
                onClick={() => s.updatePivotConfig({ sourceRange: detectedRange })}
              >
                Use Selection ({detectedRange})
              </button>
            </div>
            <input
              className="w-full font-mono text-xs px-2.5 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] text-[var(--text)] outline-none focus:border-indigo-500"
              value={activeRangeStr}
              onChange={e => s.updatePivotConfig({ sourceRange: e.target.value })}
              placeholder="e.g. A1:F20"
            />
          </div>

          {/* SECTION 2: ROWS FIELD */}
          <div>
            <label className="text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider block mb-1">
              Rows (Grouping Field)
            </label>
            <select
              className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel)] text-[var(--text)] outline-none focus:border-indigo-500"
              value={s.pivotConfig.rowField}
              onChange={e => s.updatePivotConfig({ rowField: e.target.value })}
            >
              {availableFields.map(f => (
                <option key={f} value={f}>{f}</option>
              ))}
            </select>
          </div>

          {/* SECTION 3: COLUMNS FIELD */}
          <div>
            <label className="text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider block mb-1">
              Columns (Secondary Dimension)
            </label>
            <select
              className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel)] text-[var(--text)] outline-none focus:border-indigo-500"
              value={s.pivotConfig.colField}
              onChange={e => s.updatePivotConfig({ colField: e.target.value })}
            >
              <option value="">(None - 1D Table)</option>
              {availableFields.filter(f => f !== s.pivotConfig.rowField).map(f => (
                <option key={f} value={f}>{f}</option>
              ))}
            </select>
          </div>

          {/* SECTION 4: VALUES FIELD */}
          <div>
            <label className="text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider block mb-1">
              Values (Metric to Aggregate)
            </label>
            <select
              className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel)] text-[var(--text)] outline-none focus:border-indigo-500"
              value={s.pivotConfig.valField}
              onChange={e => s.updatePivotConfig({ valField: e.target.value })}
            >
              {availableFields.map(f => (
                <option key={f} value={f}>{f}</option>
              ))}
            </select>
          </div>

          {/* SECTION 5: FILTERS FIELD */}
          <div>
            <label className="text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider block mb-1">
              Filters (Optional)
            </label>
            <select
              className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel)] text-[var(--text)] outline-none focus:border-indigo-500"
              value={s.pivotConfig.filterField}
              onChange={e => s.updatePivotConfig({ filterField: e.target.value })}
            >
              <option value="">(All Records / No Filter)</option>
              {availableFields.map(f => (
                <option key={f} value={f}>{f}</option>
              ))}
            </select>
          </div>

          {/* SECTION 6: AGGREGATION TYPE */}
          <div>
            <label className="text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider block mb-1">
              Aggregation Method
            </label>
            <div className="grid grid-cols-4 gap-1">
              {aggregations.map(agg => (
                <button
                  key={agg}
                  className={`py-1 text-[10.5px] font-mono font-semibold rounded-md border transition-all ${
                    s.pivotConfig.aggregation === agg
                      ? 'border-indigo-600 bg-indigo-600 text-white shadow-xs'
                      : 'border-[var(--border)] bg-[var(--panel-2)] text-[var(--text)] hover:bg-[var(--hover)]'
                  }`}
                  onClick={() => s.updatePivotConfig({ aggregation: agg })}
                >
                  {agg}
                </button>
              ))}
            </div>
          </div>

          {/* SECTION 7: OPTIONS */}
          <div className="space-y-1.5 pt-1 border-t border-[var(--border)]">
            <label className="text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider block">
              Options
            </label>
            <label className="flex items-center gap-2 text-xs text-[var(--text)] cursor-pointer">
              <input
                type="checkbox"
                checked={s.pivotConfig.showGrandTotals}
                onChange={e => s.updatePivotConfig({ showGrandTotals: e.target.checked })}
              />
              Show Grand Totals Row
            </label>
            <label className="flex items-center gap-2 text-xs text-[var(--text)] cursor-pointer">
              <input
                type="checkbox"
                checked={s.pivotConfig.showRowTotals}
                onChange={e => s.updatePivotConfig({ showRowTotals: e.target.checked })}
              />
              Show Row Totals Column
            </label>
            <label className="flex items-center gap-2 text-xs text-[var(--text)] cursor-pointer">
              <input
                type="checkbox"
                checked={s.pivotConfig.emptyAsZero}
                onChange={e => s.updatePivotConfig({ emptyAsZero: e.target.checked })}
              />
              Treat Empty Cells as 0
            </label>
            <div className="flex items-center gap-2 pt-1">
              <span className="text-xs text-[var(--muted)]">Sort Order:</span>
              <button
                className={`px-2 py-0.5 text-xs rounded border ${
                  s.pivotConfig.sortOrder === 'asc'
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-700 font-bold'
                    : 'border-[var(--border)]'
                }`}
                onClick={() => s.updatePivotConfig({ sortOrder: 'asc' })}
              >
                A → Z
              </button>
              <button
                className={`px-2 py-0.5 text-xs rounded border ${
                  s.pivotConfig.sortOrder === 'desc'
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-700 font-bold'
                    : 'border-[var(--border)]'
                }`}
                onClick={() => s.updatePivotConfig({ sortOrder: 'desc' })}
              >
                Z → A
              </button>
            </div>
          </div>

          {/* SECTION 8: LIVE PREVIEW */}
          <div className="pt-2 border-t border-[var(--border)]">
            <div className="text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider mb-1.5 flex items-center justify-between">
              <span>Live Pivot Preview</span>
              <span className="text-[9.5px] text-emerald-600 font-normal">Auto-calculated</span>
            </div>
            {previewData ? (
              <div className="border border-[var(--border)] rounded-lg overflow-x-auto bg-[var(--panel-2)] text-[11px]">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-[var(--border)] bg-[var(--panel)]">
                      <th className="p-1.5 font-bold text-xs text-[var(--text)] border-r border-[var(--border)]">
                        {previewData.rowTitle}
                      </th>
                      {previewData.colKeys.map(ck => (
                        <th key={ck} className="p-1.5 font-bold text-xs text-right text-indigo-600 border-r border-[var(--border)]">
                          {ck}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {previewData.rowKeys.map(rk => (
                      <tr key={rk} className="border-b border-[var(--border)] last:border-b-0">
                        <td className="p-1.5 font-medium text-[var(--text)] border-r border-[var(--border)] truncate max-w-[90px]">
                          {rk}
                        </td>
                        {previewData.colKeys.map(ck => {
                          const val = previewData.calcAgg(previewData.matrix[rk]?.[ck] || []);
                          return (
                            <td key={ck} className="p-1.5 text-right font-mono border-r border-[var(--border)]">
                              {typeof val === 'number' ? (val % 1 === 0 ? val : val.toFixed(1)) : val}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-3 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] text-center text-xs text-[var(--muted)]">
                Select a valid data table range to preview Pivot calculations.
              </div>
            )}
          </div>
        </div>

        {/* Footer: Apply / Cancel Buttons */}
        <div className="p-3 border-t border-[var(--border)] bg-[var(--panel-2)] flex items-center gap-2">
          <button
            className="flex-1 py-2 text-xs rounded-lg border border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--hover)] font-medium transition-colors"
            onClick={() => s.togglePivotPanel()}
          >
            Cancel
          </button>
          <button
            className="flex-1 py-2 text-xs rounded-lg font-bold text-white bg-indigo-600 hover:bg-indigo-700 active:scale-98 shadow-xs transition-all flex items-center justify-center gap-1 cursor-pointer"
            onClick={() => s.applyPivotTable()}
          >
            <span>✓</span>
            <span>Create Pivot Sheet</span>
          </button>
        </div>
      </div>
    </>
  );
}

// ===== FIND & REPLACE PANEL (Right Sidebar Slider) =====
function FindReplacePanel() {
  const s = useStore();
  const [isDragging, setIsDragging] = useState(false);
  const startXRef = useRef(0);
  const startWRef = useRef(0);

  const { findText, replaceText, matchCase, allCells, currentMatchIndex, totalMatches } = s.findPanelState;

  const handleSplitterDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    startXRef.current = e.clientX;
    startWRef.current = s.findPanelWidth;
  };

  useEffect(() => {
    if (!isDragging) return;
    const handleMM = (e: MouseEvent) => {
      const delta = startXRef.current - e.clientX;
      s.setFindPanelWidth(startWRef.current + delta);
    };
    const handleMU = () => setIsDragging(false);
    document.addEventListener('mousemove', handleMM);
    document.addEventListener('mouseup', handleMU);
    return () => {
      document.removeEventListener('mousemove', handleMM);
      document.removeEventListener('mouseup', handleMU);
    };
  }, [isDragging, s]);

  if (!s.showFindPanel) return null;

  const handleReplaceOne = () => {
    if (!findText) return;
    const { c, r } = s.sel.cursor;
    const raw = s.getCellRaw(c, r);
    const flags = matchCase ? 'g' : 'gi';
    const regex = new RegExp(findText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), flags);
    if (regex.test(raw)) {
      s.snapshot();
      s.setCellRaw(c, r, raw.replace(regex, replaceText));
      s.toast(`Replaced in cell ${cellRef(c, r)}`);
      s.findNextMatch();
    } else {
      s.findNextMatch();
    }
  };

  const handleReplaceAll = () => {
    const count = s.findAndReplace(findText, replaceText, matchCase, allCells);
    s.toast(count > 0 ? `Replaced ${count} occurrence(s)` : 'No matching text found');
  };

  return (
    <>
      {/* Draggable Splitter Bar */}
      <div
        id="splitter"
        className={isDragging ? 'dragging' : ''}
        onMouseDown={handleSplitterDown}
        onDoubleClick={() => { s.setFindPanelWidth(320); s.toast('Reset find panel width to 320px'); }}
        title="Drag to resize panel, double-click to reset"
      />

      <div
        style={{
          width: s.findPanelWidth,
          flexShrink: 0,
          background: 'var(--panel)',
          borderLeft: '1px solid var(--border)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {/* Header */}
        <div className="p-3 border-b border-[var(--border)] flex items-center justify-between bg-[var(--panel)]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-600 flex items-center justify-center text-white text-base shadow-xs">
              🔍
            </div>
            <div>
              <div className="font-bold text-sm text-[var(--text)]">Find & Replace</div>
              <div className="text-[11px] text-[var(--muted)]">Search & modify cells</div>
            </div>
          </div>
          <button
            className="text-[var(--muted)] hover:text-red-500 text-sm px-1.5 py-0.5 rounded hover:bg-[var(--hover)]"
            onClick={() => s.toggleFindPanel()}
            title="Close Find & Replace Panel"
          >
            ✕
          </button>
        </div>

        {/* Content Form */}
        <div className="flex-1 overflow-y-auto p-3.5 space-y-4">
          {/* Find What Input */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider">
                Find What
              </label>
              {totalMatches > 0 && (
                <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-1.5 py-0.5 rounded">
                  Match {currentMatchIndex + 1} of {totalMatches}
                </span>
              )}
            </div>
            <div className="relative">
              <input
                type="text"
                className="w-full text-xs px-2.5 py-2 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] text-[var(--text)] outline-none focus:border-amber-500 focus:bg-[var(--panel)] transition-all font-medium"
                placeholder="Text or number to find..."
                value={findText}
                onChange={e => s.updateFindPanelState({ findText: e.target.value, totalMatches: 0, currentMatchIndex: 0 })}
                onKeyDown={e => {
                  if (e.key === 'Enter') {
                    if (e.shiftKey) s.findPrevMatch();
                    else s.findNextMatch();
                  }
                }}
                autoFocus
              />
              {findText && (
                <button
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-[var(--muted)] hover:text-[var(--text)]"
                  onClick={() => s.updateFindPanelState({ findText: '', totalMatches: 0 })}
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Replace With Input */}
          <div>
            <label className="text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider block mb-1">
              Replace With
            </label>
            <input
              type="text"
              className="w-full text-xs px-2.5 py-2 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] text-[var(--text)] outline-none focus:border-amber-500 focus:bg-[var(--panel)] transition-all font-medium"
              placeholder="Replacement text or value..."
              value={replaceText}
              onChange={e => s.updateFindPanelState({ replaceText: e.target.value })}
              onKeyDown={e => {
                if (e.key === 'Enter') handleReplaceOne();
              }}
            />
          </div>

          {/* Navigation Controls: Find Next / Find Prev */}
          <div className="flex gap-2 pt-1">
            <button
              className="flex-1 py-2 text-xs font-semibold rounded-lg border border-[var(--border)] bg-[var(--panel-2)] hover:bg-[var(--hover)] flex items-center justify-center gap-1 cursor-pointer transition-all active:scale-98"
              onClick={() => s.findPrevMatch()}
              title="Find previous matching cell (Shift+Enter)"
            >
              <span>◀</span>
              <span>Find Prev</span>
            </button>
            <button
              className="flex-1 py-2 text-xs font-bold rounded-lg text-white bg-blue-600 hover:bg-blue-700 flex items-center justify-center gap-1 cursor-pointer transition-all shadow-xs active:scale-98"
              onClick={() => s.findNextMatch()}
              title="Find next matching cell (Enter)"
            >
              <span>Find Next</span>
              <span>▶</span>
            </button>
          </div>

          {/* Search Options Checkboxes */}
          <div className="space-y-2 pt-2 border-t border-[var(--border)]">
            <div className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-wider">
              Search Options
            </div>
            <label className="flex items-center gap-2 text-xs text-[var(--text)] cursor-pointer select-none">
              <input
                type="checkbox"
                checked={matchCase}
                onChange={e => s.updateFindPanelState({ matchCase: e.target.checked })}
              />
              <span>Match exact case (case-sensitive)</span>
            </label>
            <label className="flex items-center gap-2 text-xs text-[var(--text)] cursor-pointer select-none">
              <input
                type="checkbox"
                checked={allCells}
                onChange={e => s.updateFindPanelState({ allCells: e.target.checked })}
              />
              <span>Search entire active sheet</span>
            </label>
          </div>

          {/* Replace Actions */}
          <div className="pt-2 border-t border-[var(--border)] space-y-2">
            <div className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-wider">
              Replace Actions
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                className="py-2 text-xs font-semibold rounded-lg border border-amber-300 bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-200 hover:bg-amber-100 transition-all cursor-pointer"
                onClick={handleReplaceOne}
              >
                Replace
              </button>
              <button
                className="py-2 text-xs font-bold rounded-lg text-white bg-amber-600 hover:bg-amber-700 transition-all shadow-xs cursor-pointer active:scale-98"
                onClick={handleReplaceAll}
              >
                Replace All
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[var(--border)] bg-[var(--panel-2)] flex items-center gap-2">
          <button
            className="flex-1 py-2 text-xs rounded-lg border border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--hover)] font-medium transition-colors cursor-pointer"
            onClick={() => s.toggleFindPanel()}
          >
            Close Panel
          </button>
          <button
            className="flex-1 py-2 text-xs rounded-lg font-bold text-white bg-amber-600 hover:bg-amber-700 active:scale-98 shadow-xs transition-all flex items-center justify-center gap-1 cursor-pointer"
            onClick={handleReplaceAll}
          >
            <span>✓</span>
            <span>Replace All</span>
          </button>
        </div>
      </div>
    </>
  );
}

// ===== SNAPSHOT VERSION HISTORY DRAWER (Right Sidebar Slider - P1) =====
function VersionHistoryDrawer() {
  const s = useStore();
  const [isDragging, setIsDragging] = useState(false);
  const startXRef = useRef(0);
  const startWRef = useRef(0);
  const [customSnapName, setCustomSnapName] = useState('');

  const handleSplitterDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    startXRef.current = e.clientX;
    startWRef.current = s.versionDrawerWidth;
  };

  useEffect(() => {
    if (!isDragging) return;
    const handleMM = (e: MouseEvent) => {
      const delta = startXRef.current - e.clientX;
      s.setVersionDrawerWidth(startWRef.current + delta);
    };
    const handleMU = () => setIsDragging(false);
    document.addEventListener('mousemove', handleMM);
    document.addEventListener('mouseup', handleMU);
    return () => {
      document.removeEventListener('mousemove', handleMM);
      document.removeEventListener('mouseup', handleMU);
    };
  }, [isDragging, s]);

  if (!s.showVersionDrawer) return null;

  const handleTakeSnapshot = () => {
    s.createVersionSnapshot(customSnapName);
    setCustomSnapName('');
  };

  return (
    <>
      {/* Draggable Splitter Bar */}
      <div
        id="splitter"
        className={isDragging ? 'dragging' : ''}
        onMouseDown={handleSplitterDown}
        onDoubleClick={() => { s.setVersionDrawerWidth(340); s.toast('Reset snapshots drawer width to 340px'); }}
        title="Drag to resize drawer, double-click to reset"
      />

      <div
        style={{
          width: s.versionDrawerWidth,
          flexShrink: 0,
          background: 'var(--panel)',
          borderLeft: '1px solid var(--border)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {/* Header */}
        <div className="p-3 border-b border-[var(--border)] flex items-center justify-between bg-[var(--panel)]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-600 flex items-center justify-center text-white text-base shadow-xs">
              ⏱️
            </div>
            <div>
              <div className="font-bold text-sm text-[var(--text)]">Version History</div>
              <div className="text-[11px] text-[var(--muted)]">Manual save points & zero data loss</div>
            </div>
          </div>
          <button
            className="text-[var(--muted)] hover:text-red-500 text-sm px-1.5 py-0.5 rounded hover:bg-[var(--hover)] cursor-pointer"
            onClick={() => s.toggleVersionDrawer()}
            title="Close Version Drawer"
          >
            ✕
          </button>
        </div>

        {/* Top Action Bar: Create Manual Save Point */}
        <div className="p-3 bg-[var(--panel-2)] border-b border-[var(--border)] space-y-2">
          <div className="text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider">
            Create Recovery Point
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              className="flex-1 text-xs px-2.5 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel)] text-[var(--text)] outline-none focus:border-purple-500"
              placeholder="e.g. Before Sales Update..."
              value={customSnapName}
              onChange={e => setCustomSnapName(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter') handleTakeSnapshot();
              }}
            />
            <button
              className="px-3 py-1.5 rounded-lg font-bold text-xs text-white bg-purple-600 hover:bg-purple-700 active:scale-95 shadow-xs transition-all flex items-center gap-1 cursor-pointer whitespace-nowrap"
              onClick={handleTakeSnapshot}
            >
              <span>+</span>
              <span>Take Snapshot</span>
            </button>
          </div>
        </div>

        {/* Snapshot List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          <div className="flex items-center justify-between text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider">
            <span>Saved Checkpoints ({s.versionSnapshots.length})</span>
            <span className="text-emerald-600 font-normal">Auto-Recovery Active</span>
          </div>

          {s.versionSnapshots.length === 0 ? (
            <div className="text-center py-10 px-4 rounded-xl border border-dashed border-[var(--border)] bg-[var(--panel-2)] space-y-2 text-[var(--muted)]">
              <div className="text-3xl">⏱️</div>
              <div className="text-xs font-semibold text-[var(--text)]">No Snapshots Yet</div>
              <p className="text-[11px] leading-relaxed">
                Save manual checkpoints before making major changes or imports. You can instantly restore any version.
              </p>
              <button
                className="mt-2 px-3 py-1.5 bg-purple-600 text-white rounded-lg text-xs font-semibold hover:bg-purple-700 cursor-pointer shadow-xs"
                onClick={() => s.createVersionSnapshot('Initial State')}
              >
                Create Initial Snapshot
              </button>
            </div>
          ) : (
            s.versionSnapshots.map(snap => (
              <div
                key={snap.id}
                className="p-3 rounded-xl border border-[var(--border)] bg-[var(--panel-2)] hover:border-purple-400 transition-all space-y-2 group"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="font-bold text-xs text-[var(--text)] leading-tight truncate">
                    {snap.name}
                  </div>
                  <span
                    className={`text-[9.5px] px-1.5 py-0.5 rounded font-mono font-semibold flex-shrink-0 ${
                      snap.isAuto
                        ? 'bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300'
                        : 'bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-300'
                    }`}
                  >
                    {snap.isAuto ? 'AUTO' : 'MANUAL'}
                  </span>
                </div>

                <div className="text-[10.5px] text-[var(--muted)] font-mono flex items-center gap-1">
                  <span>📅</span>
                  <span>{snap.dateStr}</span>
                </div>

                <div className="text-[10px] text-[var(--muted)] flex items-center gap-2 bg-[var(--panel)] p-1.5 rounded border border-[var(--border)]">
                  <span>📊 {snap.totalSheets} Sheet(s)</span>
                  <span>·</span>
                  <span>📝 {snap.totalCells} Data Cells</span>
                  {snap.charts?.length > 0 && <span>· 📈 {snap.charts.length} Chart(s)</span>}
                </div>

                <div className="flex items-center gap-2 pt-1 border-t border-[var(--border)]">
                  <button
                    className="flex-1 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs shadow-xs transition-all flex items-center justify-center gap-1 cursor-pointer"
                    onClick={() => s.restoreVersionSnapshot(snap.id)}
                    title="Restore spreadsheet to this snapshot state"
                  >
                    <span>↺</span>
                    <span>Restore Version</span>
                  </button>
                  <button
                    className="p-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel)] text-[var(--muted)] hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors cursor-pointer"
                    onClick={() => s.deleteVersionSnapshot(snap.id)}
                    title="Delete snapshot"
                  >
                    🗑️
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[var(--border)] bg-[var(--panel-2)] flex items-center justify-between text-xs">
          <span className="text-[11px] text-[var(--muted)] font-mono">
            {s.versionSnapshots.length} snapshot(s) stored locally
          </span>
          <button
            className="px-3 py-1 text-xs rounded border border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--hover)] cursor-pointer"
            onClick={() => s.toggleVersionDrawer()}
          >
            Close
          </button>
        </div>
      </div>
    </>
  );
}

// ===== FULLSCREEN HELP & APP INFO MODAL =====
function FullscreenHelpModal() {
  const s = useStore();
  const [searchFn, setSearchFn] = useState('');
  const [selectedCat, setSelectedCat] = useState<string>('All');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (s.showFullscreenHelp) s.toggleFullscreenHelp();
      }
    };
    if (s.showFullscreenHelp) document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [s]);

  if (!s.showFullscreenHelp) return null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopiedCode(text);
    s.toast(`Copied: ${text}`);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const navItems: { id: typeof s.helpActiveTab; label: string; icon: string }[] = [
    { id: 'functions', label: 'Functions Library & Examples', icon: '🧮' },
    { id: 'info', label: 'App Overview & Info', icon: 'ℹ️' },
    { id: 'help', label: 'User Guide & Shortcuts', icon: '📖' },
    { id: 'tech', label: 'Technical Architecture', icon: '⚙️' },
    { id: 'codetree', label: 'App Code Tree', icon: '🌳' },
  ];

  const fnCategories = ['All', 'Math', 'Stat', 'Logic', 'Text', 'Lookup', 'Date', 'Finance'];

  const filteredFuncs = FUNCS_METADATA.filter(fn => {
    const matchesSearch =
      fn.name.toLowerCase().includes(searchFn.toLowerCase()) ||
      fn.desc.toLowerCase().includes(searchFn.toLowerCase()) ||
      fn.syntax.toLowerCase().includes(searchFn.toLowerCase());
    const matchesCat = selectedCat === 'All' || fn.category === selectedCat;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="modal-fullscreen-back" onClick={() => s.toggleFullscreenHelp()}>
      <div className="modal-fullscreen-container" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[var(--border)] bg-[var(--panel)]">
          <div className="flex items-center gap-3">
            <div className="px-2.5 py-1 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold text-xs shadow-xs tracking-tight">
              GRmagazin
            </div>
            <div>
              <div className="font-bold text-sm text-[var(--text)] flex items-center gap-2">
                <span>GRmagazin Ncalc v3 — Documentation & Center</span>
                <span className="text-[10.5px] px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 font-mono font-semibold">
                  v3.0
                </span>
              </div>
              <div className="text-[11px] text-[var(--muted)]">
                Smart · Fast · Stable · Simple Spreadsheet Application
              </div>
            </div>
          </div>
          <button
            className="w-8 h-8 rounded-lg flex items-center justify-center text-[var(--muted)] hover:text-[var(--text)] hover:bg-[var(--hover)] text-base transition-colors"
            onClick={() => s.toggleFullscreenHelp()}
            title="Close (Escape)"
          >
            ✕
          </button>
        </div>

        {/* Modal Body with Left Sidebar Navigation */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Navigation Tabs */}
          <div className="w-56 p-3 border-r border-[var(--border)] bg-[var(--panel-2)] flex flex-col gap-1.5 flex-shrink-0">
            <div className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-wider px-3 py-1">
              Documentation
            </div>
            {navItems.map(item => (
              <button
                key={item.id}
                className={`fs-tab-btn${s.helpActiveTab === item.id ? ' active' : ''}`}
                onClick={() => s.setHelpActiveTab(item.id)}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </button>
            ))}

            <div className="mt-auto p-3 rounded-lg border border-[var(--border)] bg-[var(--panel)] text-[11px] space-y-1">
              <div className="font-semibold text-[var(--text)]">Quick Tip 💡</div>
              <div className="text-[10.5px] text-[var(--muted)] leading-tight">
                Click <b>Σ AutoSum</b> in the Data tab or status bar to calculate ranges instantly!
              </div>
            </div>
          </div>

          {/* Right Content Area */}
          <div className="flex-1 overflow-y-auto p-6 bg-[var(--panel)]">
            {/* ===================================================== */}
            {/* 1. APP INFO TAB */}
            {/* ===================================================== */}
            {s.helpActiveTab === 'info' && (
              <div className="space-y-6 max-w-4xl">
                <div>
                  <h1 className="text-xl font-bold text-[var(--text)] mb-1">About GRmagazin Sheets — Ncalc v3</h1>
                  <p className="text-xs text-[var(--muted)] leading-relaxed">
                    GRmagazin Sheets (Ncalc v3) is a modern, high-performance spreadsheet web application designed 
                    for fast numerical analysis, formula evaluation, interactive pivot tables, and rich data styling. 
                    It operates 100% offline in the browser with automated local persistence and zero server latency.
                  </p>
                </div>

                {/* 4 Core Pillars */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  <div className="p-4 rounded-xl border border-[var(--border)] bg-[var(--panel-2)] space-y-1.5">
                    <div className="flex items-center gap-2 font-bold text-xs text-blue-600 dark:text-blue-400">
                      <span className="text-base">🧠</span>
                      <span>SMART (Intelligent UX)</span>
                    </div>
                    <p className="text-[11.5px] text-[var(--muted)] leading-relaxed">
                      Interactive colored formula referencing (P3.1), custom defined Named Ranges (P3.2), 
                      live autocomplete & function assist box, smart contiguous table auto-detection, and auto-fill series extrapolation with reference transposition.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl border border-[var(--border)] bg-[var(--panel-2)] space-y-1.5">
                    <div className="flex items-center gap-2 font-bold text-xs text-emerald-600 dark:text-emerald-400">
                      <span className="text-base">✨</span>
                      <span>SIMPLE (Clean Ergonomics)</span>
                    </div>
                    <p className="text-[11.5px] text-[var(--muted)] leading-relaxed">
                      Authentic Microsoft Office ribbon tabs (File ▾, Edit, Insert, Data, Functions, View, Tools), 
                      Format Painter 🖌️ (P1), 6 side sliders, 2-column right-click context menu, and instant 12-theme carousel switcher.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl border border-[var(--border)] bg-[var(--panel-2)] space-y-1.5">
                    <div className="flex items-center gap-2 font-bold text-xs text-amber-600 dark:text-amber-400">
                      <span className="text-base">⚡</span>
                      <span>FAST (Engine Speed)</span>
                    </div>
                    <p className="text-[11.5px] text-[var(--muted)] leading-relaxed">
                      Formula Dependency Graph (DAG) engine (P2) that recalculates only affected dependent cells in topological order, 
                      $O(1)$ evaluation cache, and CSS fixed table layout rendering at a locked 60fps.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl border border-[var(--border)] bg-[var(--panel-2)] space-y-1.5">
                    <div className="flex items-center gap-2 font-bold text-xs text-purple-600 dark:text-purple-400">
                      <span className="text-base">🛡️</span>
                      <span>STABLE (Zero Data Loss)</span>
                    </div>
                    <p className="text-[11.5px] text-[var(--muted)] leading-relaxed">
                      Snapshot Version History Drawer (P1) with manual recovery checkpoints, circular reference DFS cycle detection returning <code className="font-mono text-red-500">#CIRC!</code>, 
                      error diagnostics console, and automatic LocalStorage persistence.
                    </p>
                  </div>
                </div>

                {/* Features Checklist */}
                <div className="border border-[var(--border)] rounded-xl p-4 bg-[var(--panel)]">
                  <h3 className="font-bold text-xs text-[var(--text)] mb-3 uppercase tracking-wider">
                    Feature Capabilities Matrix
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs text-[var(--muted)]">
                    <div>✅ 65+ Formula Functions</div>
                    <div>✅ Formula DAG Dependency Graph</div>
                    <div>✅ #CIRC! Cycle Protection</div>
                    <div>✅ Interactive Colored Formula Referencing</div>
                    <div>✅ Defined Named Ranges (=SUM(Sales))</div>
                    <div>✅ Format Painter (1-Click Style Cloner)</div>
                    <div>✅ Snapshot Version History & Rollback</div>
                    <div>✅ 6 Right-Side Slider Toolbars</div>
                    <div>✅ Pivot Table Multi-Dimension Engine</div>
                    <div>✅ Find & Replace Sidebar Slider</div>
                    <div>✅ 2-Column Right-Click Context Menu</div>
                    <div>✅ 12 Light & Dark Themes Carousel</div>
                  </div>
                </div>
              </div>
            )}

            {/* ===================================================== */}
            {/* 2. USER GUIDE & APP HELP TAB */}
            {/* ===================================================== */}
            {s.helpActiveTab === 'help' && (
              <div className="space-y-6 max-w-4xl">
                <div>
                  <h1 className="text-xl font-bold text-[var(--text)] mb-1">User Guide & Shortcuts</h1>
                  <p className="text-xs text-[var(--muted)]">
                    Master all spreadsheet controls, keyboard shortcuts, and ribbon tools.
                  </p>
                </div>

                {/* Keyboard Shortcuts Table */}
                <div className="border border-[var(--border)] rounded-xl overflow-hidden">
                  <div className="bg-[var(--panel-2)] px-4 py-2 text-xs font-bold text-[var(--text)] border-b border-[var(--border)]">
                    ⌨️ Keyboard Shortcuts Cheat Sheet
                  </div>
                  <table className="w-full text-xs text-left">
                    <thead className="bg-[var(--header)] text-[var(--muted)] text-[10.5px]">
                      <tr>
                        <th className="p-2.5 font-semibold">Shortcut</th>
                        <th className="p-2.5 font-semibold">Action</th>
                        <th className="p-2.5 font-semibold">Context</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--border)] text-[var(--text)]">
                      <tr>
                        <td className="p-2.5 font-mono font-bold text-blue-600">Enter</td>
                        <td className="p-2.5">Commit edit and move down to next row</td>
                        <td className="p-2.5 text-[var(--muted)]">In-cell / Formula bar</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-mono font-bold text-blue-600">Tab / Shift+Tab</td>
                        <td className="p-2.5">Move selection right or left</td>
                        <td className="p-2.5 text-[var(--muted)]">Grid / Cell editor</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-mono font-bold text-blue-600">F2</td>
                        <td className="p-2.5">Edit active cell in place with text cursor</td>
                        <td className="p-2.5 text-[var(--muted)]">Grid</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-mono font-bold text-blue-600">Shift + Arrows</td>
                        <td className="p-2.5">Expand / shrink multi-cell rectangular selection</td>
                        <td className="p-2.5 text-[var(--muted)]">Grid</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-mono font-bold text-blue-600">Ctrl + Z / Ctrl + Y</td>
                        <td className="p-2.5">Undo / Redo changes (50 history levels)</td>
                        <td className="p-2.5 text-[var(--muted)]">Global</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-mono font-bold text-blue-600">Ctrl + C / Ctrl + X / Ctrl + V</td>
                        <td className="p-2.5">Copy, Cut, and Paste cells (transposing formula references)</td>
                        <td className="p-2.5 text-[var(--muted)]">Grid</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-mono font-bold text-blue-600">Ctrl + F</td>
                        <td className="p-2.5">Open Find & Replace dialog</td>
                        <td className="p-2.5 text-[var(--muted)]">Global</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-mono font-bold text-blue-600">Ctrl + S</td>
                        <td className="p-2.5">Export active spreadsheet as CSV file</td>
                        <td className="p-2.5 text-[var(--muted)]">Global</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-mono font-bold text-blue-600">Ctrl + N</td>
                        <td className="p-2.5">Create a clean new blank spreadsheet document</td>
                        <td className="p-2.5 text-[var(--muted)]">Global</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 font-mono font-bold text-blue-600">Delete / Backspace</td>
                        <td className="p-2.5">Clear values in selected cells</td>
                        <td className="p-2.5 text-[var(--muted)]">Grid</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* UI Walkthrough Cards */}
                <div className="space-y-3">
                  <h3 className="font-bold text-xs text-[var(--text)] uppercase tracking-wider">
                    Interactive Sidebar Panels Guide
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] space-y-1">
                      <div className="font-bold text-blue-600 flex items-center gap-1.5">
                        <span>📊</span> Charts Visualizer Panel
                      </div>
                      <p className="text-[11px] text-[var(--muted)] leading-relaxed">
                        Opened via <b>Insert → Chart</b> or <b>View → Charts Side</b>. Renders hardware-accelerated ECharts 
                        (Bar, Line, Pie, Area, Radar) synced with data ranges.
                      </p>
                    </div>

                    <div className="p-3 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] space-y-1">
                      <div className="font-bold text-emerald-600 flex items-center gap-1.5">
                        <span>🎨</span> Bulk Edit Panel
                      </div>
                      <p className="text-[11px] text-[var(--muted)] leading-relaxed">
                        Opened via <b>View → Bulk Edit</b>. Batch-format cell ranges with 10 background & 10 text color swatches, 
                        typography controls, and live card preview before applying.
                      </p>
                    </div>

                    <div className="p-3 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] space-y-1">
                      <div className="font-bold text-purple-600 flex items-center gap-1.5">
                        <span>📝</span> Format Cells Panel
                      </div>
                      <p className="text-[11px] text-[var(--muted)] leading-relaxed">
                        Opened via <b>View → Format Cells</b>. Includes 7 sub-tabs (Number, Font, Colors, Align, 
                        Border Edit with 8 position diagrams, Conditional formatting, Validation).
                      </p>
                    </div>

                    <div className="p-3 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] space-y-1">
                      <div className="font-bold text-indigo-600 flex items-center gap-1.5">
                        <span>ƒx</span> Formula Builder Panel
                      </div>
                      <p className="text-[11px] text-[var(--muted)] leading-relaxed">
                        Opened via <b>Functions → Formula Builder</b>. Search 65+ function pills with live search filter, 
                        recent usage history, parameter syntax cards, and 1-click cell insertion.
                      </p>
                    </div>

                    <div className="p-3 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] space-y-1">
                      <div className="font-bold text-amber-600 flex items-center gap-1.5">
                        <span>📊</span> Pivot Table Panel
                      </div>
                      <p className="text-[11px] text-[var(--muted)] leading-relaxed">
                        Opened via <b>Data → Pivot Panel</b>. Build multi-dimensional summary tables with Source Range, 
                        Rows, Columns, Values, Filters, 7 aggregation methods, live preview, and 1-click Pivot sheet generation.
                      </p>
                    </div>

                    <div className="p-3 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] space-y-1">
                      <div className="font-bold text-teal-600 flex items-center gap-1.5">
                        <span>🔍</span> Find & Replace Panel
                      </div>
                      <p className="text-[11px] text-[var(--muted)] leading-relaxed">
                        Opened via <b>View → Find</b> or <b>Tools → Find/Replace</b>. Real-time match counter, 
                        case-sensitive matching, next/prev cell navigation, and batch replacement.
                      </p>
                    </div>

                    <div className="p-3 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] space-y-1">
                      <div className="font-bold text-purple-700 dark:text-purple-300 flex items-center gap-1.5">
                        <span>⏱️</span> Snapshot Version Drawer (P1)
                      </div>
                      <p className="text-[11px] text-[var(--muted)] leading-relaxed">
                        Opened via <b>Top-Right Header ⏱️ Snapshots</b> or <b>File ▾ Menu</b>. Create manual named recovery checkpoints 
                        and instantly restore any past version of the spreadsheet.
                      </p>
                    </div>

                    <div className="p-3 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] space-y-1">
                      <div className="font-bold text-pink-600 flex items-center gap-1.5">
                        <span>🏷️</span> Defined Named Ranges (P3.2)
                      </div>
                      <p className="text-[11px] text-[var(--muted)] leading-relaxed">
                        Opened via <b>Functions → Name Manager</b>. Define clean names for cell coordinates (e.g. 
                        <code className="font-mono bg-black/5 px-1 py-0.5 rounded">SalesData → B2:B100</code>) for use in formulas like <code className="font-mono bg-black/5 px-1 py-0.5 rounded">=SUM(SalesData)</code>.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ===================================================== */}
            {/* 3. FUNCTIONS HELP & EXAMPLES TAB */}
            {/* ===================================================== */}
            {s.helpActiveTab === 'functions' && (
              <div className="space-y-4 max-w-4xl">
                <div>
                  <h1 className="text-xl font-bold text-[var(--text)] mb-1">Functions Library & Examples</h1>
                  <p className="text-xs text-[var(--muted)]">
                    Search and explore all 65+ formula functions with exact syntax, descriptions, and interactive examples.
                  </p>
                </div>

                {/* Search & Category Filter */}
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-[var(--muted)]">
                      🔍
                    </span>
                    <input
                      type="text"
                      className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] text-[var(--text)] outline-none focus:border-blue-500"
                      placeholder="Search functions by name (e.g. VLOOKUP, SUM, IF, AVERAGE)..."
                      value={searchFn}
                      onChange={e => setSearchFn(e.target.value)}
                    />
                  </div>
                  <div className="flex items-center gap-1 overflow-x-auto pb-1">
                    {fnCategories.map(cat => (
                      <button
                        key={cat}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                          selectedCat === cat
                            ? 'bg-blue-600 text-white font-bold shadow-xs'
                            : 'border border-[var(--border)] bg-[var(--panel-2)] text-[var(--muted)] hover:text-[var(--text)]'
                        }`}
                        onClick={() => setSelectedCat(cat)}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Functions Cards Grid */}
                <div className="space-y-3">
                  {filteredFuncs.map(fn => (
                    <div
                      key={fn.name}
                      className="p-4 rounded-xl border border-[var(--border)] bg-[var(--panel-2)] hover:border-blue-400 transition-all space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-sm text-blue-600 dark:text-blue-400">
                            {fn.name}
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-[var(--panel)] border border-[var(--border)] text-[var(--muted)] font-semibold">
                            {fn.category}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button
                            className="px-2 py-1 text-[11px] font-medium rounded border border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--hover)]"
                            onClick={() => handleCopy(fn.example)}
                          >
                            {copiedCode === fn.example ? '✓ Copied' : 'Copy Formula'}
                          </button>
                          <button
                            className="px-2.5 py-1 text-[11px] font-bold rounded bg-blue-600 hover:bg-blue-700 text-white shadow-2xs"
                            onClick={() => {
                              s.startEdit(fn.example);
                              s.toggleFullscreenHelp();
                              s.toast(`Inserted ${fn.name} example`);
                            }}
                          >
                            Insert into Cell
                          </button>
                        </div>
                      </div>

                      <div className="p-2 rounded bg-[var(--panel)] border border-[var(--border)] font-mono text-xs text-[var(--text)] font-semibold">
                        {fn.syntax}
                      </div>

                      <p className="text-xs text-[var(--muted)] leading-relaxed">
                        {fn.desc}
                      </p>

                      <div className="text-[11px] flex items-center gap-2 text-[var(--muted)] font-mono bg-blue-50/50 dark:bg-blue-950/20 p-2 rounded border border-blue-100 dark:border-blue-900/40">
                        <span className="font-bold text-blue-600">Example:</span>
                        <span className="text-[var(--text)] font-semibold">{fn.example}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ===================================================== */}
            {/* 4. TECHNICAL ARCHITECTURE TAB */}
            {/* ===================================================== */}
            {s.helpActiveTab === 'tech' && (
              <div className="space-y-6 max-w-4xl">
                <div>
                  <h1 className="text-xl font-bold text-[var(--text)] mb-1">Technical Architecture & Stack</h1>
                  <p className="text-xs text-[var(--muted)]">
                    Deep dive into data structures, formula engine evaluation, virtual table rendering, and benchmarks.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl border border-[var(--border)] bg-[var(--panel-2)] space-y-2">
                    <h3 className="font-bold text-xs text-[var(--text)] uppercase tracking-wider">
                      📦 Technology Stack
                    </h3>
                    <ul className="space-y-1.5 text-xs text-[var(--muted)]">
                      <li>• <b>React 19</b>: Declarative UI rendering & state reconciliation.</li>
                      <li>• <b>TypeScript 5.9</b>: Full compile-time type safety.</li>
                      <li>• <b>Zustand</b>: Fast, atomic reactive state container with auto-persistence.</li>
                      <li>• <b>Apache ECharts</b>: Hardware-accelerated canvas chart rendering engine.</li>
                      <li>• <b>PapaParse</b>: High-performance streaming RFC-4180 CSV parser.</li>
                      <li>• <b>Tailwind CSS 4</b>: Modern, responsive stylesheet engine.</li>
                    </ul>
                  </div>

                  <div className="p-4 rounded-xl border border-[var(--border)] bg-[var(--panel-2)] space-y-2">
                    <h3 className="font-bold text-xs text-[var(--text)] uppercase tracking-wider">
                      🛡️ Formula Engine Stability
                    </h3>
                    <ul className="space-y-1.5 text-xs text-[var(--muted)]">
                      <li>• <b>AST-Free Evaluation</b>: Direct recursive expression evaluator with operator precedence.</li>
                      <li>• <b>Recursion Guard</b>: Max depth limiter (100 stack frames) returning <code className="font-mono text-red-500">#CIRC!</code>.</li>
                      <li>• <b>Error Taxonomy</b>: Categorized handling of <code className="font-mono">#DIV/0!</code>, <code className="font-mono">#NAME?</code>, <code className="font-mono">#REF!</code>, <code className="font-mono">#VALUE!</code>, <code className="font-mono">#N/A</code>.</li>
                      <li>• <b>Sparse Grid Hashmap</b>: Coordinates stored as key string <code className="font-mono">"col,row"</code>.</li>
                    </ul>
                  </div>
                </div>

                <div className="p-4 rounded-xl border border-[var(--border)] bg-[var(--panel)] space-y-3">
                  <h3 className="font-bold text-xs text-[var(--text)] uppercase tracking-wider">
                    ⚡ Performance Benchmarks
                  </h3>
                  <div className="grid grid-cols-4 gap-3 text-center">
                    <div className="p-3 rounded-lg bg-[var(--panel-2)] border border-[var(--border)]">
                      <div className="text-xl font-bold text-blue-600">60 FPS</div>
                      <div className="text-[10px] text-[var(--muted)]">Scroll Performance</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[var(--panel-2)] border border-[var(--border)]">
                      <div className="text-xl font-bold text-emerald-600">&lt; 1ms</div>
                      <div className="text-[10px] text-[var(--muted)]">Formula Calc Latency</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[var(--panel-2)] border border-[var(--border)]">
                      <div className="text-xl font-bold text-purple-600">~320 kB</div>
                      <div className="text-[10px] text-[var(--muted)]">Gzip Bundle Size</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[var(--panel-2)] border border-[var(--border)]">
                      <div className="text-xl font-bold text-amber-600">100%</div>
                      <div className="text-[10px] text-[var(--muted)]">Offline Capable</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ===================================================== */}
            {/* 5. APP CODE TREE TAB */}
            {/* ===================================================== */}
            {s.helpActiveTab === 'codetree' && (
              <div className="space-y-4 max-w-4xl">
                <div>
                  <h1 className="text-xl font-bold text-[var(--text)] mb-1">App Codebase Architecture Tree</h1>
                  <p className="text-xs text-[var(--muted)]">
                    Overview of the component hierarchy, files structure, and reactive state data flows.
                  </p>
                </div>

                {/* Directory Structure Tree */}
                <div className="code-tree-box">
                  <div className="font-bold text-blue-600 dark:text-blue-400 mb-2">
                    📁 project-root/
                  </div>
                  <pre className="text-xs text-[var(--text)] overflow-x-auto">
{`├── 📄 index.html              # HTML5 entry with meta viewport & dynamic title
├── 📄 vite.config.ts           # Vite bundler configuration with singlefile plugin
├── 📄 package.json             # Dependencies (react 19, zustand, echarts, papaparse)
└── 📁 src/
    ├── 📄 main.tsx             # React DOM root render mount
    ├── 📄 types.ts             # TypeScript interfaces (Cell, Sheet, ChartConfig, ThemeDef)
    ├── 📄 utils.ts             # Formula evaluation engine, 65+ functions registry, formatters
    ├── 📄 store.ts             # Zustand state management store with localStorage persistence
    ├── 📄 index.css            # Tailwind styles, 12 themes CSS variables, 2-column context menu
    └── 📄 App.tsx              # Core application components:
        ├── 🎛️  ExcelRibbon       # Excel Ribbon Tabs system (File, Edit, Insert, Data, Functions, View, Tools)
        ├── ✍️  FormulaBar        # Formula input bar with live autocomplete and assist box
        ├── ▦   Grid              # Core grid table with auto-fill handle and 2-column context menu
        ├── 📊  ChartPanel        # Right sidebar slider for interactive ECharts visualizers
        ├── 🎨  BulkEditPanel     # Right sidebar slider for bulk styling with live preview
        ├── 📝  FormatCellsPanel  # Right sidebar slider (Number, Font, Colors, Align, Border, Conditional, Validation)
        ├── 📐  FormulaBuilder    # Right sidebar slider for categorized function explorer and inserter
        ├── 📑  SheetTabs         # Bottom sheet tabs switcher, adder, and renamer
        ├── ℹ️   StatusBar         # Bottom status bar with clickable aggregate calculations (Σ, Avg, Count)
        └── 🪟  Modals:
            ├── TemplateModal     # Preset business templates & custom user templates
            ├── ChartModal        # Chart creation dialog with auto-detected cell ranges
            ├── ThemeModal        # 12 Light & Dark color theme picker
            ├── ResizeModal       # Grid dimensions (rows & cols) modifier
            ├── ErrorModal        # Real-time formula calculation diagnostics console
            ├── FindReplaceModal  # Find and replace with case matching and scope toggles
            └── FullscreenHelp    # Fullscreen documentation, function examples, and code architecture`}
                  </pre>
                </div>

                {/* State Flow Diagram */}
                <div className="p-4 rounded-xl border border-[var(--border)] bg-[var(--panel-2)] space-y-2">
                  <div className="text-xs font-bold text-[var(--text)] uppercase tracking-wider">
                    🔄 Reactive State Flow Architecture
                  </div>
                  <p className="text-xs text-[var(--muted)]">
                    User inputs trigger atomic Zustand actions which update the sparse cell matrix, snapshot the state for Undo/Redo, 
                    recalculate dependent formula nodes, and sync state to <code className="font-mono text-xs">localStorage</code> automatically.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ===== 🧙 FUNCTION WIZARD PANEL (Right Sidebar Slider - Enhanced) =====
function FunctionWizardPanel() {
  const s = useStore();
  const [isDragging, setIsDragging] = useState(false);
  const startXRef = useRef(0);
  const startWRef = useRef(0);
  const [funcCat, setFuncCat] = useState<'Math' | 'Stats' | 'Finance' | 'Text'>('Math');

  const handleSplitterDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    startXRef.current = e.clientX;
    startWRef.current = 340;
  };

  useEffect(() => {
    if (!isDragging) return;
    const handleMM = (_e: MouseEvent) => {};
    const handleMU = () => setIsDragging(false);
    document.addEventListener('mousemove', handleMM);
    document.addEventListener('mouseup', handleMU);
    return () => {
      document.removeEventListener('mousemove', handleMM);
      document.removeEventListener('mouseup', handleMU);
    };
  }, [isDragging]);

  // Categories & Functions mapping (Suggestion #5)
  const wizardFunctions: Record<string, string[]> = {
    Math: ['SUM', 'PRODUCT', 'ROUND', 'SQRT', 'ABS', 'MOD'],
    Stats: ['AVERAGE', 'MIN', 'MAX', 'COUNT', 'COUNTA', 'MEDIAN', 'STDEV'],
    Finance: ['PMT', 'NPV', 'IRR'],
    Text: ['CONCAT', 'LEN', 'TRIM'],
  };

  // Safe normalized primary range (Suggestion #3)
  const s1 = parseCellRef(s.functionWizardStart);
  const e1 = parseCellRef(s.functionWizardEnd);
  const hasValidRange1 = s1 && e1;
  const minC = hasValidRange1 ? Math.min(s1.c, e1.c) : 0;
  const maxC = hasValidRange1 ? Math.max(s1.c, e1.c) : 0;
  const minR = hasValidRange1 ? Math.min(s1.r, e1.r) : 0;
  const maxR = hasValidRange1 ? Math.max(s1.r, e1.r) : 0;

  const targetBelow = hasValidRange1 ? cellRef(minC, maxR + 1) : '';
  const targetRight = hasValidRange1 ? cellRef(maxC + 1, minR) : '';
  const targetActive = cellRef(s.sel.cursor.c, s.sel.cursor.r);

  // Combine all normalized ranges (Suggestion #6)
  const allRangeStrings: string[] = useMemo(() => {
    const list: string[] = [];
    if (hasValidRange1) {
      list.push(`${cellRef(minC, minR)}:${cellRef(maxC, maxR)}`);
    }
    s.functionWizardExtraRanges.forEach(extra => {
      if (extra.start && extra.end) {
        const es = parseCellRef(extra.start);
        const ee = parseCellRef(extra.end);
        if (es && ee) {
          list.push(
            `${cellRef(Math.min(es.c, ee.c), Math.min(es.r, ee.r))}:${cellRef(
              Math.max(es.c, ee.c),
              Math.max(es.r, ee.r)
            )}`
          );
        }
      }
    });
    return list;
  }, [hasValidRange1, minC, maxC, minR, maxR, s.functionWizardExtraRanges]);

  const previewFormulaStr = allRangeStrings.length > 0
    ? `=${s.functionWizardSelectedFunc}(${allRangeStrings.join(', ')})`
    : '';

  // Live Calculation Preview & Data Health Inspector (Suggestion #2)
  const dataInspector = useMemo(() => {
    if (!hasValidRange1) return null;
    const values: any[] = [];
    let blankCount = 0;
    let textCount = 0;
    let errorCount = 0;

    const inspectRange = (r1: number, c1: number, r2: number, c2: number) => {
      for (let r = r1; r <= r2; r++) {
        for (let c = c1; c <= c2; c++) {
          const val = s.getCellValue(c, r);
          if (val === '' || val == null) {
            blankCount++;
          } else if (typeof val === 'string' && val.startsWith('#')) {
            errorCount++;
          } else if (typeof val === 'number' || (!isNaN(parseFloat(val)) && isFinite(val))) {
            values.push(typeof val === 'number' ? val : parseFloat(val));
          } else {
            textCount++;
          }
        }
      }
    };

    inspectRange(minR, minC, maxR, maxC);
    s.functionWizardExtraRanges.forEach(extra => {
      const es = parseCellRef(extra.start);
      const ee = parseCellRef(extra.end);
      if (es && ee) {
        inspectRange(Math.min(es.r, ee.r), Math.min(es.c, ee.c), Math.max(es.r, ee.r), Math.max(es.c, ee.c));
      }
    });

    // Evaluate live result
    let liveResult: any = '—';
    if (previewFormulaStr) {
      const ctx: EvalContext = {
        getCellValue: (c: number, r: number) => s.getCellValue(c, r),
        getCellRaw: (c: number, r: number) => s.getCellRaw(c, r),
        namedRanges: s.namedRanges,
      };
      const res = evaluateFormula(previewFormulaStr, ctx);
      liveResult = res.display;
    }

    return {
      numbers: values,
      numCount: values.length,
      blankCount,
      textCount,
      errorCount,
      liveResult,
    };
  }, [hasValidRange1, minR, minC, maxR, maxC, s.functionWizardExtraRanges, previewFormulaStr, s.sheets, s.activeSheet]);

  // Circular Reference Shield (Suggestion #3)
  const isCircular = useMemo(() => {
    if (!hasValidRange1) return false;
    let targetC = s.sel.cursor.c;
    let targetR = s.sel.cursor.r;

    if (s.functionWizardPlacement === 'below') {
      targetC = minC;
      targetR = maxR + 1;
    } else if (s.functionWizardPlacement === 'right') {
      targetC = maxC + 1;
      targetR = minR;
    } else if (s.functionWizardPlacement === 'copy') {
      return false;
    }

    // Check if target is inside primary range
    if (targetC >= minC && targetC <= maxC && targetR >= minR && targetR <= maxR) {
      return true;
    }

    // Check extra ranges
    for (const extra of s.functionWizardExtraRanges) {
      const es = parseCellRef(extra.start);
      const ee = parseCellRef(extra.end);
      if (es && ee) {
        const emc = Math.min(es.c, ee.c);
        const emxc = Math.max(es.c, ee.c);
        const emr = Math.min(es.r, ee.r);
        const emxr = Math.max(es.r, ee.r);
        if (targetC >= emc && targetC <= emxc && targetR >= emr && targetR <= emxr) {
          return true;
        }
      }
    }

    return false;
  }, [hasValidRange1, minC, maxC, minR, maxR, s.functionWizardPlacement, s.sel.cursor, s.functionWizardExtraRanges]);

  if (!s.showFunctionWizard) return null;

  return (
    <>
      {/* Draggable Splitter Bar */}
      <div
        id="splitter"
        className={isDragging ? 'dragging' : ''}
        onMouseDown={handleSplitterDown}
        onDoubleClick={() => { s.toast('Function Wizard panel'); }}
        title="Drag to resize panel"
      />

      <div
        style={{
          width: 340,
          flexShrink: 0,
          background: 'var(--panel)',
          borderLeft: '1px solid var(--border)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {/* Header */}
        <div className="p-3 border-b border-[var(--border)] bg-[var(--panel-2)]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xl">🧙</span>
              <div>
                <div className="font-bold text-sm text-[var(--text)]">Function Wizard</div>
                <div className="text-[10px] text-[var(--muted)]">Smart Formula Generator & Range Inspector</div>
              </div>
            </div>
            <button
              className="w-7 h-7 rounded-lg flex items-center justify-center text-[var(--muted)] hover:text-red-500 hover:bg-[var(--hover)] text-sm transition-colors cursor-pointer"
              onClick={() => s.toggleFunctionWizard()}
              title="Close Wizard"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-3.5 space-y-3.5">
          {/* Get Range Button */}
          <div className="p-2.5 rounded-xl border-2 border-dashed border-blue-300 dark:border-blue-900/60 bg-blue-50/50 dark:bg-blue-950/20 text-center">
            <button
              className="w-full py-2 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 active:scale-98 text-white font-bold text-xs shadow-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
              onClick={() => s.getRangeFromSelection()}
              title="Capture the currently selected cell range from the spreadsheet"
            >
              <span>📍</span>
              <span>Get Range from Selection</span>
            </button>
            <p className="text-[10.5px] text-[var(--muted)] mt-1.5 leading-tight">
              Select cells in spreadsheet (e.g. C1:C4), then click to capture.
            </p>
          </div>

          {/* Range 1: START and END Text Boxes (Auto-Normalized) */}
          <div className="p-2.5 rounded-xl border border-[var(--border)] bg-[var(--panel-2)] space-y-2">
            <div className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-wider flex items-center justify-between">
              <span>Primary Range</span>
              {hasValidRange1 && (
                <span className="text-[10px] text-emerald-600 font-mono font-semibold">
                  ✓ {cellRef(minC, minR)}:{cellRef(maxC, maxR)}
                </span>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] font-bold text-emerald-700 dark:text-emerald-300 uppercase mb-0.5">
                  🟢 START Cell
                </label>
                <input
                  type="text"
                  className="w-full text-xs font-mono font-bold px-2.5 py-1.5 rounded-lg border border-emerald-300 dark:border-emerald-900/80 bg-[var(--panel)] text-[var(--text)] outline-none focus:ring-2 focus:ring-emerald-500"
                  value={s.functionWizardStart}
                  onChange={e => s.setFunctionWizardStart(e.target.value)}
                  placeholder="e.g. C1"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-amber-700 dark:text-amber-300 uppercase mb-0.5">
                  🟡 END Cell
                </label>
                <input
                  type="text"
                  className="w-full text-xs font-mono font-bold px-2.5 py-1.5 rounded-lg border border-amber-300 dark:border-amber-900/80 bg-[var(--panel)] text-[var(--text)] outline-none focus:ring-2 focus:ring-amber-500"
                  value={s.functionWizardEnd}
                  onChange={e => s.setFunctionWizardEnd(e.target.value)}
                  placeholder="e.g. C4"
                />
              </div>
            </div>
          </div>

          {/* Extra Multi-Ranges (Suggestion #6) */}
          {s.functionWizardExtraRanges.length > 0 && (
            <div className="space-y-2">
              <div className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-wider">
                Additional Ranges (+ Multi-Range)
              </div>
              {s.functionWizardExtraRanges.map((extra, idx) => (
                <div key={idx} className="p-2 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] relative flex items-center gap-2">
                  <div className="flex-1 grid grid-cols-2 gap-1.5">
                    <input
                      type="text"
                      className="text-xs font-mono font-bold px-2 py-1 rounded border border-emerald-300 dark:border-emerald-900 bg-[var(--panel)] text-[var(--text)] outline-none"
                      placeholder={`🟢 Start ${idx + 2}`}
                      value={extra.start}
                      onChange={e => s.updateFunctionWizardExtraRange(idx, 'start', e.target.value)}
                    />
                    <input
                      type="text"
                      className="text-xs font-mono font-bold px-2 py-1 rounded border border-amber-300 dark:border-amber-900 bg-[var(--panel)] text-[var(--text)] outline-none"
                      placeholder={`🟡 End ${idx + 2}`}
                      value={extra.end}
                      onChange={e => s.updateFunctionWizardExtraRange(idx, 'end', e.target.value)}
                    />
                  </div>
                  <button
                    type="button"
                    className="text-xs text-[var(--muted)] hover:text-red-500 p-1 cursor-pointer"
                    onClick={() => s.removeFunctionWizardExtraRange(idx)}
                    title="Remove range"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Add Range Button */}
          <button
            type="button"
            className="w-full py-1 text-[11px] rounded-lg border border-[var(--border)] bg-[var(--panel-2)] hover:bg-[var(--hover)] text-blue-600 font-semibold cursor-pointer transition-colors"
            onClick={() => s.addFunctionWizardExtraRange()}
          >
            + Add Another Range (Multi-Range)
          </button>

          {/* Function Selection with Category Pills (Suggestion #5) */}
          <div className="space-y-1.5">
            <div className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-wider">
              Select Function
            </div>
            {/* Category Sub-Tabs */}
            <div className="flex items-center gap-1 border-b border-[var(--border)] pb-1">
              {(['Math', 'Stats', 'Finance', 'Text'] as const).map(cat => (
                <button
                  key={cat}
                  type="button"
                  className={`px-2 py-0.5 rounded text-[10.5px] font-semibold transition-all cursor-pointer ${
                    funcCat === cat
                      ? 'bg-blue-600 text-white shadow-2xs'
                      : 'text-[var(--muted)] hover:bg-[var(--hover)]'
                  }`}
                  onClick={() => setFuncCat(cat)}
                >
                  {cat}
                </button>
              ))}
            </div>
            {/* Function Buttons Grid */}
            <div className="grid grid-cols-3 gap-1.5 pt-1">
              {wizardFunctions[funcCat].map(func => (
                <button
                  key={func}
                  type="button"
                  className={`py-1.5 px-1 rounded-lg border text-xs font-mono font-bold transition-all cursor-pointer ${
                    s.functionWizardSelectedFunc === func
                      ? 'border-blue-600 bg-blue-600 text-white shadow-xs'
                      : 'border-[var(--border)] bg-[var(--panel)] text-[var(--text)] hover:border-blue-400 hover:bg-[var(--hover)]'
                  }`}
                  onClick={() => s.setFunctionWizardSelectedFunc(func)}
                >
                  {func}
                </button>
              ))}
            </div>
          </div>

          {/* Live Calculation Preview & Data Health Inspector (Suggestion #2) */}
          <div className="p-3 rounded-xl bg-gradient-to-br from-[var(--panel-2)] to-[var(--panel)] border border-[var(--border)] space-y-2">
            <div className="flex items-center justify-between text-[10px] font-bold text-[var(--muted)] uppercase tracking-wider">
              <span>Live Calculation & Preview</span>
              <span className="text-[9.5px] text-emerald-600 font-mono">Real-time</span>
            </div>

            {/* Generated Formula Box */}
            <div className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 p-2 bg-[var(--panel)] rounded-lg border border-[var(--border)] break-all">
              {previewFormulaStr || 'Select range and function'}
            </div>

            {/* Live Result Badge */}
            {dataInspector && (
              <div className="space-y-1.5 pt-1">
                <div className="flex items-center justify-between text-xs bg-[var(--panel)] p-2 rounded-lg border border-[var(--border)]">
                  <span className="text-[var(--muted)] font-medium">Computed Result:</span>
                  <span className="font-mono font-bold text-sm text-[var(--text)]">
                    {dataInspector.liveResult}
                  </span>
                </div>

                {/* Data Health Inspector */}
                <div className="text-[10px] text-[var(--muted)] flex items-center gap-2 flex-wrap pt-0.5">
                  <span className="text-emerald-600 font-semibold">✓ {dataInspector.numCount} numbers</span>
                  {dataInspector.blankCount > 0 && <span>· ⚠️ {dataInspector.blankCount} blanks</span>}
                  {dataInspector.textCount > 0 && <span>· ⚠️ {dataInspector.textCount} text</span>}
                  {dataInspector.errorCount > 0 && <span className="text-red-500 font-bold">· ⚠️ {dataInspector.errorCount} errors</span>}
                </div>
              </div>
            )}
          </div>

          {/* Smart Target Placement (Suggestion #1) */}
          <div className="space-y-1.5">
            <div className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-wider">
              🎯 Insert Destination
            </div>
            <div className="grid grid-cols-2 gap-1.5 text-[11px]">
              <button
                type="button"
                className={`py-2 px-2 rounded-lg border flex items-center justify-center gap-1 font-semibold transition-all cursor-pointer ${
                  s.functionWizardPlacement === 'below'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300 font-bold shadow-xs'
                    : 'border-[var(--border)] bg-[var(--panel)] text-[var(--text)] hover:bg-[var(--hover)]'
                }`}
                onClick={() => s.setFunctionWizardPlacement('below')}
                disabled={!hasValidRange1}
              >
                <span>⬇️</span>
                <span>Below ({targetBelow || '—'})</span>
              </button>

              <button
                type="button"
                className={`py-2 px-2 rounded-lg border flex items-center justify-center gap-1 font-semibold transition-all cursor-pointer ${
                  s.functionWizardPlacement === 'right'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300 font-bold shadow-xs'
                    : 'border-[var(--border)] bg-[var(--panel)] text-[var(--text)] hover:bg-[var(--hover)]'
                }`}
                onClick={() => s.setFunctionWizardPlacement('right')}
                disabled={!hasValidRange1}
              >
                <span>➡️</span>
                <span>Right ({targetRight || '—'})</span>
              </button>

              <button
                type="button"
                className={`py-2 px-2 rounded-lg border flex items-center justify-center gap-1 font-semibold transition-all cursor-pointer ${
                  s.functionWizardPlacement === 'active'
                    ? 'border-blue-600 bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300 font-bold shadow-xs'
                    : 'border-[var(--border)] bg-[var(--panel)] text-[var(--text)] hover:bg-[var(--hover)]'
                }`}
                onClick={() => s.setFunctionWizardPlacement('active')}
              >
                <span>🎯</span>
                <span>Active ({targetActive})</span>
              </button>

              <button
                type="button"
                className={`py-2 px-2 rounded-lg border flex items-center justify-center gap-1 font-semibold transition-all cursor-pointer ${
                  s.functionWizardPlacement === 'copy'
                    ? 'border-purple-600 bg-purple-50 text-purple-700 dark:bg-purple-950/50 dark:text-purple-300 font-bold shadow-xs'
                    : 'border-[var(--border)] bg-[var(--panel)] text-[var(--text)] hover:bg-[var(--hover)]'
                }`}
                onClick={() => s.setFunctionWizardPlacement('copy')}
              >
                <span>📋</span>
                <span>Copy Only</span>
              </button>
            </div>
          </div>

          {/* Circular Reference Warning Shield (Suggestion #3) */}
          {isCircular && (
            <div className="p-2.5 rounded-xl border border-red-300 bg-red-50 text-red-700 dark:bg-red-950/50 dark:text-red-300 dark:border-red-900/60 text-[11px] leading-tight space-y-1">
              <div className="font-bold flex items-center gap-1">
                <span>⚠️</span>
                <span>Circular Reference Loop Detected!</span>
              </div>
              <p>
                Destination cell is inside the formula range. Choose <b>Below</b>, <b>Right</b>, or <b>Copy Only</b> to avoid <code className="font-mono">#CIRC!</code>.
              </p>
            </div>
          )}

          {/* Generate and Insert Action Button */}
          <button
            type="button"
            className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-bold text-sm shadow-md transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            onClick={() => s.generateAndInsertFormula()}
            disabled={!hasValidRange1 || !s.functionWizardSelectedFunc}
            title="Generate and insert formula into destination cell"
          >
            <span>✨</span>
            <span>
              {s.functionWizardPlacement === 'copy'
                ? 'Generate & Copy to Clipboard'
                : `Generate & Insert into ${
                    s.functionWizardPlacement === 'below'
                      ? targetBelow
                      : s.functionWizardPlacement === 'right'
                      ? targetRight
                      : targetActive
                  }`}
            </span>
          </button>
        </div>
      </div>
    </>
  );
}

// ===== MAIN ROOT APP =====
export default function App() {
  const s = useStore();
  const tv = THEMES.find(t => t.key === s.theme)?.vars ?? THEMES[0].vars;

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-theme', s.theme);
    const m: Record<string, string> = {
      bg: '--bg',
      panel: '--panel',
      'panel-2': '--panel-2',
      border: '--border',
      text: '--text',
      muted: '--muted',
      accent: '--accent',
      'accent-2': '--accent-2',
      sel: '--sel',
      'sel-border': '--sel-border',
      header: '--header',
      'chart-bg': '--chart-bg',
      hover: '--hover',
      'menu-bg': '--menu-bg',
    };
    Object.entries(tv).forEach(([k, v]) => {
      const css = m[k];
      if (css) root.style.setProperty(css, v);
    });
  }, [s.theme, tv]);

  useEffect(() => {
    const h = () => s.setShowCtxMenu(false);
    document.addEventListener('click', h);
    return () => document.removeEventListener('click', h);
  }, [s]);

  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden" style={{ background: 'var(--bg)' }}>
      {/* Modern Excel Ribbon System with 2-Line Action Buttons & Top-Right Theme Carousel + Help */}
      <ExcelRibbon />

      {/* Formula Bar with Live Autocomplete */}
      <FormulaBar />

      {/* Main Grid Viewport + Resizable Side Panels */}
      <div className="flex-1 flex overflow-hidden">
        <Grid />
        <ChartPanel />
        <BulkEditPanel /><BorderEditPanel />
        <FormatCellsPanel />
        <FormulaBuilderPanel />
        <PivotPanel />
        <FindReplacePanel />
        <VersionHistoryDrawer />
        <FunctionWizardPanel />
      </div>

      {/* Sheet Tabs & Clickable Status Bar */}
      <SheetTabs />
      <StatusBar />

      {/* Interactive Modals */}
      <TemplateModal />
      <ChartModal />
      <ThemeModal />
      <ResizeModal />
      <ErrorModal />
      <FindReplaceModal />
      <AboutModal />
      <NameManagerModal />
      <FullscreenHelpModal />

      {/* Toast Notification */}
      {s.showToast && <div className="toast">{s.toastMsg}</div>}
    </div>
  );
}