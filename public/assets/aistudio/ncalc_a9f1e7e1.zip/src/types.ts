export interface CellFormat {
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  strikethrough?: boolean;
  fontFamily?: string;
  fontSize?: number;
  color?: string;
  bgColor?: string;
  align?: 'left' | 'center' | 'right';
  valign?: 'top' | 'middle' | 'bottom';
  numberFormat?: string;
  wrap?: boolean;
  border?: { t?: string; b?: string; l?: string; r?: string };
}

export interface Cell {
  raw: string;
  fmt?: CellFormat;
}

export interface Sheet {
  name: string;
  cells: Record<string, Cell>;
  colWidths?: Record<number, number>;
  rowHeights?: Record<number, number>;
}

export interface ChartConfig {
  id: string;
  type: 'bar' | 'line' | 'pie' | 'scatter' | 'area' | 'radar';
  title: string;
  dataRange: string;
  seriesRange?: string;
  options?: Record<string, any>;
  palette?: string;
}

export interface ThemeDef {
  key: string;
  label: string;
  group: 'light' | 'dark';
  vars: Record<string, string>;
}

export interface Template {
  name: string;
  icon: string;
  desc?: string;
  data?: any[][];
  sheets?: Sheet[];
  charts?: ChartConfig[];
  isCustom?: boolean;
  id?: string;
}

export interface VersionSnapshot {
  id: string;
  name: string;
  timestamp: number;
  dateStr: string;
  sheets: Sheet[];
  charts: ChartConfig[];
  activeSheet: number;
  totalCells: number;
  totalSheets: number;
  isAuto?: boolean;
}

export interface FormatPainterState {
  active: boolean;
  fmt: CellFormat;
  isLocked: boolean;
}

export interface NamedRange {
  id: string;
  name: string;
  range: string;
  sheetIndex?: number;
  comment?: string;
}

export interface FormulaReferenceHighlight {
  refText: string;
  color: string;
  bgColor: string;
  borderColor: string;
  bounds: { c1: number; r1: number; c2: number; r2: number };
  cellKeys: string[];
}

export interface FuncDef {
  name: string;
  syntax: string;
  desc: string;
  category: 'Math' | 'Stat' | 'Logic' | 'Text' | 'Date' | 'Finance' | 'Lookup';
  example: string;
}

export interface FormulaErrorItem {
  cell: string;
  formula: string;
  error: string;
  help: string;
}

export type RibbonTabType = 'file' | 'edit' | 'insert' | 'data' | 'import' | 'functions' | 'view' | 'tools';

export const FONT_FAMILIES = [
  'Arial', 'Inter', 'Helvetica', 'Times New Roman', 'Georgia',
  'Courier New', 'monospace', 'Verdana', 'Tahoma', 'Trebuchet MS', 'sans-serif',
];

export const FONT_SIZES = [8, 9, 10, 11, 12, 13, 14, 16, 18, 20, 24, 28, 32, 36, 48];

export const NUMBER_FORMATS = [
  { value: '', label: 'Automatic' },
  { value: 'number', label: 'Number (1,234.56)' },
  { value: 'currency', label: 'Currency ($1,234.56)' },
  { value: 'percent', label: 'Percent (12.34%)' },
  { value: 'date', label: 'Date (2024-01-15)' },
  { value: 'integer', label: 'Integer (1,234)' },
  { value: 'scientific', label: 'Scientific (1.23e+4)' },
];