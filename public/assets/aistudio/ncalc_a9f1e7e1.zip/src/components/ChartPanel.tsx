import React, { useEffect, useRef, useState, useMemo } from 'react';
import { useStore } from '../store';
import { parseRange, colToLetter, cellRef } from '../utils';
import { ChartConfig } from '../types';
import ReactEChartsCore from 'echarts-for-react/lib/core';
import * as echarts from 'echarts/core';
import { BarChart, LineChart, PieChart, ScatterChart, RadarChart } from 'echarts/charts';
import { GridComponent, TooltipComponent, TitleComponent, LegendComponent } from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';

echarts.use([
  BarChart, LineChart, PieChart, ScatterChart, RadarChart,
  GridComponent, TooltipComponent, TitleComponent, LegendComponent, CanvasRenderer,
]);

// 8 named palettes — Vibrant matches the reference photo
export const CHART_PALETTES: Record<string, string[]> = {
  Default: ['#5470c6', '#91cc75', '#fac858', '#ee6666', '#73c0de', '#3ba272', '#fc8452', '#9a60b4'],
  Ocean:   ['#003f5c', '#2f4b7c', '#665191', '#a05195', '#d45087', '#f95d6a', '#ff7c43', '#ffa600'],
  Forest:  ['#2d6a4f', '#52b788', '#95d5b2', '#b7e4c7', '#74c69d', '#40916c', '#1b4332', '#081c15'],
  Sunset:  ['#ff0066', '#ff6600', '#ffc200', '#ff9a3c', '#ff5e62', '#ff9966', '#ff7e5f', '#feb47b'],
  Mono:    ['#333333', '#555555', '#777777', '#999999', '#bbbbbb', '#dddddd', '#222222', '#666666'],
  Pastel:  ['#ffb3ba', '#bae1ff', '#baffc9', '#ffffba', '#ffdfba', '#e0bbff', '#c9f0ff', '#fcb1d4'],
  Vibrant: ['#ff0066', '#3385ff', '#8033e0', '#00cc66', '#ffcc00', '#ff6600', '#00cccc', '#ff3399'],
  Earth:   ['#8b5a2b', '#c19a6b', '#d2b48c', '#a0522d', '#6f4e37', '#5c4033', '#704214', '#3e2723'],
};

const PALETTE_NAMES = Object.keys(CHART_PALETTES);
const CHART_TYPES: { type: ChartConfig['type']; label: string; icon: string }[] = [
  { type: 'bar', label: 'Bar', icon: '📊' },
  { type: 'line', label: 'Line', icon: '📈' },
  { type: 'pie', label: 'Pie', icon: '🥧' },
  { type: 'area', label: 'Area', icon: '📉' },
  { type: 'scatter', label: 'Scatter', icon: '⚬' },
  { type: 'radar', label: 'Radar', icon: '🕸️' },
];

function paletteColors(name?: string): string[] {
  return CHART_PALETTES[name || 'Default'] || CHART_PALETTES.Default;
}

// ===== SMART ANALYSIS =====
function buildAnalysis(cats: string[], sNames: string[], sData: number[][]) {
  const all = sData.flat().filter(n => typeof n === 'number' && !isNaN(n));
  const insights: string[] = [];
  const recs: string[] = [];

  if (all.length === 0) {
    return { insights: ['No numeric data found in range.'], recs: ['Enter numeric values to generate analysis.'] };
  }

  const min = Math.min(...all);
  const max = Math.max(...all);
  const avg = all.reduce((a, b) => a + b, 0) / all.length;
  const pos = all.filter(v => v > 0).length;
  const neg = all.filter(v => v < 0).length;
  const zero = all.filter(v => v === 0).length;
  const mixed = pos > 0 && neg > 0;

  insights.push(`Categories: ${cats.length} · Series: ${sNames.length}`);
  insights.push(`Values: ${all.length} numeric · Min ${formatNum(min)} · Max ${formatNum(max)} · Avg ${formatNum(avg)}`);
  const parts: string[] = [];
  if (pos) parts.push(`${pos} positive`);
  if (neg) parts.push(`${neg} negative`);
  if (zero) parts.push(`${zero} zero`);
  insights.push(`Distribution: ${parts.join(', ')} (${mixed ? 'mixed' : pos > 0 ? 'all positive' : 'all negative'})`);

  // Chart-type recommendations based on actual data
  if (sNames.length === 1 && neg === 0 && cats.length <= 8) recs.push('Pie — single positive series, few categories.');
  if (sNames.length >= 3) recs.push('Bar/Line — multiple series compare well across categories.');
  if (mixed) recs.push('Bar — handles negative values better than Pie/Area.');
  if (cats.length > 12) recs.push('Line — many categories trend better than Pie.');
  if (neg === 0 && sNames.length >= 2) recs.push('Area — good for cumulative positive trends.');
  if (sNames.length >= 4 && cats.length <= 8) recs.push('Radar — compares multivariate profiles.');
  if (recs.length === 0) recs.push('Bar — a safe default for this data shape.');

  return { insights, recs };
}

function formatNum(n: number) {
  if (Math.abs(n) >= 1000) return n.toLocaleString(undefined, { maximumFractionDigits: 1 });
  return Math.round(n * 100) / 100;
}

// ===== CHART CARD =====
function ChartCard({ chart }: { chart: ChartConfig }) {
  const s = useStore();
  const [editMode, setEditMode] = useState(false);
  const [typeMenu, setTypeMenu] = useState(false);
  const [showLegend, setShowLegend] = useState(true);
  const [eTitle, setETitle] = useState(chart.title);
  const [eRange, setERange] = useState(chart.dataRange);
  const [eType, setEType] = useState(chart.type);
  const [ePalette, setEPalette] = useState(chart.palette || 'Default');

  const range = parseRange(chart.dataRange);

  // Reset edit fields when entering edit mode
  useEffect(() => {
    if (editMode) {
      setETitle(chart.title);
      setERange(chart.dataRange);
      setEType(chart.type);
      setEPalette(chart.palette || 'Default');
    }
  }, [editMode]);

  const colors = paletteColors(chart.palette);

  const { option, cats, sNames, sData } = useMemo(() => {
    if (!range) return { option: null, cats: [], sNames: [], sData: [] };
    const cats: string[] = [];
    const sData: number[][] = [];
    for (let r = range.r1; r <= range.r2; r++) {
      cats.push(String(s.getCellValue(range.c1, r) ?? ''));
      const row: number[] = [];
      for (let c = range.c1 + 1; c <= range.c2; c++) {
        const v = s.getCellValue(c, r);
        row.push(typeof v === 'number' ? v : parseFloat(v) || 0);
      }
      sData.push(row);
    }
    const sNames: string[] = [];
    for (let c = range.c1 + 1; c <= range.c2; c++) {
      sNames.push(String(s.getCellValue(c, range.r1 - 1) ?? colToLetter(c)));
    }

    let option: any;
    if (chart.type === 'pie') {
      option = {
        title: { text: chart.title, textStyle: { color: 'var(--text)', fontSize: 12 } },
        tooltip: { trigger: 'item' },
        series: [{
          type: 'pie',
          radius: '62%',
          data: cats.map((cat, i) => ({
            name: cat,
            value: sData[i]?.[0] ?? 0,
            itemStyle: { color: colors[i % colors.length] },
          })),
          label: { color: 'var(--text)', fontSize: 10, formatter: '{b}' },
          labelLine: { length: 8, length2: 10 },
        }],
      };
    } else if (chart.type === 'radar') {
      const maxVal = Math.max(...sData.flat(), 100) * 1.2;
      option = {
        title: { text: chart.title, textStyle: { color: 'var(--text)', fontSize: 12 } },
        tooltip: {},
        radar: { indicator: cats.map(c => ({ name: c, max: maxVal })) },
        series: [{
          type: 'radar',
          data: sNames.map((name, si) => ({
            name,
            value: sData.map(r => r[si] ?? 0),
            itemStyle: { color: colors[si % colors.length] },
            areaStyle: { opacity: 0.15 },
            lineStyle: { color: colors[si % colors.length] },
          })),
        }],
      };
    } else {
      const ct = chart.type === 'area' ? 'line' : chart.type;
      option = {
        title: { text: chart.title, textStyle: { color: 'var(--text)', fontSize: 12 } },
        tooltip: { trigger: 'axis' },
        legend: { data: sNames, textStyle: { fontSize: 10 } },
        xAxis: { type: 'category', data: cats, axisLabel: { fontSize: 9 } },
        yAxis: { type: 'value', axisLabel: { fontSize: 9 } },
        series: sNames.map((name, i) => ({
          name,
          type: ct,
          data: sData.map(r => r[i] ?? 0),
          itemStyle: { color: colors[i % colors.length] },
          lineStyle: { color: colors[i % colors.length] },
          areaStyle: chart.type === 'area' ? { color: colors[i % colors.length], opacity: 0.25 } : undefined,
          smooth: ct === 'line',
        })),
        grid: { left: 40, right: 20, top: 50, bottom: 30 },
      };
    }
    return { option, cats, sNames, sData };
  }, [chart, range, s, colors]);

  if (!range) {
    return (
      <div className="chart-card">
        <div className="p-3 text-xs text-red-500">Invalid data range: {chart.dataRange}</div>
      </div>
    );
  }

  const analysis = buildAnalysis(cats, sNames, sData);

  const handleSelection = () => {
    const { sel } = s;
    const c1 = Math.min(sel.anchor.c, sel.cursor.c);
    const r1 = Math.min(sel.anchor.r, sel.cursor.r);
    const c2 = Math.max(sel.anchor.c, sel.cursor.c);
    const r2 = Math.max(sel.anchor.r, sel.cursor.r);
    const r = `${cellRef(c1, r1)}:${cellRef(c2, r2)}`;
    s.snapshot();
    s.updateChart(chart.id, { dataRange: r });
    s.toast(`Chart range set to current selection: ${r}`);
  };

  const handleDelete = () => {
    s.snapshot();
    s.removeChart(chart.id);
    s.toast('Chart deleted');
  };

  const saveEdit = () => {
    s.snapshot();
    s.updateChart(chart.id, {
      title: eTitle.trim() || 'Chart',
      dataRange: eRange.trim().toUpperCase() || chart.dataRange,
      type: eType,
      palette: ePalette,
    });
    setEditMode(false);
    s.toast('Chart updated');
  };

  const IconBtn = ({ icon, label, onClick, active, danger }: any) => (
    <button
      title={label}
      onClick={onClick}
      className="w-7 h-7 rounded-md flex items-center justify-center text-sm transition-all cursor-pointer border border-transparent"
      style={{
        background: active ? 'rgba(239,68,68,0.12)' : 'transparent',
        color: danger ? '#ef4444' : active ? '#ef4444' : 'var(--muted)',
        borderColor: active ? 'rgba(239,68,68,0.4)' : 'transparent',
      }}
      onMouseEnter={(e) => { if (!active) { e.currentTarget.style.background = 'var(--hover)'; e.currentTarget.style.color = 'var(--text)'; } }}
      onMouseLeave={(e) => { if (!active) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = danger ? '#ef4444' : 'var(--muted)'; } }}
    >
      {icon}
    </button>
  );

  return (
    <div className="chart-card" style={{ background: 'var(--panel)' }}>
      {/* Header: title + icon toolbar */}
      <div className="head" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '.4rem .6rem', borderBottom: '1px solid var(--border)' }}>
        <span className="font-semibold text-xs" style={{ color: 'var(--text)' }}>
          {editMode ? 'Edit Chart' : chart.title}
        </span>
        <div className="flex items-center gap-0.5 relative">
          <IconBtn icon="✎" label="Edit — title, range & palette" onClick={() => setEditMode(v => !v)} active={editMode} />
          <IconBtn icon="⇄" label="Change chart type" onClick={() => setTypeMenu(v => !v)} active={typeMenu} />
          <IconBtn icon="🎯" label="Use current grid selection as range" onClick={handleSelection} />
          <IconBtn
            icon="🏷"
            label={showLegend ? 'Legend ON — click to hide' : 'Legend OFF — click to show'}
            onClick={() => setShowLegend(v => !v)}
            active={showLegend}
          />
          <IconBtn
            icon={s.chartAnalysis ? '💡' : '🔇'}
            label={s.chartAnalysis ? 'Smart Analysis ON — click to disable' : 'Smart Analysis OFF — click to enable'}
            onClick={() => { s.setChartAnalysis(!s.chartAnalysis); s.toast(`Smart Analysis ${!s.chartAnalysis ? 'enabled' : 'disabled'}`); }}
            active={false}
          />
          <IconBtn icon="🗑" label="Delete chart" onClick={handleDelete} danger />
        </div>
      </div>

      {/* Inline type switcher strip */}
      {typeMenu && !editMode && (
        <div className="px-3 py-2 flex flex-wrap gap-1 border-t" style={{ borderColor: 'var(--border)', background: 'var(--panel-2)' }}>
          {CHART_TYPES.map(ct => (
            <button
              key={ct.type}
              className={`px-2 py-1 text-[11px] rounded border cursor-pointer ${chart.type === ct.type ? 'border-[var(--accent)] bg-[var(--sel)] text-[var(--accent)] font-bold' : 'border-[var(--border)] text-[var(--muted)] hover:bg-[var(--hover)]'}`}
              onClick={() => { s.snapshot(); s.updateChart(chart.id, { type: ct.type }); setTypeMenu(false); s.toast(`Type → ${ct.label}`); }}
            >
              {ct.icon} {ct.label}
            </button>
          ))}
        </div>
      )}

      {/* Edit mode form */}
      {editMode ? (
        <div className="p-3 space-y-2.5" style={{ background: 'var(--panel-2)' }}>
          <div>
            <label className="block text-[10px] font-bold uppercase mb-1" style={{ color: 'var(--muted)' }}>Title</label>
            <input
              className="w-full text-xs px-2 py-1.5 rounded border outline-none"
              style={{ background: 'var(--panel)', border: '1px solid var(--border)', color: 'var(--text)' }}
              value={eTitle}
              onChange={e => setETitle(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold uppercase mb-1" style={{ color: 'var(--muted)' }}>Data Range</label>
            <input
              className="w-full text-xs font-mono px-2 py-1.5 rounded border outline-none"
              style={{ background: 'var(--panel)', border: '1px solid var(--border)', color: 'var(--accent)' }}
              value={eRange}
              onChange={e => setERange(e.target.value)}
              placeholder="e.g. A1:E6"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold uppercase mb-1" style={{ color: 'var(--muted)' }}>Type</label>
            <div className="flex flex-wrap gap-1">
              {CHART_TYPES.map(ct => (
                <button
                  key={ct.type}
                  className={`px-2 py-1 text-[11px] rounded border cursor-pointer ${eType === ct.type ? 'border-[var(--accent)] bg-[var(--sel)] text-[var(--accent)] font-bold' : 'border-[var(--border)] text-[var(--muted)] hover:bg-[var(--hover)]'}`}
                  onClick={() => setEType(ct.type)}
                >
                  {ct.icon} {ct.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-[10px] font-bold uppercase mb-1" style={{ color: 'var(--muted)' }}>Color Palette</label>
            <div className="grid grid-cols-4 gap-1.5">
              {PALETTE_NAMES.map(name => {
                const pal = CHART_PALETTES[name];
                const selected = ePalette === name;
                return (
                  <button
                    key={name}
                    title={name}
                    className="p-1.5 rounded border cursor-pointer transition-all flex flex-col items-center gap-1"
                    style={{
                      borderColor: selected ? 'var(--accent)' : 'var(--border)',
                      background: selected ? 'var(--sel)' : 'var(--panel)',
                      boxShadow: selected ? '0 0 0 1px var(--accent)' : 'none',
                    }}
                    onClick={() => setEPalette(name)}
                  >
                    <div className="flex gap-0.5">
                      {pal.slice(0, 5).map((c, i) => (
                        <span key={i} style={{ width: 8, height: 12, background: c, borderRadius: 2, display: 'inline-block' }} />
                      ))}
                    </div>
                    <span className="text-[9px] font-semibold" style={{ color: selected ? 'var(--accent)' : 'var(--muted)' }}>{name}</span>
                  </button>
                );
              })}
            </div>
          </div>
          <div className="flex gap-2 pt-1">
            <button
              className="flex-1 py-1.5 text-xs font-bold rounded text-white cursor-pointer"
              style={{ background: 'var(--accent)' }}
              onClick={saveEdit}
            >
              ✓ Apply
            </button>
            <button
              className="px-3 py-1.5 text-xs rounded border cursor-pointer"
              style={{ border: '1px solid var(--border)', color: 'var(--muted)' }}
              onClick={() => setEditMode(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Chart visual */}
          <div className="p-1" style={{ background: 'var(--chart-bg)' }}>
            {option && <ReactEChartsCore echarts={echarts} option={option} style={{ height: 220, width: '100%' }} />}
          </div>

          {/* Legend (photo-style: Title header + swatch | label | right-aligned value) */}
          {showLegend && (
            <div className="px-3 py-2 border-t" style={{ borderColor: 'var(--border)', background: 'var(--panel-2)' }}>
              <div className="text-[11px] font-bold mb-1.5 pb-1.5 border-b" style={{ color: 'var(--text)', borderColor: 'var(--border)' }}>
                {chart.title}
              </div>
              <div className="space-y-1.5 pt-0.5">
                {sNames.map((name, i) => {
                  const total = sData.reduce((acc, row) => acc + (row[i] ?? 0), 0);
                  return (
                    <div key={i} className="flex items-center gap-2 text-[11px]" style={{ color: 'var(--text)' }}>
                      <span
                        style={{
                          width: 14,
                          height: 14,
                          background: colors[i % colors.length],
                          borderRadius: 4,
                          display: 'inline-block',
                          flexShrink: 0,
                        }}
                      />
                      <span className="truncate flex-1">{name}</span>
                      <span className="font-semibold tabular-nums" style={{ color: 'var(--text)' }}>
                        {formatNum(total)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Smart Analysis */}
          {s.chartAnalysis && (
            <div className="px-3 py-2 border-t" style={{ borderColor: 'var(--border)', background: 'var(--panel)' }}>
              <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase mb-1.5" style={{ color: 'var(--accent)' }}>
                <span>💡</span><span>Smart Analysis</span>
              </div>
              <div className="space-y-1">
                {analysis.insights.map((t, i) => (
                  <div key={i} className="text-[10.5px] leading-tight" style={{ color: 'var(--text)' }}>• {t}</div>
                ))}
                <div className="pt-1 mt-1 border-t" style={{ borderColor: 'var(--border)' }}>
                  <div className="text-[10px] font-semibold mb-0.5" style={{ color: 'var(--muted)' }}>Recommended charts:</div>
                  {analysis.recs.map((t, i) => (
                    <div key={i} className="text-[10.5px] leading-tight" style={{ color: 'var(--accent)' }}>→ {t}</div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ===== CHART PANEL (right sidebar) =====
export default function ChartPanel() {
  const s = useStore();
  const [isDraggingSplitter, setIsDraggingSplitter] = useState(false);
  const startXRef = useRef(0);
  const startWRef = useRef(0);

  const handleSplitterDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDraggingSplitter(true);
    startXRef.current = e.clientX;
    startWRef.current = s.chartsWidth;
  };

  useEffect(() => {
    if (!isDraggingSplitter) return;
    const handleMM = (e: MouseEvent) => {
      const delta = startXRef.current - e.clientX;
      s.setChartsWidth(startWRef.current + delta);
    };
    const handleMU = () => setIsDraggingSplitter(false);
    document.addEventListener('mousemove', handleMM);
    document.addEventListener('mouseup', handleMU);
    return () => {
      document.removeEventListener('mousemove', handleMM);
      document.removeEventListener('mouseup', handleMU);
    };
  }, [isDraggingSplitter, s]);

  if (!s.showCharts) return null;

  return (
    <>
      <div
        id="splitter"
        className={isDraggingSplitter ? 'dragging' : ''}
        onMouseDown={handleSplitterDown}
        onDoubleClick={() => { s.setChartsWidth(360); s.toast('Reset charts width to 360px'); }}
        title="Drag to resize charts, double-click to reset"
      />

      <div
        style={{
          width: s.chartsWidth,
          flexShrink: 0,
          background: 'var(--panel-2)',
          borderLeft: '1px solid var(--border)',
          overflow: 'auto',
          padding: 10,
          display: 'flex',
          flexDirection: 'column',
          gap: 10,
        }}
      >
        <div className="flex items-center justify-between text-xs mb-1" style={{ color: 'var(--muted)' }}>
          <span className="font-semibold">Interactive Charts ({s.charts.length})</span>
          <button className="btn icon" onClick={() => s.toggleCharts()} style={{ fontSize: 10 }}>
            ✕ Hide
          </button>
        </div>
        {s.charts.length === 0 ? (
          <div className="text-center py-12" style={{ color: 'var(--muted)', fontSize: 11 }}>
            <div className="text-2xl mb-2">📊</div>
            No charts attached.<br />
            Select a data range and click <b>Insert → Chart</b>.
          </div>
        ) : (
          s.charts.map(ch => <ChartCard key={ch.id} chart={ch} />)
        )}
      </div>
    </>
  );
}