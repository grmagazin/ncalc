import React, { useEffect, useRef, useState } from 'react';
import { useStore } from '../store';
import { cellRef, FUNCS_METADATA } from '../utils';

// Smart separator groups — set automatically when a function pill is clicked
const RANGE_SEP_COLON = new Set(['SUM','AVERAGE','MIN','MAX','COUNT','COUNTA','COUNTIF','SUMIF','AVERAGEIF','STDEV','STDEVP','VAR','MEDIAN','MODE','LARGE','SMALL','RANK','PERCENTILE','CORREL','PRODUCT','SQRT','INT','LN','LOG','EXP','CEILING','FLOOR']);
const RANGE_SEP_COMMA = new Set(['ROUND','ROUNDUP','ROUNDDOWN','ABS','POWER','MOD','IF','IFS','AND','OR','NOT','IFERROR','SWITCH','CONCAT','CONCATENATE','LEFT','RIGHT','MID','LEN','TRIM','UPPER','LOWER','PROPER','FIND','SEARCH','REPLACE','SUBSTITUTE','TEXT','VALUE','REPT','VLOOKUP','XLOOKUP','HLOOKUP','INDEX','MATCH','OFFSET','CHOOSE','INDIRECT','DATEDIF','DAYS','EDATE','WEEKDAY']);
const RANGE_SEP_EMPTY = new Set(['TODAY','NOW','DATE','YEAR','MONTH','DAY']);

export default function FormulaBuilderPanel() {
  const s = useStore();
  const [isDragging, setIsDragging] = useState(false);
  const startXRef = useRef(0);
  const startWRef = useRef(0);
  const [searchQuery, setSearchQuery] = useState('');

  const targetRef = cellRef(s.sel.cursor.c, s.sel.cursor.r);

  const handleSplitterDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    startXRef.current = e.clientX;
    startWRef.current = s.formulaBuilderWidth;
  };

  useEffect(() => {
    if (!isDragging) return;
    const handleMM = (e: MouseEvent) => {
      const delta = startXRef.current - e.clientX;
      s.setFormulaBuilderWidth(startWRef.current + delta);
    };
    const handleMU = () => setIsDragging(false);
    document.addEventListener('mousemove', handleMM);
    document.addEventListener('mouseup', handleMU);
    return () => {
      document.removeEventListener('mousemove', handleMM);
      document.removeEventListener('mouseup', handleMU);
    };
  }, [isDragging, s]);

  if (!s.showFormulaBuilder) return null;

  // Complete categorization matching reference photos
  const categories: { title: string; icon: string; funcs: string[] }[] = [
    {
      title: 'MATH',
      icon: '📐',
      funcs: [
        'SUM', 'AVERAGE', 'MIN', 'MAX', 'COUNT', 'COUNTA', 'COUNTIF', 'SUMIF',
        'AVERAGEIF', 'ROUND', 'ROUNDUP', 'ROUNDDOWN', 'ABS', 'SQRT', 'POWER',
        'MOD', 'INT', 'CEILING', 'FLOOR', 'PRODUCT', 'LN', 'LOG', 'EXP',
      ],
    },
    {
      title: 'LOGICAL',
      icon: '🔀',
      funcs: ['IF', 'IFS', 'AND', 'OR', 'NOT', 'IFERROR', 'SWITCH'],
    },
    {
      title: 'TEXT',
      icon: '📝',
      funcs: [
        'CONCAT', 'CONCATENATE', 'LEFT', 'RIGHT', 'MID', 'LEN', 'TRIM',
        'UPPER', 'LOWER', 'PROPER', 'FIND', 'SEARCH', 'REPLACE', 'SUBSTITUTE',
        'TEXT', 'VALUE', 'REPT',
      ],
    },
    {
      title: 'LOOKUP',
      icon: '🔍',
      funcs: [
        'VLOOKUP', 'XLOOKUP', 'HLOOKUP', 'INDEX', 'MATCH', 'OFFSET',
        'CHOOSE', 'INDIRECT',
      ],
    },
    {
      title: 'DATE',
      icon: '📅',
      funcs: [
        'TODAY', 'NOW', 'DATE', 'YEAR', 'MONTH', 'DAY', 'DAYS',
        'EDATE', 'WEEKDAY', 'DATEDIF',
      ],
    },
    {
      title: 'STATS',
      icon: '📊',
      funcs: [
        'STDEV', 'STDEVP', 'VAR', 'MEDIAN', 'MODE', 'LARGE', 'SMALL',
        'RANK', 'PERCENTILE', 'CORREL',
      ],
    },
  ];

  // Active selected function metadata
  const selectedMeta = s.selectedBuilderFunc
    ? FUNCS_METADATA.find(f => f.name === s.selectedBuilderFunc) || {
        name: s.selectedBuilderFunc,
        syntax: `${s.selectedBuilderFunc}(value1, [value2], ...)`,
        desc: `Executes standard ${s.selectedBuilderFunc} formula operation.`,
        category: 'Math' as any,
        example: `=${s.selectedBuilderFunc}(A1:B10)`,
      }
    : null;

  const handleFuncClick = (fnName: string) => {
    s.setSelectedBuilderFunc(fnName);
    if (RANGE_SEP_COLON.has(fnName)) s.setRangeSel({ sep: ':' });
    else if (RANGE_SEP_COMMA.has(fnName)) s.setRangeSel({ sep: ',' });
    else if (RANGE_SEP_EMPTY.has(fnName)) s.setRangeSel({ sep: '' });
    // named ranges / unknown: leave separator untouched
  };

  const handleFuncDoubleClick = (fnName: string) => {
    s.insertFormulaToActiveCell(fnName);
  };

  // Read the current grid selection into Start / End
  const handleGetRange = () => {
    const { sel } = s;
    const c1 = Math.min(sel.anchor.c, sel.cursor.c);
    const r1 = Math.min(sel.anchor.r, sel.cursor.r);
    const c2 = Math.max(sel.anchor.c, sel.cursor.c);
    const r2 = Math.max(sel.anchor.r, sel.cursor.r);
    const start = cellRef(c1, r1);
    const end = cellRef(c2, r2);
    s.setRangeSel({ start, end });
    s.toast(`Range ${start}:${end} loaded into selector`);
  };

  return (
    <>
      {/* Draggable Splitter Bar */}
      <div
        id="splitter"
        className={isDragging ? 'dragging' : ''}
        onMouseDown={handleSplitterDown}
        onDoubleClick={() => { s.setFormulaBuilderWidth(320); s.toast('Reset formula builder width to 320px'); }}
        title="Drag to resize panel, double-click to reset"
      />

      <div
        style={{
          width: s.formulaBuilderWidth,
          flexShrink: 0,
          background: 'var(--panel)',
          borderLeft: '1px solid var(--border)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {/* Header (Matching photo 1 & 2) */}
        <div className="p-3 border-b border-[var(--border)] flex items-center justify-between bg-[var(--panel)]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold font-mono text-sm shadow-xs">
              ƒ
            </div>
            <div>
              <div className="font-bold text-sm text-[var(--text)]">Formula Builder</div>
              <div className="text-[11px] text-[var(--muted)] font-mono">
                Target: <span className="font-bold text-blue-600 dark:text-blue-400">{targetRef}</span>
              </div>
            </div>
          </div>
          <button
            className="text-[var(--muted)] hover:text-red-500 text-sm px-1.5 py-0.5 rounded hover:bg-[var(--hover)]"
            onClick={() => s.toggleFormulaBuilder()}
            title="Close Formula Builder"
          >
            ✕
          </button>
        </div>

        {/* Search Functions Bar */}
        <div className="p-3 pb-2 border-b border-[var(--border)] bg-[var(--panel)]">
          <div className="relative">
            <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-[var(--muted)]">
              🔍
            </span>
            <input
              type="text"
              className="w-full text-xs pl-8 pr-7 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel-2)] text-[var(--text)] outline-none focus:border-blue-500 focus:bg-[var(--panel)] transition-all"
              placeholder="Search functions..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
            {searchQuery && (
              <button
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-[var(--muted)] hover:text-[var(--text)]"
                onClick={() => setSearchQuery('')}
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Range Selector */}
        <div className="px-3 py-2 border-b border-[var(--border)] bg-[var(--panel-2)]">
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-[var(--muted)] uppercase tracking-wider mb-1.5">
            <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[8px] font-bold">⌖</span>
            <span>Range Selector</span>
          </div>
          <div className="flex items-center gap-1">
            <input
              type="text"
              className="flex-1 min-w-0 text-xs font-mono px-2 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel)] text-[var(--text)] outline-none focus:border-blue-500 transition-all"
              placeholder="Start"
              value={s.rangeSelStart}
              onChange={e => s.setRangeSel({ start: e.target.value.toUpperCase() })}
            />
            <input
              type="text"
              className="w-9 text-center text-xs font-mono px-1 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel)] text-[var(--text)] outline-none focus:border-blue-500 transition-all"
              placeholder=":"
              value={s.rangeSelSep}
              onChange={e => s.setRangeSel({ sep: e.target.value })}
            />
            <input
              type="text"
              className="flex-1 min-w-0 text-xs font-mono px-2 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--panel)] text-[var(--text)] outline-none focus:border-blue-500 transition-all"
              placeholder="End"
              value={s.rangeSelEnd}
              onChange={e => s.setRangeSel({ end: e.target.value.toUpperCase() })}
            />
            <button
              className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-xs font-bold rounded-lg shadow-xs transition-all"
              onClick={handleGetRange}
              title="Read current grid selection into Start / End"
            >
              GET
            </button>
          </div>
          <div className="text-[10px] text-[var(--muted)] mt-1.5">
            Select a range on the grid, then click GET
          </div>
        </div>

        {/* Scrollable Function List (Matching photo) */}
        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          {/* RECENTLY USED */}
          {!searchQuery && s.recentFunctions.length > 0 && (
            <div>
              <div className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-wider mb-2">
                RECENTLY USED
              </div>
              <div className="flex flex-wrap gap-1.5">
                {s.recentFunctions.map(fn => (
                  <button
                    key={fn}
                    className={`px-3 py-1 text-xs font-mono font-semibold rounded-lg border transition-all ${
                      s.selectedBuilderFunc === fn
                        ? 'border-blue-600 bg-blue-50 text-blue-600 dark:bg-blue-950/50 shadow-xs'
                        : 'border-[var(--border)] bg-[var(--panel)] text-[var(--text)] hover:border-blue-400 hover:bg-[var(--hover)]'
                    }`}
                    onClick={() => handleFuncClick(fn)}
                    onDoubleClick={() => handleFuncDoubleClick(fn)}
                    title={`Click to view details, double-click to insert =${fn}()`}
                  >
                    {fn}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* DEFINED NAMED RANGES (P3.2) */}
          {s.namedRanges.length > 0 && (
            <div className="border-t border-[var(--border)] pt-3 first:border-t-0 first:pt-0">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-[10.5px] font-bold text-purple-600 dark:text-purple-400 uppercase tracking-wider">
                  <span>🏷️</span>
                  <span>DEFINED NAMES ({s.namedRanges.length})</span>
                </div>
                <button
                  type="button"
                  className="text-[10px] text-blue-600 hover:underline"
                  onClick={() => s.setShowNameManagerModal(true)}
                >
                  Manage
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {s.namedRanges
                  .filter(nr => nr.name.toLowerCase().includes(searchQuery.toLowerCase()))
                  .map(nr => (
                    <button
                      key={nr.id}
                      className={`px-2.5 py-1 text-[11px] font-mono font-bold rounded-lg border transition-all ${
                        s.selectedBuilderFunc === nr.name
                          ? 'border-purple-600 bg-purple-600 text-white shadow-xs'
                          : 'border-purple-200 dark:border-purple-900 bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 hover:border-purple-400'
                      }`}
                      onClick={() => handleFuncClick(nr.name)}
                      onDoubleClick={() => handleFuncDoubleClick(nr.name)}
                      title={`Named range: ${nr.range}${nr.comment ? ` (${nr.comment})` : ''}`}
                    >
                      {nr.name}
                    </button>
                  ))}
              </div>
            </div>
          )}

          {/* CATEGORIES */}
          {categories.map(cat => {
            const filteredFuncs = cat.funcs.filter(fn =>
              fn.toLowerCase().includes(searchQuery.toLowerCase())
            );

            if (searchQuery && filteredFuncs.length === 0) return null;

            return (
              <div key={cat.title} className="border-t border-[var(--border)] pt-3 first:border-t-0 first:pt-0">
                <div className="flex items-center gap-1.5 text-[10.5px] font-bold text-[var(--muted)] uppercase tracking-wider mb-2">
                  <span>{cat.icon}</span>
                  <span>{cat.title}</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {filteredFuncs.map(fn => (
                    <button
                      key={fn}
                      className={`px-2.5 py-1 text-[11px] font-mono font-medium rounded-lg border transition-all ${
                        s.selectedBuilderFunc === fn
                          ? 'border-blue-600 bg-blue-600 text-white font-bold shadow-xs'
                          : 'border-[var(--border)] bg-[var(--panel)] text-[var(--text)] hover:border-blue-400 hover:bg-[var(--hover)]'
                      }`}
                      onClick={() => handleFuncClick(fn)}
                      onDoubleClick={() => handleFuncDoubleClick(fn)}
                      title={`Click to view details, double-click to insert =${fn}()`}
                    >
                      {fn}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Details / Inserter Section (Matching Photo 1 & 2 bottom) */}
        <div className="p-3 border-t border-[var(--border)] bg-[var(--panel-2)] flex flex-col items-center justify-center min-h-[90px]">
          {selectedMeta ? (
            <div className="w-full space-y-2 text-left">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs font-mono text-blue-600 dark:text-blue-400">
                  {selectedMeta.name}
                </span>
                <span className="text-[10px] text-[var(--muted)] bg-[var(--panel)] px-1.5 py-0.5 rounded border border-[var(--border)]">
                  {selectedMeta.category}
                </span>
              </div>
              <div className="text-[11px] font-mono text-[var(--text)] font-semibold truncate bg-[var(--panel)] p-1.5 rounded border border-[var(--border)]">
                {selectedMeta.syntax}
              </div>
              <div className="text-[11px] text-[var(--muted)] leading-tight">
                {selectedMeta.desc}
              </div>
              <button
                className="w-full py-2 bg-blue-600 hover:bg-blue-700 active:scale-98 text-white font-bold text-xs rounded-lg shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer mt-1"
                onClick={() => s.insertFormulaToActiveCell(selectedMeta.name)}
              >
                <span>➕</span>
                <span>Insert ={selectedMeta.name}() into {targetRef}</span>
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center text-center py-2 text-[var(--muted)]">
              <div className="w-7 h-7 rounded border border-[var(--border)] flex items-center justify-center font-bold font-mono text-xs mb-1.5 opacity-60">
                ƒ
              </div>
              <div className="text-[11px]">Select a function to see details</div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}