import React, { useEffect, useRef, useState } from 'react';
import { useStore } from '../store';

// Color swatches matching the reference photo
const SWATCHES_ROW1 = [
  { name: 'Black', color: '#000000' },
  { name: 'Dark Gray', color: '#434343' },
  { name: 'Blue', color: '#2563eb' },
  { name: 'Green', color: '#16a34a' },
  { name: 'Red', color: '#dc2626' },
  { name: 'Purple', color: '#7c3aed' },
  { name: 'Burnt Orange', color: '#c2410c' },
];
const SWATCHES_ROW2 = [
  { name: 'Teal', color: '#0891b2' },
  { name: 'Gray', color: '#9ca3af' },
  { name: 'White', color: '#ffffff' },
];

const POSITIONS = [
  { id: 'none', label: 'None', icon: '◻' },
  { id: 'outline', label: 'Outline', icon: '▭' },
  { id: 'inside', label: 'Inside', icon: '⊞' },
  { id: 'all', label: 'All', icon: '▦' },
  { id: 'top', label: 'Top', icon: '▔' },
  { id: 'bottom', label: 'Bottom', icon: '▁' },
  { id: 'left', label: 'Left', icon: '▏' },
  { id: 'right', label: 'Right', icon: '▕' },
] as const;

const LINE_STYLES = [
  { id: 'solid', label: 'Solid', style: 'solid' },
  { id: 'dashed', label: 'Dashed', style: 'dashed' },
  { id: 'dotted', label: 'Dotted', style: 'dotted' },
] as const;

const THICKNESSES = ['1px', '2px', '3px'] as const;

export default function BorderEditPanel() {
  const s = useStore();
  const [isDragging, setIsDragging] = useState(false);
  const startXRef = useRef(0);
  const startWRef = useRef(0);
  const [hexInput, setHexInput] = useState(s.borderEditState.color);

  useEffect(() => {
    setHexInput(s.borderEditState.color);
  }, [s.borderEditState.color]);

  const handleSplitterDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    startXRef.current = e.clientX;
    startWRef.current = s.borderEditWidth;
  };

  useEffect(() => {
    if (!isDragging) return;
    const handleMM = (e: MouseEvent) => {
      const delta = startXRef.current - e.clientX;
      s.setBorderEditWidth(startWRef.current + delta);
    };
    const handleMU = () => setIsDragging(false);
    document.addEventListener('mousemove', handleMM);
    document.addEventListener('mouseup', handleMU);
    return () => {
      document.removeEventListener('mousemove', handleMM);
      document.removeEventListener('mouseup', handleMU);
    };
  }, [isDragging, s]);

  if (!s.showBorderEdit) return null;

  const { borderEditState } = s;
  const borderCss = `${borderEditState.thickness} ${borderEditState.lineStyle} ${borderEditState.color}`;

  const applyHex = (val: string) => {
    const v = val.trim();
    if (/^#[0-9a-fA-F]{3,8}$/.test(v)) s.updateBorderEditState({ color: v });
  };

  return (
    <>
      <div
        id="splitter"
        className={isDragging ? 'dragging' : ''}
        onMouseDown={handleSplitterDown}
        onDoubleClick={() => { s.setBorderEditWidth(320); s.toast('Reset border panel width to 320px'); }}
        title="Drag to resize panel, double-click to reset"
      />

      <div
        style={{
          width: s.borderEditWidth,
          flexShrink: 0,
          background: '#ffffff',
          borderLeft: '1px solid var(--border)',
          overflow: 'auto',
          padding: 14,
          display: 'flex',
          flexDirection: 'column',
          gap: 16,
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b" style={{ borderColor: 'var(--border)' }}>
          <div className="flex items-center gap-2">
            <div
              className="w-7 h-7 rounded-md flex items-center justify-center text-white shadow-xs"
              style={{ background: '#2b5ce6' }}
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
                <rect x="4" y="4" width="16" height="16" rx="1.5" />
              </svg>
            </div>
            <span className="font-bold text-sm" style={{ color: '#1f2937' }}>Border Edit</span>
          </div>
          <button
            className="text-[var(--muted)] hover:text-red-500 text-sm px-1.5 py-0.5 rounded hover:bg-[var(--hover)]"
            onClick={() => s.toggleBorderEdit()}
            title="Close Border Edit"
          >
            ✕
          </button>
        </div>

        {/* PREVIEW */}
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wider mb-1.5" style={{ color: '#6c757d' }}>
            PREVIEW
          </div>
          <div className="flex justify-center">
            <div
              className="w-28 h-16 rounded flex items-center justify-center"
              style={{ background: '#ffffff', border: borderCss }}
            >
              <span className="text-[10px]" style={{ color: '#6c757d' }}>{borderEditState.position}</span>
            </div>
          </div>
        </div>

        {/* BORDER POSITION */}
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wider mb-1.5" style={{ color: '#6c757d' }}>
            BORDER POSITION
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            {POSITIONS.map(p => (
              <button
                key={p.id}
                className={`py-2 px-1 rounded-lg border text-xs font-medium flex flex-col items-center justify-center gap-1 transition-all ${
                  borderEditState.position === p.id
                    ? 'border-[#2b5ce6] bg-[#2b5ce6] text-white font-bold'
                    : 'border-[var(--border)] bg-white hover:bg-[var(--hover)]'
                }`}
                style={borderEditState.position === p.id ? {} : { color: '#374151' }}
                onClick={() => s.updateBorderEditState({ position: p.id as any })}
              >
                <span className="text-base leading-none">{p.icon}</span>
                <span className="text-[10px]">{p.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* LINE STYLE */}
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wider mb-1.5" style={{ color: '#6c757d' }}>
            LINE STYLE
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            {LINE_STYLES.map(ls => (
              <button
                key={ls.id}
                className={`py-2 px-2 rounded-lg border text-xs font-medium flex flex-col items-center justify-center gap-1.5 ${
                  borderEditState.lineStyle === ls.id
                    ? 'border-[#2b5ce6] bg-[#2b5ce6] text-white font-bold'
                    : 'border-[var(--border)] bg-white hover:bg-[var(--hover)]'
                }`}
                style={borderEditState.lineStyle === ls.id ? {} : { color: '#374151' }}
                onClick={() => s.updateBorderEditState({ lineStyle: ls.id as any })}
              >
                <div
                  className="w-full border-t-2"
                  style={{
                    borderStyle: ls.style,
                    borderColor: borderEditState.lineStyle === ls.id ? 'white' : '#111827',
                  }}
                />
                <span className="text-[10px]">{ls.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* THICKNESS */}
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wider mb-1.5" style={{ color: '#6c757d' }}>
            THICKNESS
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            {THICKNESSES.map(th => (
              <button
                key={th}
                className={`py-1.5 rounded-lg border text-xs font-semibold ${
                  borderEditState.thickness === th
                    ? 'border-[#2b5ce6] bg-[#2b5ce6] text-white'
                    : 'border-[var(--border)] bg-white hover:bg-[var(--hover)]'
                }`}
                style={borderEditState.thickness === th ? {} : { color: '#374151' }}
                onClick={() => s.updateBorderEditState({ thickness: th as any })}
              >
                {th}
              </button>
            ))}
          </div>
        </div>

        {/* COLOR */}
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wider mb-1.5" style={{ color: '#6c757d' }}>
            COLOR
          </div>
          <div className="grid grid-cols-7 gap-1.5">
            {SWATCHES_ROW1.map(sw => (
              <button
                key={sw.name}
                title={sw.name}
                className={`w-7 h-7 rounded-md border-2 transition-transform hover:scale-110 ${
                  borderEditState.color.toLowerCase() === sw.color.toLowerCase()
                    ? 'border-[#2b5ce6] ring-2 ring-blue-400'
                    : 'border-gray-200'
                }`}
                style={{ background: sw.color }}
                onClick={() => s.updateBorderEditState({ color: sw.color })}
              />
            ))}
            {SWATCHES_ROW2.map(sw => (
              <button
                key={sw.name}
                title={sw.name}
                className={`w-7 h-7 rounded-md border-2 transition-transform hover:scale-110 ${
                  borderEditState.color.toLowerCase() === sw.color.toLowerCase()
                    ? 'border-[#2b5ce6] ring-2 ring-blue-400'
                    : 'border-gray-300'
                }`}
                style={{ background: sw.color }}
                onClick={() => s.updateBorderEditState({ color: sw.color })}
              />
            ))}
            <button
              className="w-7 h-7 rounded-md border border-[var(--border)] flex items-center justify-center text-xs hover:bg-[var(--hover)]"
              title="Custom color"
              onClick={() => {
                const input = document.createElement('input');
                input.type = 'color';
                input.value = borderEditState.color;
                input.onchange = (e: any) => s.updateBorderEditState({ color: e.target.value });
                input.click();
              }}
            >
              🎨
            </button>
            <input
              type="text"
              className="col-span-1 w-full h-7 text-[10px] font-mono px-1 rounded border border-[var(--border)] outline-none focus:border-[#2b5ce6]"
              style={{ color: '#374151' }}
              value={hexInput}
              onChange={e => setHexInput(e.target.value)}
              onBlur={e => applyHex(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') applyHex((e.target as HTMLInputElement).value); }}
              title="Hex color code"
            />
          </div>
        </div>

        {/* FOOTER BUTTONS */}
        <div className="flex items-center gap-2 pt-2 border-t" style={{ borderColor: 'var(--border)' }}>
          <button
            className="flex items-center gap-1 px-3 py-1.5 text-xs rounded-lg border border-[var(--border)] bg-white hover:bg-[var(--hover)]"
            style={{ color: '#6c757d' }}
            onClick={() => {
              s.snapshot();
              s.setFmtSel({ border: undefined });
              s.toast('Borders cleared');
            }}
            title="Clear borders on selection"
          >
            <span>🧽</span>
            <span>Clear</span>
          </button>
          <button
            className="flex-1 flex items-center justify-center gap-1 py-1.5 text-xs rounded-lg font-semibold text-white shadow-xs"
            style={{ background: '#28a745' }}
            onClick={() => s.applyBorderEdit()}
            title="Smart apply border to selection"
          >
            <span>⚡</span>
            <span>Smart Apply</span>
          </button>
          <button
            className="flex items-center justify-center px-3 py-1.5 text-xs rounded-lg font-semibold text-white shadow-xs"
            style={{ background: '#3367d6' }}
            onClick={() => s.applyBorderEdit()}
            title="Apply border to selection"
          >
            Apply
          </button>
        </div>
      </div>
    </>
  );
}