import React from 'react';
import { useStore } from '../store';
import { buildPrintHTML } from '../lib/fileIO';

export default function PrintPreviewModal() {
  const s = useStore();
  if (!s.showPrintPreview) return null;

  const html = buildPrintHTML(s);

  return (
    <div className="modal-back" onClick={() => s.setModal('showPrintPreview', false)}>
      <div
        className="modal"
        style={{ width: 'min(1000px,94vw)', height: 'min(80vh,760px)', display: 'flex', flexDirection: 'column', padding: 0 }}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-[var(--border)]">
          <h2 className="text-sm font-semibold" style={{ color: 'var(--text)' }}>
            🖨️ Print Preview — {s.sheet().name}
          </h2>
          <div className="flex items-center gap-2">
            <button
              className="px-3 py-1 text-xs rounded font-semibold text-white"
              style={{ background: 'var(--accent)' }}
              onClick={() => {
                const w = window.open('', '_blank');
                if (!w) { s.toast('Popup blocked — allow popups to print'); return; }
                w.document.write(html);
                w.document.close();
                w.focus();
                setTimeout(() => w.print(), 350);
              }}
            >
              Print
            </button>
            <button
              className="w-7 h-7 rounded-md flex items-center justify-center hover:bg-[var(--hover)] text-[var(--muted)] hover:text-[var(--text)] text-sm font-bold cursor-pointer"
              onClick={() => s.setModal('showPrintPreview', false)}
              title="Close (Escape)"
            >
              ✕
            </button>
          </div>
        </div>
        <iframe
          title="Print Preview"
          srcDoc={html}
          style={{ flex: 1, width: '100%', border: 'none', background: '#fff' }}
        />
      </div>
    </div>
  );
}